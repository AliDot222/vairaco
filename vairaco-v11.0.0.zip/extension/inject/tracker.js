// ردیاب تغییرات اسکریپت‌ها (عمومی؛ برای هر اسکریپتی، حتی جدید، بدون دانستن محتوایش).
// begin() پنجره‌ی ثبت را باز می‌کند، end() آن را می‌بندد؛ undo() همه‌ی تغییرات ثبت‌شده را برمی‌گرداند.
// چه ثبت می‌شود: تغییر DOM (المان، attribute، متن) در حین اجرای اسکریپت، و MutationObserver/IntersectionObserver/ResizeObserver،
// تایمر و شنونده‌هایی که اسکریپت می‌سازد (با undo قطع می‌شوند) + تغییراتی که callbackهای همین‌ها بعداً در DOM می‌دهند.
(() => {
  if (globalThis.__vc && globalThis.__vc.v === 3) return;
  const G = globalThis, MAX = 20000, MAXU = 5000;
  const OPT = { subtree: true, childList: true, attributes: true, attributeOldValue: true, characterData: true, characterDataOldValue: true };
  const NativeMO = G.MutationObserver, nSetTimeout = G.setTimeout.bind(G);
  const pend = [];   // رکوردهایی که بین دو فایلِ تزریق‌شده تحویل داده می‌شوند (وگرنه takeRecords خالی برمی‌گرداند)
  const rec = new NativeMO(rs => { for (const r of rs) pend.push(r); });
  const S = { v: 3, log: [], undoers: [], open: false, depth: 0, saved: null };

  const flush = () => {
    for (const r of [...pend.splice(0), ...rec.takeRecords()]) {
      if (S.log.length >= MAX) break;
      const e = { type: r.type, t: r.target, name: r.attributeName, ns: r.attributeNamespace, old: r.oldValue };
      if (r.type === 'attributes') e.after = e.ns ? r.target.getAttributeNS(e.ns, e.name) : r.target.getAttribute(e.name);
      else if (r.type === 'characterData') e.after = r.target.data;
      else { e.add = Array.from(r.addedNodes); e.rem = Array.from(r.removedNodes); e.prev = r.previousSibling; e.next = r.nextSibling; }
      S.log.push(e);
    }
  };
  const track = fn => {   // یک callback را با ثبت تغییراتش اجرا می‌کند
    const outer = S.depth > 0;
    if (!outer) { rec.observe(document, OPT); rec.takeRecords(); pend.length = 0; }
    S.depth++;
    try { return fn(); }
    finally { S.depth--; if (!outer) { flush(); rec.disconnect(); } }
  };
  const wrap = fn => typeof fn !== 'function' ? fn : function (...a) { return track(() => fn.apply(this, a)); };
  const keep = u => { if (S.undoers.length < MAXU) S.undoers.push(u); };

  S.cleanup = fn => keep(fn);   // اسکریپت‌ها می‌توانند کار پاک‌سازیِ خودشان را (مثلاً حذف FontFace) برای Reset ثبت کنند

  const patch = () => {
    const P = S.saved = {};
    for (const k of ['MutationObserver', 'IntersectionObserver', 'ResizeObserver']) {
      const N = G[k]; if (!N) continue;
      P[k] = N;
      const W = function (cb, ...r) { const o = new N(wrap(cb), ...r); keep(() => { try { o.disconnect(); } catch (e) {} }); return o; };
      W.prototype = N.prototype; G[k] = W;
    }
    for (const k of ['setTimeout', 'setInterval']) {
      const N = G[k]; P[k] = N;
      G[k] = function (f, ...r) { const id = N.call(G, wrap(f), ...r); keep(() => { G.clearTimeout(id); G.clearInterval(id); }); return id; };
    }
    const AEL = EventTarget.prototype.addEventListener; P.ael = AEL;
    EventTarget.prototype.addEventListener = function (t, l, o) { if (l) keep(() => { try { this.removeEventListener(t, l, o); } catch (e) {} }); return AEL.call(this, t, l, o); };
  };
  const unpatch = () => {
    const P = S.saved; if (!P) return;
    for (const k in P) { if (k === 'ael') EventTarget.prototype.addEventListener = P.ael; else G[k] = P[k]; }
    S.saved = null;
  };

  S.begin = (hold) => {   // hold=true: the window stays open until end() (used when the script is a separate injected file); safety timeout 3s
    if (S.open) return;
    S.open = true; S.depth++;
    patch(); rec.observe(document, OPT); rec.takeRecords(); pend.length = 0;
    nSetTimeout(S.end, hold ? 3000 : 0);   // اگر اسکریپت خطا داد و end اجرا نشد، پنجره همین‌جا بسته می‌شود
  };
  S.end = () => {
    if (!S.open) return;
    flush(); rec.disconnect(); unpatch(); S.open = false; S.depth = Math.max(0, S.depth - 1);
  };

  const tokens = v => new Set(String(v || '').split(/\s+/).filter(Boolean));
  const styleMap = v => { const d = document.createElement('div'); d.style.cssText = v || ''; const m = {}; for (let i = 0; i < d.style.length; i++) { const p = d.style[i]; m[p] = d.style.getPropertyValue(p) + '|' + d.style.getPropertyPriority(p); } return m; };

  S.undo = () => {
    S.end();
    for (const u of S.undoers.splice(0)) { try { u(); } catch (e) {} }
    const log = S.log.splice(0);
    let n = 0;
    // ۱) ساختار DOM، از آخر به اول
    for (let i = log.length - 1; i >= 0; i--) {
      const e = log[i]; if (e.type !== 'childList') continue;
      try {
        for (const x of e.add) if (x.parentNode === e.t) { e.t.removeChild(x); n++; }
        for (const x of e.rem) {
          if (x.parentNode) continue;
          const ref = e.next && e.next.parentNode === e.t ? e.next : (e.prev && e.prev.parentNode === e.t ? e.prev.nextSibling : null);
          e.t.insertBefore(x, ref); n++;
        }
      } catch (err) {}
    }
    // ۲) attributeها: برای هر (المان، نام) اولین مقدار قبلی و آخرین مقدار بعدی
    const attrs = new Map(), texts = new Map();
    for (const e of log) {
      if (e.type === 'attributes') {
        let m = attrs.get(e.t); if (!m) attrs.set(e.t, m = new Map());
        const k = (e.ns || '') + '|' + e.name, g = m.get(k);
        if (!g) m.set(k, { name: e.name, ns: e.ns, old: e.old, after: e.after }); else g.after = e.after;
      } else if (e.type === 'characterData') {
        const g = texts.get(e.t); if (!g) texts.set(e.t, { old: e.old, after: e.after }); else g.after = e.after;
      }
    }
    for (const [el, m] of attrs) for (const g of m.values()) {
      try {
        const cur = g.ns ? el.getAttributeNS(g.ns, g.name) : el.getAttribute(g.name);
        const set = v => { if (v === null) { g.ns ? el.removeAttributeNS(g.ns, g.name) : el.removeAttribute(g.name); } else { g.ns ? el.setAttributeNS(g.ns, g.name, v) : el.setAttribute(g.name, v); } };
        if (cur === g.after) set(g.old);                                  // بعد از اسکریپت کسی دست نزده: برگرداندن کامل
        else if (g.name === 'class') {                                    // صفحه هم کلاس عوض کرده: فقط سهم اسکریپت
          const o = tokens(g.old), a = tokens(g.after), c = tokens(cur);
          a.forEach(t => { if (!o.has(t)) c.delete(t); }); o.forEach(t => { if (!a.has(t)) c.add(t); });
          el.setAttribute('class', [...c].join(' '));
        } else if (g.name === 'style') {                                  // فقط پراپرتی‌هایی که اسکریپت عوض کرده
          const o = styleMap(g.old), a = styleMap(g.after), c = styleMap(cur);
          for (const p in a) if (o[p] !== a[p] && c[p] === a[p]) { if (o[p] === undefined) el.style.removeProperty(p); else { const [v, pr] = o[p].split('|'); el.style.setProperty(p, v, pr); } }
        }
        if (g.name === 'style' && el.getAttribute('style') === '' && g.old === null) el.removeAttribute('style');
        if (g.name === 'class' && el.getAttribute('class') === '' && g.old === null) el.removeAttribute('class');
        n++;
      } catch (err) {}
    }
    for (const [t, g] of texts) { try { if (t.data === g.after) { t.data = g.old; n++; } } catch (err) {} }
    return n;
  };

  G.__vc = S;
})();
