// vairaco — settings follow you across Chrome profiles (same Google account, Chrome Sync on).
// Source of truth at runtime stays chrome.storage.local; this module mirrors rules + right-click menu choice to
// chrome.storage.sync (small items, well under the quotas) and applies newer remote snapshots back to local.
// Last writer wins by timestamp. First sync on a profile that already has its own rules MERGES instead of overwriting.
const META = 'vc_meta', RULE = 'vc_rule_';
const LOCAL_KEYS = ['rules', 'menuScripts'];
let pushTimer = null, pullTimer = null, busy = Promise.resolve();
const serial = fn => (busy = busy.catch(() => {}).then(fn));
const enabled = async () => (await chrome.storage.local.get('syncOn')).syncOn !== false;   // default ON

async function readRemote() {
  const all = await chrome.storage.sync.get(null);
  const meta = all[META];
  if (!meta || !Array.isArray(meta.ids)) return null;
  const rules = meta.ids.map(id => all[RULE + id]).filter(Boolean);
  return { ts: meta.ts || 0, rules, menu: Array.isArray(meta.menu) ? meta.menu : null, hasMenu: !!meta.hasMenu, all };
}

async function push(ts) {
  const { rules, menuScripts } = await chrome.storage.local.get(LOCAL_KEYS);
  const list = (Array.isArray(rules) ? rules : []).filter(r => r && r.id);
  const items = { [META]: { ts, ids: list.map(r => r.id), menu: Array.isArray(menuScripts) ? menuScripts : [], hasMenu: Array.isArray(menuScripts) } };
  for (const r of list) items[RULE + r.id] = r;
  const old = Object.keys(await chrome.storage.sync.get(null)).filter(k => k.startsWith(RULE) && !(k in items));
  await chrome.storage.local.set({ syncTs: ts });          // before writing, so our own echo is recognised
  await chrome.storage.sync.set(items);
  if (old.length) await chrome.storage.sync.remove(old);
  await chrome.storage.local.set({ syncAt: Date.now(), syncErr: null });
}

async function apply(remote) {
  const set = { rules: remote.rules, syncTs: remote.ts, syncAt: Date.now(), syncErr: null };
  if (remote.hasMenu) set.menuScripts = remote.menu;
  await chrome.storage.local.set(set);
  if (!remote.hasMenu) await chrome.storage.local.remove('menuScripts');
}

// Called on startup/install and after every remote change. Decides push, pull or merge.
export function reconcile() {
  return serial(async () => {
    if (!(await enabled())) return;
    try {
      const remote = await readRemote();
      const { rules, menuScripts, syncTs } = await chrome.storage.local.get([...LOCAL_KEYS, 'syncTs']);
      const hasLocal = (Array.isArray(rules) && rules.length) || Array.isArray(menuScripts);
      if (!remote) { if (hasLocal) await push(Date.now()); return; }
      if (syncTs === undefined && hasLocal) {                       // first time on this profile: merge by rule id, then publish
        const have = new Set(remote.rules.map(r => r.id));
        remote.rules = [...remote.rules, ...(rules || []).filter(r => r && r.id && !have.has(r.id))];
        if (!remote.hasMenu && Array.isArray(menuScripts)) { remote.menu = menuScripts; remote.hasMenu = true; }
        remote.ts = Date.now(); await apply(remote); await push(remote.ts); return;
      }
      if (remote.ts > (syncTs || 0)) await apply(remote);           // newer settings from another profile
    } catch (e) { await chrome.storage.local.set({ syncErr: String((e && e.message) || e).slice(0, 200) }); }
  });
}

export function startSync() {
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area === 'sync') { if (ch[META] || Object.keys(ch).some(k => k.startsWith(RULE))) { clearTimeout(pullTimer); pullTimer = setTimeout(() => reconcile(), 600); } return; }
    if (area !== 'local') return;
    if (ch.syncTs) return;                                          // that was us applying/publishing
    if (ch.syncOn && ch.syncOn.newValue !== false) { reconcile(); return; }
    if (!(ch.rules || ch.menuScripts)) return;
    clearTimeout(pushTimer);                                        // debounce bursts (typing a domain, dragging chips)
    pushTimer = setTimeout(() => serial(async () => {
      if (!(await enabled())) return;
      try { await push(Date.now()); } catch (e) { await chrome.storage.local.set({ syncErr: String((e && e.message) || e).slice(0, 200) }); }
    }), 1200);
  });
  chrome.runtime.onStartup.addListener(reconcile);
  chrome.runtime.onInstalled.addListener(reconcile);
  reconcile();
}
