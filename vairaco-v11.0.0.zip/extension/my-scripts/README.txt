vairaco — scripts folder
========================
Every  name.js  in this folder is a script. Edit with Notepad (or any editor), Save, switch back to Chrome:
it is applied to the open pages instantly. A brand-new file is picked up the next time you open the popup (then it shows in the right-click menu too). No reload, no buttons.

Write plain JavaScript wrapped in  (() => { ... })();  with no import/export.
Optional first lines:
    // @title Pretty name
    // @sites chat.example.com, other.com      (the sites this script is for)
    // @auto                                   (run on those @sites by itself, every visit)
    // @sticky                                 (the page reloads once after Reset)
Keep this README.txt. Handy: popup -> "My scripts" -> "Copy new-script template".
