@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Building extension scripts (src-scripts -> extension/run)...
node tools/build-run.mjs
if errorlevel 1 (
  echo.
  echo BUILD FAILED - see the error above.
) else (
  echo.
  echo BUILD OK - now reload the extension in chrome://extensions
)
pause
