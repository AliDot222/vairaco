export function GPTMATH() {
// name of this file : math.js

// اضافه کردن استایل برای همه ریاضیات
const mathStyle = document.createElement("style");
mathStyle.textContent = `

/* =========================== */
/* ریاضیاتی که MathJax یا KaTeX هستند */
.math, .katex, .katex-display, mjx-container {
    direction: ltr !important;
    unicode-bidi: plaintext !important;
    text-align: left !important;
}

/* =========================== */
/* ریاضی داخل متن معمولی: اعداد + عملگرها */
body * {
    /* این regex داخل CSS نداریم، ولی می‌تونیم روی JS انجام بدیم */
}

/* =========================== */
/* optional: اعداد هم LTR */
body {
    unicode-bidi: plaintext;
}

/* =========================== */
`;
document.head.appendChild(mathStyle);

// ===========================
// JS برای ریاضی داخل متن معمولی (Inline Math / Text)
const elements = document.querySelectorAll("body *");

elements.forEach(el => {
    if(el.childNodes.length > 0){
        el.childNodes.forEach(node => {
            if(node.nodeType === 3){ // Text node
                // Regex تشخیص وجود عملیات ریاضی ساده
                // اینجا 0-9 و + - * / = ^ () را می‌گیریم
                if(/[0-9+\-*/=^()]/.test(node.textContent)){
                    const span = document.createElement("span");
                    span.style.direction = "ltr";
                    span.style.unicodeBidi = "plaintext";
                    span.style.fontFamily = "monospace, sans-serif";
                    span.textContent = node.textContent;
                    node.parentNode.replaceChild(span, node);
                }
            }
        });
    }
});

}
