export function Gemini() {
  (function () {
    'use strict';

    const FONT_CSS = [];   // فونت‌ها از داخل خود افزونه می‌آیند (inject/vazir-faces.js)؛ لینک‌های CDN حذف شد

    const CLASS_NAME = 'tm-persian-font-applied';
    const STYLE_ID   = 'tm-persian-font-style';

    function ensureStyles(doc = document) {
      FONT_CSS.forEach(href => {
        if (!doc.querySelector(`link[rel="stylesheet"][href="${href}"]`)) {
          const l = doc.createElement('link');
          l.rel = 'stylesheet';
          l.href = href;
          doc.head && doc.head.appendChild(l);
        }
      });

      if (!doc.getElementById(STYLE_ID)) {
        const s = doc.createElement('style');
        s.id = STYLE_ID;
        s.textContent = `
          .${CLASS_NAME} {
            font-family: "Vazir", "IRANSans", sans-serif !important;
          }
        `;
        doc.head && doc.head.appendChild(s);
      }
    }

    function hasPersianText(node) {
      if (!node) return false;
      const txt = node.textContent;
      if (!txt) return false;
      return /[آ-ی]/.test(txt.trim());
    }

    function applyToElement(el) {
      try {
        if (el && el.nodeType === 1) {
          if (hasPersianText(el)) {
            el.classList.add(CLASS_NAME);
          } else if (el.classList.contains(CLASS_NAME)) {
            el.classList.remove(CLASS_NAME);
          }
        }
      } catch {}
    }

    function initialScan(doc = document) {
      const candidates = doc.querySelectorAll('p, span, a, h1, h2, h3, h4, h5, div, li, td, textarea, input');
      candidates.forEach(el => applyToElement(el));
    }

    function scanNodeForPersian(node) {
      if (!node) return;
      if (node.nodeType === 3) {
        const parent = node.parentElement;
        if (parent) applyToElement(parent);
        return;
      }
      if (node.nodeType === 1) {
        applyToElement(node);
        const inner = node.querySelectorAll('p, span, a, div, li, td, h1, h2, h3');
        inner.forEach(el => applyToElement(el));
      }
    }

    const mo = new MutationObserver(muts => {
      for (const m of muts) {
        if (m.type === 'characterData') {
          scanNodeForPersian(m.target);
        } else {
          m.addedNodes && m.addedNodes.forEach(n => scanNodeForPersian(n));
          if (m.target) scanNodeForPersian(m.target);
        }
      }
    });

    function startObserver(doc = document) {
      try {
        if (doc.body) {
          mo.observe(doc.body, {
            childList: true,
            subtree: true,
            characterData: true
          });
        }
      } catch (e) {
        console.warn('GEMINI Persian Font: observer failed', e);
      }
    }

    function applyToIframes() {
      const iframes = Array.from(document.querySelectorAll('iframe'));
      iframes.forEach(fr => {
        try {
          const doc = fr.contentDocument;
          if (!doc) return;
          ensureStyles(doc);
          initialScan(doc);
        } catch {
          // cross-origin
        }
      });
    }

    function boot() {
      ensureStyles(document);

      const readyFonts = (document.fonts && typeof document.fonts.ready?.then === 'function')
        ? document.fonts.ready.then.bind(document.fonts.ready)
        : null;

      const doWork = () => {
        initialScan();
        applyToIframes();
        startObserver();

        const intervalMs = 3000;
        const ticker = setInterval(() => {
          initialScan();
          applyToIframes();
        }, intervalMs);

        window.addEventListener('beforeunload', () => {
          try { mo.disconnect(); } catch {}
          try { clearInterval(ticker); } catch {}
        });

        console.info('GEMINI Persian Font: active');
      };

      if (readyFonts) {
        readyFonts(() => doWork()).catch(() => doWork());
      } else {
        doWork();
      }
    }

    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', boot, { once: true });
    } else {
      boot();
    }
  })();
}
