@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Starting vairaco bridge on http://127.0.0.1:47654
echo Keep this window open while using the extension popup.
echo.
node tools/bridge.mjs
echo.
echo Bridge stopped.
pause
