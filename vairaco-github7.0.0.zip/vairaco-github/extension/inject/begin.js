// vairaco — opens the change-tracking window for a script dropped into my-scripts/ (see inject/tracker.js).
if (globalThis.__vc) globalThis.__vc.begin();
