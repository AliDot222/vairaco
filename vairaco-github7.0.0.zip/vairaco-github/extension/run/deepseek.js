// تولیدشده توسط tools/build-run.mjs از src-scripts/deepseek.js (کد اصلی بدون تغییر)
;(() => { const vc = globalThis.__vc; if (vc) vc.begin();
try {
function DEEPSEEK() {
  // - DEEP-SEEK
  // محتوای استایل دقیقاً همان اسکریپت اصلی است؛ تنها تفاوت «نحوه‌ی اتصال»:
  // به‌جای document.head.innerHTML +=  از تزریق امنِ عنصر <style> استفاده می‌کنیم تا head سایت خراب نشود
  // و با اجرای دوباره (SPA) استایل قبلی پاک و دوباره اضافه شود (بدون تکرار).
  // نکته: تگ‌های <style> خودِ اسکریپتِ اصلی فقط ظرف HTML بودند؛ چون این‌جا محتوا را به textContent
  // می‌دهیم، همان CSS تمیز (بدون تگ) درج می‌شود تا قاعده‌ی اول باطل نشود.

  // پاک کردن استایل قبلی برای جلوگیری از دوباره‌کاری
  document.getElementById('vc-deepseek-style')?.remove();

  // روش امن تزریق استایل (بدون خراب کردن head)
  const s = document.createElement('style');
  s.id = 'vc-deepseek-style';
  s.textContent = `
    /* تنظیم فونت فارسی برای کل صفحه */
    * {
        font-family: Vazirmatn, IranSans, Tahoma, sans-serif !important;
    }

    /* تنظیم جهت متن */
    * {
        direction: rtl !important;
        text-align: right !important;
    }

    /* استثنا برای کد و فرمول‌های ریاضی */
    pre, code, pre *, code *,
    [class*="code"], [class*="code"] *,
    [class*="Code"], [class*="Code"] *,
    [class*="math"], [class*="math"] *,
    [class*="Math"], [class*="Math"] *,
    [class*="equation"], [class*="equation"] *,
    [class*="Equation"], [class*="Equation"] *,
    [class*="formula"], [class*="formula"] *,
    [class*="Formula"], [class*="Formula"] *,
    [class*="katex"], [class*="katex"] *,
    [class*="latex"], [class*="latex"] *,
    .math, .Math, .equation, .Equation,
    .formula, .Formula, .katex, .latex,
    mjx-container, mjx-container * {
        direction: ltr !important;
        text-align: left !important;
        font-size: calc(100% + 0.7px) !important;
        font-family: monospace, "Courier New", Courier !important;
        letter-spacing: 0.5px !important;
    }

    /* 🔥 باکس پرامپت مثل Copilot */
    textarea, input[type="text"], [contenteditable="true"] {
        direction: auto !important;
        unicode-bidi: plaintext !important;
        text-align: start !important;
    }
  `;

  // اتصال به head
  (document.head || document.documentElement).appendChild(s);
}

;DEEPSEEK();

} finally { if (vc) vc.end(); } })();
