// تولیدشده توسط tools/build-run.mjs از src-scripts/gpt-dev.js (کد اصلی بدون تغییر)
;(() => { const vc = globalThis.__vc; if (vc) vc.begin();
try {
function GPTDev() {
  //                              - GPT-

  // اضافه کردن لینک فونت وزیر
  const fontLink = document.createElement("link");
  fontLink.href = "https://cdn.jsdelivr.net/gh/rastikerdar/vazir-font@v30.1.0/dist/font-face.css";
  fontLink.rel = "stylesheet";
  document.head.appendChild(fontLink);

  const s = document.createElement("style");
  s.textContent = `
code, pre {
  font-family: monospace !important;
  font-size: calc(1em + 1px) !important;
  white-space: pre-wrap !important;
  overflow-x: auto !important;
  line-height: 1.7 !important;
  letter-spacing: 0.6px !important;

  /* 👇 این‌ها باعث می‌شن " و < و > دقیق نمایش داده بشن */
  unicode-bidi: plaintext !important;
  direction: ltr !important;
}

body, p, span, div {
  font-family: "Vazir", "IranSans", sans-serif !important;
}
    `;
  document.head.appendChild(s);

  // تنظیم جهت متن خودکار
  const css = `
    * {
      unicode-bidi: plaintext !important;
      direction: auto !important;
    }
  `;
  const styleSheet = document.createElement('style');
  styleSheet.textContent = css;
  document.head.appendChild(styleSheet);


  






}

;GPTDev();

} finally { if (vc) vc.end(); } })();
