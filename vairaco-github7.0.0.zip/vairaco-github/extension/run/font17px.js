// تولیدشده توسط tools/build-run.mjs از src-scripts/font17px.js (کد اصلی بدون تغییر)
;(() => { const vc = globalThis.__vc; if (vc) vc.begin();
try {
function FONT17PX() {

// Style e koli baraye hame
const style = document.createElement('style');
style.textContent = `
    body { font-size: 20px !important; }
    div, p, span, a, li, td, button, input, textarea, 
    h1, h2, h3, h4, h5, h6, label, strong, b, i, em, 
    code, pre, blockquote, article, section, main, 
    header, footer, nav, aside, form, select, option {
        font-size: inherit !important;
    }
`;
document.head.appendChild(style);

}

;FONT17PX();

} finally { if (vc) vc.end(); } })();
