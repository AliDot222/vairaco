// تولیدشده توسط tools/build-run.mjs از src-scripts/a.js (کد اصلی بدون تغییر)
;(() => { const vc = globalThis.__vc; if (vc) vc.begin();
try {
// @sites   (optional) chat.example.com
// Write plain JavaScript. “Reset Styles” undoes every change.
// Example: light-pink background and strong-pink text
document.body.style.background = '#fff0f6';
document.body.style.color = '#be185d';


} finally { if (vc) vc.end(); } })();
