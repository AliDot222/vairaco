// «Vazir»: فونت وزیر (لوکال) روی کل صفحه، به‌جز بلاک کد. فونت‌ها را inject/vazir-faces.js از پوشه‌ی fonts می‌آورد.
;(() => {
  const vc = globalThis.__vc; if (vc) vc.begin();
  try {
    if (!document.getElementById('vc-vazir-style')) {
      const s = document.createElement('style'); s.id = 'vc-vazir-style';
      s.textContent = `
        body, body *:not(pre):not(pre *):not(code):not(code *):not(kbd):not(samp):not(svg):not(svg *):not([class*="icon" i]):not(i) {
          font-family: "Vazirmatn", "Vazir", Tahoma, sans-serif !important;
        }`;
      (document.head || document.documentElement).appendChild(s);
    }
  } finally { if (vc) vc.end(); }
})();
