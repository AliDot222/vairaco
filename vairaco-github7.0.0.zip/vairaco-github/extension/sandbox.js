// vairaco — syntax checker. Runs in a manifest "sandbox" page (the only extension context where compiling a string is allowed).
// It only COMPILES the code with new Function (never calls it), so nothing the user wrote is executed here.
addEventListener('message', e => {
  const { id, code } = e.data || {};
  let res = { ok: true };
  try { new Function(String(code)); } catch (err) { res = { ok: false, msg: String(err && err.message || err) }; }
  e.source.postMessage({ id, ...res }, '*');
});
