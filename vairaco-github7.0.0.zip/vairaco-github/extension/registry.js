// فهرست اسکریپت‌ها؛ توسط tools/build-run.mjs ساخته می‌شود (دستی ویرایش نکنید)
export const SCRIPTS = [
 {
  "id": "RTL",
  "title": "RTL",
  "kind": "rtl",
  "builtin": true
 },
 {
  "id": "Vazir",
  "title": "Vazir",
  "file": "vazir.js",
  "desc": "فونت وزیر روی کل صفحه",
  "builtin": true
 },
 {
  "id": "FONT17PX",
  "title": "FONT17PX",
  "file": "font17px.js",
  "sites": [],
  "sticky": false,
  "builtin": true
 },
 {
  "id": "GPT-Dev",
  "title": "GPT-Dev",
  "file": "gpt-dev.js",
  "sites": [
   "chatgpt.com"
  ],
  "sticky": false,
  "builtin": true
 },
 {
  "id": "COPILOT_V2",
  "title": "COPILOT_V2",
  "file": "copilot_v2.js",
  "sites": [
   "copilot.microsoft.com"
  ],
  "sticky": true,
  "builtin": true
 },
 {
  "id": "G-A-P GPT",
  "title": "G-A-P GPT",
  "file": "gap-gpt.js",
  "sites": [],
  "sticky": false,
  "builtin": true
 },
 {
  "id": "Gemini",
  "title": "Gemini",
  "file": "gemini.js",
  "sites": [
   "gemini.google.com"
  ],
  "sticky": true,
  "builtin": true
 },
 {
  "id": "GPT--MATH",
  "title": "GPT--MATH",
  "file": "gpt-math.js",
  "sites": [],
  "sticky": false,
  "builtin": true
 },
 {
  "id": "Claude-AI",
  "title": "Claude-AI",
  "file": "claude.js",
  "sites": [
   "claude.ai"
  ],
  "sticky": true,
  "builtin": true
 },
 {
  "id": "Google-AI-Studio",
  "title": "Google AI Studio",
  "file": "google-ai-studio.js",
  "sites": [
   "aistudio.google.com"
  ],
  "sticky": false,
  "builtin": true
 },
 {
  "id": "DeepSeek",
  "title": "DeepSeek",
  "file": "deepseek.js",
  "sites": [
   "chat.deepseek.com"
  ],
  "sticky": false,
  "builtin": true
 },
 {
  "id": "a",
  "title": "a",
  "file": "a.js",
  "sites": [
   "(optional)",
   "chat.example.com"
  ],
  "sticky": false,
  "builtin": false
 }
];
