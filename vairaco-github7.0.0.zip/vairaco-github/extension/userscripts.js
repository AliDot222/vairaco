// vairaco — "drop a file in my-scripts/ and it just works".
// The popup scans the extension's my-scripts/ folder (live, no build, no reload), parses optional header comments
// and stores the list so the background worker can build the right-click menu and auto-apply rules.
//   // @title Pretty name     // @sites chat.example.com, other.com     // @sticky
export const USER_DIR = 'my-scripts';

const listDir = () => new Promise(resolve => {
  if (!chrome.runtime.getPackageDirectoryEntry) return resolve([]);
  chrome.runtime.getPackageDirectoryEntry(root => root.getDirectory(USER_DIR, {}, dir => {
    const out = [], rd = dir.createReader();
    const more = () => rd.readEntries(es => { if (!es.length) return resolve(out); es.forEach(e => e.isFile && out.push(e.name)); more(); }, () => resolve(out));
    more();
  }, () => resolve([])));
});

export async function scanUserScripts(staticIds) {
  const names = (await listDir()).filter(n => /\.js$/i.test(n)).sort((a, b) => a.localeCompare(b));
  const list = [];
  for (const file of names) {
    const id = file.replace(/\.js$/i, '');
    if (staticIds.has(id)) continue;                    // never shadow a built-in script
    let head = '', bad = null;
    try {
      const txt = await (await fetch(chrome.runtime.getURL(USER_DIR + '/' + encodeURIComponent(file)))).text();
      head = txt.split('\n').slice(0, 10).join('\n');
      if (/^\s*(export|import)\s/m.test(txt)) bad = 'module';   // classic scripts only (see my-scripts/README.txt)
    } catch { bad = 'read'; }
    const tag = n => { const m = head.match(new RegExp('^\\s*//\\s*@' + n + '\\b[ \\t]*(.*)$', 'm')); return m ? m[1].trim() : null; };
    list.push({ id, title: tag('title') || id, file, sites: (tag('sites') || '').split(/[,\s]+/).filter(Boolean), sticky: tag('sticky') !== null, bad });
  }
  return list;
}

// Scan + save (only when something changed, so the menu is rebuilt only when needed)
export async function syncUserScripts(staticIds) {
  const list = await scanUserScripts(staticIds);
  const { userScripts } = await chrome.storage.local.get('userScripts');
  if (JSON.stringify(userScripts || []) !== JSON.stringify(list)) await chrome.storage.local.set({ userScripts: list });
  return list;
}
