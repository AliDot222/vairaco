export function ResetStyles() {
  (function () {
    try {
      // remove injected font links
      document.querySelectorAll(
        'link[href*="vazir"], link[href*="vazirmatn"], link[href*="iransans"], link[href*="fira_code"], link[href*="firacode"], link[href*="fira-code"], #claude-fa-link, #claude-fa-link2, #claude-fa-link3, #fa-font-link'
      ).forEach(n => n.remove());

      // remove injected styles
      document.querySelectorAll('style').forEach(s => {
        const txt = s.textContent || "";
        if (
          s.id === 'tm-persian-font-style' ||
          s.id === 'claude-fa-style' ||                 // 👈 ریست اختصاصی استایل کلاد
          s.id === 'fa-dir-style' ||
          txt.includes('Vazir') || txt.includes('Vazirmatn') ||
          txt.includes('IranSans') || txt.includes('IRANSans') ||
          txt.includes('Fira Code') ||
          txt.includes('tm-persian-font-applied') ||
          txt.includes('.custom-rtl') ||
          txt.includes('unicode-bidi: plaintext') ||
          txt.includes('mjx-container') ||
          txt.includes('font-size: 20px') ||
          txt.includes('box-content') ||                // 👈 پاک‌سازی استایل باکس پرامپت کلاد
          txt.includes('language-')                      // 👈 پاک‌سازی استایل بلاک کد کلاد
        ) {
          s.remove();
        }
      });

      // remove inline font-size styles
      document.querySelectorAll('body *').forEach(el => {
        if (el.style.fontSize === '20px') {
          el.style.fontSize = ''; // reset to default
        }
      });


      // remove classes/attributes
      document.documentElement.classList.remove('custom-rtl', 'tm-persian-font-applied');
      if (document.documentElement.getAttribute('lang') === 'fa') {
        document.documentElement.removeAttribute('lang');
      }

      // try to clean iframes
      document.querySelectorAll('iframe').forEach(fr => {
        try {
          const doc = fr.contentDocument;
          if (!doc) return;
          doc.querySelectorAll('#tm-persian-font-style, style').forEach(s => {
            const txt = s.textContent || "";
            if (
              s.id === 'tm-persian-font-style' ||
              txt.includes('tm-persian-font-applied') ||
              txt.includes('IranSans') || txt.includes('Vazir') ||
              txt.includes('Vazirmatn') || txt.includes('font-size: 20px') // ✅ iframe check
            ) s.remove();
          });
          doc.querySelectorAll('.tm-persian-font-applied').forEach(el => el.classList.remove('tm-persian-font-applied'));
        } catch (e) {}
      });

      console.clear();
      console.log('✅ ResetStyles: hame taghirat (font, style, class) pak shod');
    } catch (e) {
      console.error('Reset Styles failed:', e);
    }
  })();
}
