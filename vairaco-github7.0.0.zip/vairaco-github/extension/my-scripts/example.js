// @title Example (delete me)
// Shows how a dropped script looks. Outlines the page body; "Reset Styles" removes it.
document.body.style.outline = '3px dashed #14b8a6';
