vairaco — your own scripts
==========================
Drop a file  name.js  into this folder, then click the vairaco icon:
it appears in the popup as "name" (no .js) and in the right-click menu. No build, no reload.
Delete the file and it disappears the same way.

- Write plain code (no  export / import ). Anything you change in the page is tracked, so "Reset Styles" undoes it.
- Optional header comments (first 10 lines):
      // @title Pretty name
      // @sites chat.example.com, other.com      (adds it to "Suggested rules")
      // @sticky                                  (page reloads after Reset)
- Keep this README.txt; only *.js files are loaded.
