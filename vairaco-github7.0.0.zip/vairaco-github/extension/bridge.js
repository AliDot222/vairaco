// ارتباط پاپ‌آپ با پل محلی (tools/bridge.mjs): ذخیره در src-scripts + اجرای build.
// اگر پل بالا نباشد، همه‌ی توابع «قطع» برمی‌گردانند و پاپ‌آپ به رفتار قبلی (ذخیره در مرورگر) برمی‌گردد.
const BASE = 'http://127.0.0.1:47654';

async function call(path, body, ms = 30000) {
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), ms);
  try {
    const r = await fetch(BASE + path, {
      method: body ? 'POST' : 'GET',
      headers: body ? { 'Content-Type': 'application/json' } : undefined,
      body: body ? JSON.stringify(body) : undefined,
      signal: ctl.signal,
      cache: 'no-store',
    });
    if (!r.ok) throw new Error('bridge HTTP ' + r.status);
    return await r.json();
  } finally { clearTimeout(timer); }
}

// اتصال کوتاه برای نمایش وضعیت (پاپ‌آپ نباید منتظر بماند)
export const ping = () => call('/status', null, 800).then(x => !!(x && x.ok)).catch(() => false);
export const save = (name, code, remove) => call('/save', { name, code, remove: remove || undefined });
export const remove = name => call('/delete', { name });
export const build = () => call('/build');
export const watch = on => call('/watch', { on: !!on });
