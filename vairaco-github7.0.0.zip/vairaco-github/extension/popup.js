import { runScript, BY_ID, userScriptsOk, parseMeta, frozenIds, clearGuard } from './inject.js';
import { SCRIPTS } from './registry.js';
import { UPDATE_URL } from './config.js';
import { syncUserScripts } from './userscripts.js';
import { getDir, setDir, pickDir, ensureWrite, writeScript, removeScript } from './diskfs.js';
import { t, setLang, getLang, guessLang, applyI18n, LANGS } from './i18n.js';
import { normalizeDomain, matchHost, loadRules, saveRules, newRuleId } from './rules.js';
import { ping as bridgePing, save as bridgeSave, build as bridgeBuild, watch as bridgeWatch, remove as bridgeRemove } from './bridge.js';

const $ = id => document.getElementById(id);
const show = (id, on = true) => $(id).classList.toggle('hidden', !on);
const setMsg = (id, t, ok = false) => { $(id).textContent = t || ''; $(id).classList.toggle('ok', ok); };
const store = (k) => chrome.storage.local.get(k);
const CUR = chrome.runtime.getManifest().version;

// ---------- تب‌ها ----------
function openTab(name) {
  if (!document.getElementById('tab-' + name)) name = 'rules';
  document.querySelectorAll('.tabs button').forEach(b => b.classList.toggle('on', b.dataset.tab === name));
  document.querySelectorAll('.panel').forEach(p => p.classList.toggle('on', p.id === 'tab-' + name));
  chrome.storage.local.set({ lastTab: name });
  if (name === 'edit' && typeof checkUs === 'function') checkUs();
  if (name === 'edit' && typeof refreshBridge === 'function') refreshBridge();
}
document.querySelectorAll('.tabs button').forEach(b => { b.onclick = () => openTab(b.dataset.tab); });

// ---------- GitHub link ----------
const openUpdates = () => chrome.tabs.create({ url: UPDATE_URL });
$('btn-updates').onclick = openUpdates;

// ---------- اسکریپت‌ها (همه لوکال و رایگان) ----------
const STATIC = SCRIPTS.map(s => ({ id: s.id, title: s.title, sites: s.sites || [] }));
const IN_TAB = new URLSearchParams(location.search).has('tab');
let DIR = null;
let BRIDGE = false, WATCHING = false;   // پل محلی (tools/bridge.mjs): ذخیره در src-scripts + build
let AVAILABLE = STATIC, ACTIVE = null, RULES = [], BAD = [], FOLDER = [], USERCODE = {}, OVERRIDES = {};
function rebuildAvailable() {   // داخلی + فایل‌های پوشه‌ی my-scripts + اسکریپت‌های ساخته‌شده در ویرایشگر
  const have = new Set(STATIC.map(s => s.id));
  const out = [...STATIC];
  for (const u of FOLDER) if (!u.bad && !have.has(u.id)) { have.add(u.id); out.push({ id: u.id, title: u.title, sites: u.sites }); }
  for (const [id, c] of Object.entries(USERCODE)) if (!have.has(id)) { have.add(id); const m = parseMeta(c.code); out.push({ id, title: m.title || id, sites: m.sites }); }
  AVAILABLE = out;
}
const infoOf = id => AVAILABLE.find(a => a.id === id);
const runScriptById = (tabId, id) => runScript(tabId, id);
const explain = e => t('runFail', e && e.message ? e.message : t('noAccess'));

function makeChip(id, opts = {}) {
  const info = infoOf(id);
  const el = document.createElement('span');
  el.className = 'chip' + (info ? '' : ' locked');
  const label = document.createElement('span');
  label.textContent = (info ? '' : '🔒 ') + (info ? info.title : id);
  el.dataset.id = id;
  el.append(label);
  if (!info) el.title = t('missing');
  if (info) {
    el.draggable = true;
    el.addEventListener('dragstart', e => {
      e.dataTransfer.setData('text/plain', JSON.stringify({ id, from: opts.from || null }));
      e.dataTransfer.effectAllowed = 'copyMove';
    });
  }
  if (opts.onRemove) {
    const x = document.createElement('button'); x.className = 'x'; x.type = 'button'; x.textContent = '×'; x.title = t('removeSite');
    x.onclick = opts.onRemove; el.append(x);
  }
  return el;
}

// ---------- تب «اسکریپت‌ها» (اجرای دستی) ----------
function renderScripts() {
  $('userHint').textContent = t('userHint') + (BAD.length ? '  ⚠ ' + t('userBad', BAD.join(', ')) : '');
  $('scriptList').innerHTML = '';
  AVAILABLE.forEach(a => {
    const b = document.createElement('button'); b.className = 'chip btnchip'; b.type = 'button'; b.textContent = a.title;
    b.onclick = async () => {
      if (!ACTIVE) return setMsg('msg-scripts', t('tabNoAccess'));
      try { await runScriptById(ACTIVE.id, a.id); setMsg('msg-scripts', t('applied', a.title), true); }
      catch (e) { setMsg('msg-scripts', explain(e)); }
    };
    $('scriptList').append(b);
  });
}
$('btn-reset').onclick = async () => {
  if (!ACTIVE) return setMsg('msg-scripts', t('tabNoAccess'));
  const r = await chrome.runtime.sendMessage({ type: 'reset', tabId: ACTIVE.id });
  setMsg('msg-scripts', r && r.ok ? (r.reloaded ? t('resetReload') : t('resetDone')) : t('resetNo'), !!(r && r.ok));
};

// ---------- تب «قوانین سایت» ----------
let saveTimer = null;
function persist() { saveRules(RULES); }   // فوری ذخیره می‌شود (پاپ‌آپ ممکن است بلافاصله بسته شود)

function activeHost() {
  try { const u = new URL(ACTIVE.url); return /^https?:$/.test(u.protocol) ? u.hostname.toLowerCase() : null; } catch { return null; }
}
async function applyNow(rule, id) {   // اگر همین الان روی همان سایت هستید، اسکریپتِ تازه‌اضافه‌شده فوراً اعمال شود
  const h = ACTIVE && activeHost();
  if (!h || rule.enabled === false || !rule.domain || !matchHost(h, rule.domain)) return;
  try { await runScriptById(ACTIVE.id, id); setMsg('msg-rules', t('appliedHere'), true); }
  catch (e) { if (e.message !== 'NOT_AVAILABLE') setMsg('msg-rules', explain(e)); }
}
function addToRule(rule, id, from, beforeId) {
  const had = rule.scripts.includes(id);
  if (had) rule.scripts = rule.scripts.filter(s => s !== id);      // جابجایی = تغییر ترتیب اجرا
  const at = beforeId ? rule.scripts.indexOf(beforeId) : -1;
  if (at >= 0) rule.scripts.splice(at, 0, id); else rule.scripts.push(id);
  if (from && from !== rule.id) { const src = RULES.find(x => x.id === from); if (src) src.scripts = src.scripts.filter(s => s !== id); }
  persist(); renderRules(); if (!had) applyNow(rule, id);
}

function renderPalette() {
  $('palette').innerHTML = '';
  AVAILABLE.forEach(a => $('palette').append(makeChip(a.id)));
  show('btn-suggest', AVAILABLE.some(a => a.sites && a.sites.length));
}

function renderRules() {
  const list = $('ruleList');
  list.innerHTML = '';
  show('rulesEmpty', RULES.length === 0);
  RULES.forEach(r => {
    const card = document.createElement('div'); card.className = 'rule' + (r.enabled === false ? ' off' : ''); card.dataset.id = r.id;

    const head = document.createElement('div'); head.className = 'rhead';
    const inp = document.createElement('input'); inp.className = 'dom'; inp.type = 'text'; inp.placeholder = t('sitePh'); inp.value = r.domain || '';
    inp.onchange = () => {
      const raw = inp.value.trim();
      if (!raw) { r.domain = ''; inp.classList.remove('bad'); persist(); return; }
      const d = normalizeDomain(raw);
      if (!d) { inp.classList.add('bad'); setMsg('msg-rules', t('badDomain')); return; }
      inp.classList.remove('bad'); setMsg('msg-rules', ''); r.domain = d; inp.value = d; persist();
    };
    const sw = document.createElement('label'); sw.className = 'sw'; sw.title = t('toggle');
    const cb = document.createElement('input'); cb.type = 'checkbox'; cb.checked = r.enabled !== false;
    cb.onchange = () => { r.enabled = cb.checked; persist(); renderRules(); };
    const knob = document.createElement('span'); sw.append(cb, knob);
    const del = document.createElement('button'); del.className = 'btn red small'; del.type = 'button'; del.textContent = t('delSite');
    del.onclick = () => { RULES = RULES.filter(x => x.id !== r.id); persist(); renderRules(); };
    head.append(inp, sw, del);

    const drop = document.createElement('div'); drop.className = 'drop';
    if (!r.scripts.length) { const h = document.createElement('span'); h.className = 'hint'; h.textContent = t('dropHint'); drop.append(h); }
    r.scripts.forEach(id => drop.append(makeChip(id, {
      from: r.id,
      onRemove: () => { r.scripts = r.scripts.filter(s => s !== id); persist(); renderRules(); }
    })));
    drop.addEventListener('dragover', e => { e.preventDefault(); drop.classList.add('over'); });
    drop.addEventListener('dragleave', () => drop.classList.remove('over'));
    drop.addEventListener('drop', e => {
      e.preventDefault(); drop.classList.remove('over');
      try { const d = JSON.parse(e.dataTransfer.getData('text/plain')); if (d && typeof d.id === 'string') { const c = e.target.closest && e.target.closest('.chip'); addToRule(r, d.id, d.from, c && c.dataset.id !== d.id ? c.dataset.id : null); } } catch { /* داده‌ی نامربوط */ }
    });

    // جایگزین بدون درگ (موبایل/دسترسی‌پذیری)
    const sel = document.createElement('select'); sel.style.marginTop = '8px';
    const o0 = document.createElement('option'); o0.value = ''; o0.textContent = t('addScript'); sel.append(o0);
    AVAILABLE.filter(a => !r.scripts.includes(a.id)).forEach(a => { const o = document.createElement('option'); o.value = a.id; o.textContent = a.title; sel.append(o); });
    sel.onchange = () => { if (sel.value) addToRule(r, sel.value, null); };

    card.append(head, drop, sel);
    list.append(card);
  });
}

function addRule(domain) {
  if (domain && RULES.some(r => r.domain === domain)) { setMsg('msg-rules', t('dup')); return; }
  if (RULES.length >= 100) { setMsg('msg-rules', t('max100')); return; }
  RULES.unshift({ id: newRuleId(), domain: domain || '', scripts: [], enabled: true });
  setMsg('msg-rules', ''); persist(); renderRules();
  if (!domain) { const i = document.querySelector('.rule .dom'); if (i) i.focus(); }
}
$('btn-add-rule').onclick = () => addRule('');
$('btn-add-current').onclick = () => { const h = ACTIVE && activeHost(); const d = h && normalizeDomain(h); if (d) addRule(d); else setMsg('msg-rules', t('notNormal')); };
$('btn-suggest').onclick = () => {
  let added = 0;
  AVAILABLE.forEach(a => (a.sites || []).forEach(site => {
    const d = normalizeDomain(site); if (!d) return;
    let r = RULES.find(x => x.domain === d);
    if (!r) { r = { id: newRuleId(), domain: d, scripts: [], enabled: true }; RULES.unshift(r); }
    if (!r.scripts.includes(a.id)) { r.scripts.push(a.id); added++; }
  }));
  persist(); renderRules(); setMsg('msg-rules', added ? t('sugAdded', added) : t('sugNone'), !!added);
};

// ---------- تب «منوی راست‌کلیک» ----------
let MENU = null, SEEN = [];     // MENU: null = همه نمایش داده می‌شوند؛ آرایه = فقط همین‌ها به همین ترتیب
const materialize = () => { if (MENU === null) MENU = AVAILABLE.map(a => a.id); };
function saveMenu() { chrome.storage.local.set({ menuScripts: MENU }); }
function menuAdd(id, beforeId) {
  materialize();
  MENU = MENU.filter(x => x !== id);
  const at = beforeId ? MENU.indexOf(beforeId) : -1;
  if (at >= 0) MENU.splice(at, 0, id); else MENU.push(id);
  saveMenu(); renderMenuTab();
}
function renderMenuTab() {
  const list = MENU === null ? AVAILABLE.map(a => a.id) : MENU;
  const drop = $('menuDrop'); drop.innerHTML = '';
  $('menuCount').textContent = MENU === null ? t('menuAllCount', list.length) : '(' + list.filter(id => infoOf(id)).length + ')';
  if (!list.length) { const h = document.createElement('span'); h.className = 'hint'; h.textContent = t('menuEmpty'); drop.append(h); }
  list.forEach(id => drop.append(makeChip(id, {
    from: 'menu',
    onRemove: () => { materialize(); MENU = MENU.filter(x => x !== id); saveMenu(); renderMenuTab(); }
  })));
  drop.ondragover = e => { e.preventDefault(); drop.classList.add('over'); };
  drop.ondragleave = () => drop.classList.remove('over');
  drop.ondrop = e => {
    e.preventDefault(); drop.classList.remove('over');
    try {
      const d = JSON.parse(e.dataTransfer.getData('text/plain'));
      if (d && typeof d.id === 'string') { const c = e.target.closest && e.target.closest('.chip'); menuAdd(d.id, c && c.dataset.id !== d.id ? c.dataset.id : null); }
    } catch { /* داده‌ی نامربوط */ }
  };
  const q = $('menuSearch').value.trim().toLowerCase();
  const inMenu = new Set(list);
  $('palette2').innerHTML = '';
  AVAILABLE.filter(a => !q || a.title.toLowerCase().includes(q) || a.id.toLowerCase().includes(q) || (a.sites || []).some(x => String(x).toLowerCase().includes(q))).forEach(a => {
    const c = makeChip(a.id);
    if (inMenu.has(a.id)) c.classList.add('inmenu');
    if (!SEEN.includes(a.id)) { c.classList.add('new'); c.dataset.new = { fa: 'جدید', ar: 'جديد', en: 'new' }[getLang()]; }
    c.onclick = () => { if (!inMenu.has(a.id)) menuAdd(a.id, null); };
    $('palette2').append(c);
  });
}
$('menuSearch').oninput = renderMenuTab;
$('btn-menu-all').onclick = () => { MENU = null; saveMenu(); renderMenuTab(); setMsg('msg-menu', t('menuAllMsg'), true); };
$('btn-menu-clear').onclick = () => { MENU = []; saveMenu(); renderMenuTab(); setMsg('msg-menu', ''); };
async function loadMenu() {
  const o = await store(['menuScripts', 'seenScripts']);
  MENU = Array.isArray(o.menuScripts) ? o.menuScripts : null; SEEN = Array.isArray(o.seenScripts) ? o.seenScripts : [];
}
async function markSeen() {   // برچسب «جدید» فقط تا وقتی تب منو را ببینید می‌ماند
  const ids = AVAILABLE.map(a => a.id);
  if (ids.some(id => !SEEN.includes(id))) { SEEN = ids; await chrome.storage.local.set({ seenScripts: ids }); }
}


async function refreshUi() { renderFolder(); await loadMenu(); renderScripts(); renderPalette(); renderRules(); renderMenuTab(); renderEdList(); }

function mountLang(cur) {
  const sel = $('lang'); sel.innerHTML = '';
  for (const [k, v] of Object.entries(LANGS)) { const o = document.createElement('option'); o.value = k; o.textContent = v; sel.append(o); }
  sel.value = cur;
  sel.onchange = async () => { await chrome.storage.local.set({ lang: sel.value }); setLang(sel.value); applyI18n(); $('ver').textContent = t('ver', CUR); await refreshUi(); };
}
async function init() {
  const { lang } = await store('lang'); const L = LANGS[lang] ? lang : guessLang();
  setLang(L); applyI18n(); mountLang(L);
  $('ver').textContent = t('ver', CUR);
  const [{ lastTab }, tabs, rules] = await Promise.all([store('lastTab'), chrome.tabs.query({ active: true, currentWindow: true }), loadRules()]);
  RULES = rules;
  const user = await syncUserScripts(new Set(STATIC.map(s => s.id))).catch(() => []);   // my-scripts: فهرست زنده، بدون build
  FOLDER = user; BAD = user.filter(u => u.bad).map(u => u.id);
  const st = await store(['userCode', 'overrides']); USERCODE = st.userCode || {}; OVERRIDES = st.overrides || {};
  rebuildAvailable();
  ACTIVE = tabs[0] ? { id: tabs[0].id, url: tabs[0].url || '' } : null;
  const h = ACTIVE && activeHost(); const d = h && normalizeDomain(h);
  $('curSite').textContent = d ? '(' + d + ')' : '';
  $('btn-add-current').disabled = !d;
  if (IN_TAB) document.documentElement.classList.add('tabmode');
  DIR = await getDir(); renderFolder();
  openTab(new URLSearchParams(location.search).get('tab') || lastTab || 'rules');
  await refreshUi();
  refreshBridge();
}
init();

// ---------- خروجی / ورودی تنظیمات (برای انتقال به پروفایل‌های دیگر) ----------
function exportRules() {
  const data = { app: 'vairaco-rules', v: 1, rules: RULES.map(r => ({ domain: r.domain, scripts: r.scripts, enabled: r.enabled !== false })) };
  return JSON.stringify(data, null, 1);
}
$('btn-export').onclick = async () => {
  const txt = exportRules();
  try { await navigator.clipboard.writeText(txt); setMsg('msg-rules', t('copied'), true); }
  catch { $('ioBox').classList.remove('hidden'); $('ioText').value = txt; $('ioText').select(); setMsg('msg-rules', t('copyManual')); }
};
$('btn-import').onclick = () => { $('ioBox').classList.toggle('hidden'); $('ioText').value = ''; $('ioText').focus(); };
$('btn-import-go').onclick = () => {
  let d;
  try { d = JSON.parse($('ioText').value); } catch { return setMsg('msg-rules', t('badText')); }
  if (!d || d.app !== 'vairaco-rules' || !Array.isArray(d.rules)) return setMsg('msg-rules', t('notOurs'));
  let n = 0;
  for (const x of d.rules) {
    const dom = normalizeDomain(x && x.domain); if (!dom || !Array.isArray(x.scripts)) continue;
    const scripts = [...new Set(x.scripts.filter(s => typeof s === 'string'))].slice(0, 50);
    const ex = RULES.find(r => r.domain === dom);
    if (ex) { ex.scripts = scripts; ex.enabled = x.enabled !== false; }
    else if (RULES.length < 100) RULES.push({ id: newRuleId(), domain: dom, scripts, enabled: x.enabled !== false });
    else continue;
    n++;
  }
  persist(); renderRules(); $('ioBox').classList.add('hidden');
  setMsg('msg-rules', t('imported', n), true);
};

// ---------- تب «ویرایشگر»: ساخت / ویرایش / حذف اسکریپت ----------
let ED = null;   // { id, kind: 'new' | 'user' | 'builtin' }
const NAME_OK = n => /^[^\n\r/\\]{1,40}$/.test(n) && n.trim() === n;
const staticSrc = async id => {   // متن قابل‌ویرایش اسکریپت داخلی
  const s = SCRIPTS.find(x => x.id === id);
  if (s.kind === 'rtl') return (await (await fetch(chrome.runtime.getURL('scripts/rtl.js'))).text()).replace(/export\s+function/, 'function') + '\n;RTL();\n';
  return (await (await fetch(chrome.runtime.getURL('run/' + s.file))).text());
};
const saveStore = o => chrome.storage.local.set(o);
function renderEdList() {
  const box = $('edList'); box.innerHTML = '';
  AVAILABLE.forEach(a => {
    const isF = FOLDER.some(f => f.id === a.id);
    if (isF && MODE() !== 'live') return;            // فایل‌های پوشه فقط وقتی پوشه‌ی my-scripts وصل است در ویرایشگر باز می‌شوند
    const c = document.createElement('span'); c.className = 'chip'; c.dataset.id = a.id;
    c.textContent = a.title + (OVERRIDES[a.id] !== undefined ? t('edEdited') : '') + (isF ? ' 📁' : '');
    if (ED && ED.id === a.id) c.classList.add('inmenu');
    c.onclick = () => openEditor(a.id);
    box.append(c);
  });
}
function renderLoopWarn() { $('loopWarn').textContent = '⚠ ' + t('edLoop'); }
async function checkUs() { renderLoopWarn(); const ok = await userScriptsOk(); $('usWarn').classList.toggle('hidden', ok); $('usWarn').textContent = ok ? '' : t('edUsOff'); return ok; }
async function openEditor(id) {
  setMsg('msg-edit', '');
  const s = SCRIPTS.find(x => x.id === id);
  const isStatic = !!s && s.builtin !== false;          // فقط اسکریپت‌های رسمی پروژه (scripts.json)
  const ff = !isStatic && FOLDER.find(f => f.id === id);
  ED = { id, kind: isStatic ? 'builtin' : 'user', disk: !!ff };
  $('edCard').classList.remove('hidden');
  $('edName').value = id; $('edName').readOnly = isStatic;
  let code = '';
  if (isStatic) code = OVERRIDES[id] !== undefined ? OVERRIDES[id] : await staticSrc(id);
  else if (ff) code = await (await fetch(chrome.runtime.getURL('my-scripts/' + encodeURIComponent(ff.file)))).text();
  else {
    let disk = null;   // منبع حقیقت: فایل خام src-scripts (اگر پوشه وصل است)، نه فایل wrap‌شده‌ی run/
    if (DIR && MODE() === 'src') { try { const fh = await DIR.getFileHandle(id + '.js'); disk = await (await fh.getFile()).text(); } catch { /* فایلی نیست */ } }
    code = disk !== null ? disk : (USERCODE[id] ? USERCODE[id].code : '');
  }
  $('edCode').value = code;
  const del = $('btn-ed-del'); del.classList.toggle('hidden', isStatic); del.textContent = t('edDelete'); del.dataset.sure = '';
  $('btn-ed-restore').classList.toggle('hidden', !(isStatic && OVERRIDES[id] !== undefined));
  renderEdList(); checkUs();
  if ((await frozenIds()).includes(id)) setMsg('msg-edit', t('edFroze'));
}
$('btn-ed-new').onclick = () => {
  ED = { id: null, kind: 'new' }; setMsg('msg-edit', '');
  $('edCard').classList.remove('hidden'); $('edName').value = ''; $('edName').readOnly = false; $('edCode').value = t('edTemplate');
  $('btn-ed-del').classList.add('hidden'); $('btn-ed-restore').classList.add('hidden');
  renderEdList(); checkUs(); $('edName').focus();
};
$('edCode').addEventListener('keydown', e => {   // Tab = دو فاصله (به‌جای رفتن به کنترل بعدی)
  if (e.key !== 'Tab' || e.shiftKey) return;
  e.preventDefault(); const a = e.target, p = a.selectionStart; a.value = a.value.slice(0, p) + '  ' + a.value.slice(a.selectionEnd); a.selectionStart = a.selectionEnd = p + 2;
});
const ids = () => new Set(AVAILABLE.map(a => a.id));
async function afterEdit() { rebuildAvailable(); await refreshUi(); }
async function renameEverywhere(from, to) {
  let ch = false;
  RULES.forEach(r => { const i = r.scripts.indexOf(from); if (i >= 0) { r.scripts[i] = to; ch = true; } });
  if (ch) persist();
  if (Array.isArray(MENU) && MENU.includes(from)) { MENU = MENU.map(x => x === from ? to : x); saveMenu(); }
}
async function removeEverywhere(id) {
  RULES.forEach(r => { r.scripts = r.scripts.filter(x => x !== id); }); persist();
  if (Array.isArray(MENU)) { MENU = MENU.filter(x => x !== id); saveMenu(); }
}
// بررسی نحو بدون اجرا: کروم در صفحه‌ی افزونه eval را نمی‌دهد، پس کد را در صفحه‌ی sandbox فقط «کامپایل» می‌کنیم (اجرا نمی‌شود)
let synSeq = 0;
function checkSyntax(code) {
  return new Promise(resolve => {
    const f = $('syntaxFrame'), id = ++synSeq;
    const done = r => { removeEventListener('message', on); clearTimeout(tm); resolve(r); };
    const on = e => { if (e.source === f.contentWindow && e.data && e.data.id === id) done(e.data); };
    const tm = setTimeout(() => done({ ok: true }), 1500);   // اگر sandbox در دسترس نبود، ذخیره را نبند
    addEventListener('message', on);
    try { f.contentWindow.postMessage({ id, code }, '*'); } catch { done({ ok: true }); }
  });
}
let diskNote = '';

// ---------- پل محلی (tools/bridge.mjs): ذخیره در src-scripts + اجرای build ----------
const tail = s => { s = String(s || '').replace(/\s+/g, ' ').trim(); return s.length > 320 ? '…' + s.slice(-320) : s; };
function renderBridge() {
  const el = $('bridgeState'); if (!el) return;
  el.textContent = BRIDGE ? t('edBridgeOn') : t('edBridgeOff');
  el.classList.toggle('ok', BRIDGE);
  $('btn-ed-watch').textContent = WATCHING ? t('edWatchStop') : t('edWatchStart');
}
async function refreshBridge() {
  BRIDGE = await bridgePing();
  if (!BRIDGE) WATCHING = false;
  renderBridge();
  return BRIDGE;
}
$('btn-ed-build').onclick = async () => {
  if (!(await refreshBridge())) return setMsg('msg-edit', t('edBuildManual'));
  setMsg('msg-edit', t('edBuilding'));
  try {
    const r = await bridgeBuild();
    setMsg('msg-edit', r.ok ? t('edBuildOk', tail(r.log)) : t('edBuildFail', tail(r.log)), !!r.ok);
  } catch { BRIDGE = false; renderBridge(); setMsg('msg-edit', t('edBridgeDown')); }
};
$('btn-ed-watch').onclick = async () => {
  if (!(await refreshBridge())) return setMsg('msg-edit', t('edBridgeDown'));
  try {
    const r = await bridgeWatch(!WATCHING);
    WATCHING = !!r.watching; renderBridge();
    setMsg('msg-edit', WATCHING ? t('edWatchMsgOn') : t('edWatchMsgOff'), true);
  } catch { BRIDGE = false; renderBridge(); setMsg('msg-edit', t('edBridgeDown')); }
};
// ذخیره در src-scripts + build. خروجی: true = انجام شد یا خطا نمایش داده شد؛ null = پل خطا داد (برگرد به ذخیره‌ی مرورگر)
async function saveToSrc(code) {
  if (ED.kind === 'builtin') {
    const s = SCRIPTS.find(x => x.id === ED.id);
    if (!s || !s.file || s.id === 'Vazir' || s.id === 'RTL') return null;   // فایل منبع قابل‌ساخت ندارد
    try {
      const r = await bridgeSave(s.file.replace(/\.js$/i, ''), code);
      if (!r.ok) { setMsg('msg-edit', t('edBuildFail', tail(r.log))); return true; }
      delete OVERRIDES[ED.id]; await saveStore({ overrides: OVERRIDES });
      $('btn-ed-restore').classList.add('hidden');
      await clearGuard(ED.id); await afterEdit();
      setMsg('msg-edit', t('edSavedSrcBuild', r.file || s.file), true);
      return true;
    } catch { BRIDGE = false; renderBridge(); return null; }
  }
  const name = $('edName').value;
  if (!name.trim()) { setMsg('msg-edit', t('edNeedName')); return true; }
  if (!NAME_OK(name)) { setMsg('msg-edit', t('edBadName')); return true; }
  if (name !== ED.id && ids().has(name)) { setMsg('msg-edit', t('edDup')); return true; }
  if (!/^[A-Za-z0-9._ -]+$/.test(name)) { setMsg('msg-edit', t('edBadSrcName')); return true; }
  try {
    const r = await bridgeSave(name, code, ED.id && ED.id !== name ? ED.id : undefined);
    if (!r.ok) { setMsg('msg-edit', t('edBuildFail', tail(r.log))); return true; }
    if (ED.kind === 'user' && name !== ED.id) { delete USERCODE[ED.id]; await renameEverywhere(ED.id, name); }
    USERCODE[name] = { code }; await saveStore({ userCode: USERCODE });
    ED = { id: name, kind: 'user', disk: false };
    const del = $('btn-ed-del'); del.classList.remove('hidden'); del.textContent = t('edDelete');
    await clearGuard(name); await afterEdit();
    setMsg('msg-edit', t('edSavedSrcBuildReload', r.file || (name + '.js')), true);
    return true;
  } catch { BRIDGE = false; renderBridge(); return null; }
}

async function edSave() {
  if (!ED) return false;
  diskNote = '';
  const code = $('edCode').value;
  const syn = await checkSyntax(code);
  if (!syn.ok) return setMsg('msg-edit', t('edSyntax', syn.msg)), false;

  // پیش‌فرض: اگر پل روشن است، ذخیره مستقیم در src-scripts + build
  if (BRIDGE) { const saved = await saveToSrc(code); if (saved) return saved; }

  if (ED.kind === 'builtin') {
    const orig = await staticSrc(ED.id);
    if (code === orig) delete OVERRIDES[ED.id]; else OVERRIDES[ED.id] = code;
    await saveStore({ overrides: OVERRIDES });
    $('btn-ed-restore').classList.toggle('hidden', OVERRIDES[ED.id] === undefined);
  } else {
    const name = $('edName').value;
    if (!name.trim()) return setMsg('msg-edit', t('edNeedName')), false;
    if (!NAME_OK(name)) return setMsg('msg-edit', t('edBadName')), false;
    if (name !== ED.id && ids().has(name)) return setMsg('msg-edit', t('edDup')), false;
    const mode = MODE();
    if (mode !== 'none' && !FILE_OK(name)) return setMsg('msg-edit', t('edBadFile')), false;
    let wrote = false;
    if (mode !== 'none') {   // ذخیره روی دیسک (پوشه‌ی وصل‌شده)
      if (await ensureWrite(DIR)) {
        try { await writeScript(DIR, name, code); wrote = true; if (name !== ED.id && (ED.disk || mode === 'src')) await removeScript(DIR, ED.id).catch(() => {}); }
        catch (e) { if (ED.disk) return setMsg('msg-edit', t('edDiskFail', e && e.message || '')), false; }
      } else if (ED.disk) return setMsg('msg-edit', t('edNeedPerm')), false;
    }
    if (ED.kind === 'user' && name !== ED.id) { delete USERCODE[ED.id]; await renameEverywhere(ED.id, name); }
    if (mode === 'live' && wrote) delete USERCODE[name]; else USERCODE[name] = { code };   // my-scripts: فایل منبع حقیقت است؛ بقیه: نسخه‌ی مرورگر هم می‌ماند
    await saveStore({ userCode: USERCODE });
    ED = { id: name, kind: 'user', disk: mode === 'live' && wrote };
    if (ED.disk) await rescan();
    const del = $('btn-ed-del'); del.classList.remove('hidden'); del.textContent = t('edDelete');
    diskNote = wrote ? t('edSavedDisk', name + '.js') + (mode === 'src' ? ' ' + t('edNeedBuild') : '') : (mode !== 'none' ? t('edNotDisk') : '');
  }
  await clearGuard(ED.id);
  await afterEdit(); setMsg('msg-edit', diskNote || t('edSaved'), true); return true;
}
$('btn-ed-save').onclick = edSave;
$('btn-ed-run').onclick = async () => {
  if (!(await edSave())) return;
  if (!ACTIVE) return setMsg('msg-edit', t('tabNoAccess'));
  try { await runScriptById(ACTIVE.id, ED.id); setMsg('msg-edit', t('applied', ED.id), true); }
  catch (e) { setMsg('msg-edit', e && e.message === 'USERSCRIPTS_OFF' ? t('edUsFail') : e && e.message === 'SCRIPT_FROZE' ? t('edFroze') : explain(e)); }
};
$('btn-ed-reset').onclick = async () => {
  if (!ACTIVE) return setMsg('msg-edit', t('tabNoAccess'));
  const r = await chrome.runtime.sendMessage({ type: 'reset', tabId: ACTIVE.id }).catch(() => null);
  setMsg('msg-edit', r && r.ok ? (r.reloaded ? t('resetReload') : t('resetDone')) : t('resetNo'), !!(r && r.ok));
};
$('btn-ed-del').onclick = async () => {
  const b = $('btn-ed-del');
  if (!ED || ED.kind !== 'user') return;
  if (b.dataset.sure !== '1') { b.dataset.sure = '1'; b.textContent = t('edDeleteSure'); return; }
  const wasDisk = ED.disk, id = ED.id;
  let bridgeState = '';   // 'ok' | 'fail' | ''
  if (BRIDGE) {   // حذف فایل src-scripts + build از طریق پل
    try {
      const r = await bridgeRemove(id);
      bridgeState = r && r.ok ? 'ok' : 'fail';
      if (bridgeState === 'fail') setMsg('msg-edit', t('edDeletedBuildFail', tail(r && r.log)));
    } catch { BRIDGE = false; renderBridge(); }
  }
  let removedDisk = false;
  if (bridgeState !== 'ok' && DIR && (wasDisk || MODE() === 'src') && (await ensureWrite(DIR))) {
    await removeScript(DIR, id).catch(() => {}); removedDisk = true;
  }
  delete USERCODE[id]; await saveStore({ userCode: USERCODE }); await removeEverywhere(id);
  if (wasDisk) await rescan();
  ED = null; $('edCard').classList.add('hidden'); await afterEdit();
  if (bridgeState === 'ok') setMsg('msg-edit', t('edDeletedBuilt'));
  else if (bridgeState !== 'fail') setMsg('msg-edit', removedDisk ? t('edDeletedBuild') : t('edDeleted')); 
};
$('btn-ed-restore').onclick = async () => {
  if (!ED || ED.kind !== 'builtin') return;
  delete OVERRIDES[ED.id]; await saveStore({ overrides: OVERRIDES });
  $('edCode').value = await staticSrc(ED.id); $('btn-ed-restore').classList.add('hidden');
  await afterEdit(); setMsg('msg-edit', t('edRestored'), true);
};

$('btn-ed-reload').onclick = () => { chrome.runtime.reload(); };   // معادل دکمه‌ی Reload در chrome://extensions؛ تنظیمات و اسکریپت‌ها حفظ می‌شوند

// ---------- ذخیره روی دیسک (پوشه‌ی پروژه) ----------
const MODE = () => !DIR ? 'none' : DIR.name === 'src-scripts' ? 'src' : 'live';
const FILE_OK = n => NAME_OK(n) && !/[<>:"|?*]/.test(n) && !/^\.+$/.test(n);
async function rescan() { FOLDER = await syncUserScripts(new Set(STATIC.map(s => s.id))).catch(() => FOLDER); BAD = FOLDER.filter(u => u.bad).map(u => u.id); rebuildAvailable(); }
function renderFolder() {
  $('btn-ed-folder').textContent = IN_TAB ? t('edFolderBtn') : t('edFolderTab');
  $('edFolderInfo').textContent = !DIR ? t('edFolderNone') : t('edFolderOn', DIR.name) + (MODE() === 'src' ? ' ' + t('edNeedBuild') : '');
}
$('btn-ed-folder').onclick = async () => {
  if (!IN_TAB) { chrome.tabs.create({ url: chrome.runtime.getURL('popup.html?tab=edit') }); window.close(); return; }   // پنجره‌ی انتخاب پوشه در پاپ‌آپ آن را می‌بندد؛ در تب عادی کار می‌کند
  try {
    const h = await pickDir();
    if (h.name !== 'my-scripts' && h.name !== 'src-scripts') return setMsg('msg-edit', t('edFolderWrong'));
    await setDir(h); DIR = h; await ensureWrite(h); await rescan(); await refreshUi(); renderFolder(); setMsg('msg-edit', t('edFolderOk', h.name), true);
  } catch (e) { if (e && e.name !== 'AbortError') setMsg('msg-edit', String(e.message || e)); }
};
