// اجرای اسکریپت‌ها (همه لوکال، از داخل خود افزونه) با ردیاب Reset. هیچ کدی از اینترنت لود نمی‌شود.
import { RTL } from './scripts/rtl.js';
import { SCRIPTS } from './registry.js';

export const BY_ID = new Map(SCRIPTS.map(s => [s.id, s]));
const dirtyKey = tabId => 'dirty_' + tabId;
// اسکریپت‌هایی که Observer / شنونده / حذف المان باقی می‌گذارند: Reset بعدش یک بار تب را رفرش می‌کند تا ردی نماند
export async function isDirty(tabId) { const k = dirtyKey(tabId); return !!(await chrome.storage.session.get(k))[k]; }
export async function clearDirty(tabId) { await chrome.storage.session.remove(dirtyKey(tabId)); }

export async function runRtl(tabId) {
  await chrome.scripting.executeScript({ target: { tabId }, files: ['inject/tracker.js'] });
  return chrome.scripting.executeScript({ target: { tabId }, func: RTL });
}

// id → اجرا روی تب. ترتیب: ردیاب، فونت وزیر لوکال، خودِ اسکریپت (همه در یک تزریق، دنیای ISOLATED، سازگار با CSP)
// ---------- اسکریپت‌های کاربر ----------
// ۱) پوشه‌ی my-scripts (فایل .js؛ فهرستش را پاپ‌آپ در storage.userScripts می‌گذارد)
// ۲) تب «ویرایشگر» پاپ‌آپ: کد در storage.userCode (اسکریپت جدید) و storage.overrides (نسخه‌ی ویرایش‌شده‌ی اسکریپت‌های داخلی)
//    این کدها با chrome.userScripts (دنیای USER_SCRIPT) اجرا می‌شوند، چون کروم اجازه‌ی eval به افزونه نمی‌دهد.
export async function userScriptsOk() {
  try { if (!chrome.userScripts || !chrome.userScripts.execute) return false; await chrome.userScripts.getScripts(); return true; } catch { return false; }
}
export const parseMeta = code => {
  const head = String(code).split('\n').slice(0, 10).join('\n');
  const tag = n => { const m = head.match(new RegExp('^\\s*//\\s*@' + n + '\\b[ \\t]*(.*)$', 'm')); return m ? m[1].trim() : null; };
  return { title: tag('title'), sites: (tag('sites') || '').split(/[,\s]+/).filter(Boolean), sticky: tag('sticky') !== null };
};
export async function loadUserScripts() {
  for (const [id, s] of [...BY_ID]) if (s.user) BY_ID.delete(id);
  const { userScripts, userCode } = await chrome.storage.local.get(['userScripts', 'userCode']);
  for (const u of Array.isArray(userScripts) ? userScripts : []) if (u && !u.bad && !BY_ID.has(u.id)) BY_ID.set(u.id, { ...u, user: true });
  for (const [id, c] of Object.entries(userCode || {})) if (c && typeof c.code === 'string' && !BY_ID.has(id)) { const m = parseMeta(c.code); BY_ID.set(id, { id, title: m.title || id, sites: m.sites, sticky: m.sticky, user: true, editor: true }); }
}

// اجرای کد متنی در دنیای USER_SCRIPT (ردیاب هم همان‌جا تزریق می‌شود تا Reset بتواند برگرداند). wrap: کد خام کاربر بین begin/end
// شبکه‌ی ایمنی حلقه‌ی بی‌نهایت: قبل از اجرا پرچم «در حال اجرا» می‌گذاریم و بعد از پایان برمی‌داریم. اگر تب هنگ کند، پرچم می‌ماند
// و دفعه‌ی بعد این اسکریپت خودکار اجرا نمی‌شود تا هر بار سایت را قفل نکند (با ذخیره‌ی دوباره در ویرایشگر فعال می‌شود).
const GUARD_MS = 20000;
async function guardSet(id, on) {
  if (!id) return;
  const { guard } = await chrome.storage.local.get('guard'); const g = { ...(guard || {}) };
  if (on) g[id] = Date.now(); else delete g[id];
  await chrome.storage.local.set({ guard: g });
}
export async function frozenIds() {
  const { guard } = await chrome.storage.local.get('guard');
  return Object.entries(guard || {}).filter(([, at]) => Date.now() - at > GUARD_MS).map(([id]) => id);
}
export const clearGuard = id => guardSet(id, false);
async function runCode(tabId, code, wrap, id) {
  if (!(await userScriptsOk())) throw new Error('USERSCRIPTS_OFF');
  if (id && (await frozenIds()).includes(id)) throw new Error('SCRIPT_FROZE');
  await chrome.scripting.executeScript({ target: { tabId }, files: ['inject/tracker.js', 'inject/vazir-faces.js'] });   // فونت‌های وزیر برای هر دو دنیا
  const src = wrap ? '(()=>{const vc=globalThis.__vc;if(vc)vc.begin();try{\n' + code + '\n}finally{if(vc)vc.end();}})();' : code;
  await guardSet(id, true);
  try { await chrome.userScripts.execute({ target: { tabId }, world: 'USER_SCRIPT', js: [{ file: 'inject/tracker.js' }, { code: src }] }); }
  finally { await guardSet(id, false); }
}

export async function runScript(tabId, id) {
  if (!BY_ID.has(id)) await loadUserScripts();
  const s = BY_ID.get(id);
  if (!s) throw new Error('NOT_AVAILABLE');
  const { userCode, overrides } = await chrome.storage.local.get(['userCode', 'overrides']);
  if (s.editor && userCode && userCode[id]) await runCode(tabId, userCode[id].code, true, id);
  else if (overrides && typeof overrides[id] === 'string' && await userScriptsOk()) await runCode(tabId, overrides[id], !/__vc/.test(overrides[id]), id);   // نسخه‌ی ویرایش‌شده‌ی اسکریپت داخلی
  else if (s.kind === 'rtl') return runRtl(tabId);
  else {
    const files = s.user ? ['inject/tracker.js', 'inject/vazir-faces.js', 'inject/begin.js', 'my-scripts/' + s.file] : ['inject/tracker.js', 'inject/vazir-faces.js', 'run/' + s.file];
    await chrome.scripting.executeScript({ target: { tabId }, files });
  }
  if (s.sticky) await chrome.storage.session.set({ [dirtyKey(tabId)]: 1 });
}

// برگرداندن همه‌ی تغییرات ثبت‌شده‌ی هر اسکریپتی. خطا نباید ریست را متوقف کند.
export async function undoTracked(tabId) {
  try { await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, func: () => (globalThis.__vc ? globalThis.__vc.undo() : 0) }); } catch (e) { /* صفحه‌ی محافظت‌شده */ }
  try { if (await userScriptsOk()) await chrome.userScripts.execute({ target: { tabId, allFrames: true }, world: 'USER_SCRIPT', js: [{ code: 'globalThis.__vc&&globalThis.__vc.undo()' }] }); } catch (e) { /* دنیای کاربر در این صفحه نیست */ }
}
