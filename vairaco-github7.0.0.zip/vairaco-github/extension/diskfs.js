// vairaco — optional "save my scripts to the project folder on disk".
// An extension cannot write files by itself, so the user links a folder once (File System Access API); the handle is kept in IndexedDB.
// Link  extension/my-scripts  (scripts run instantly, no build)  or  src-scripts  (project source; run `node tools/build-run.mjs` later).
const idb = () => new Promise((res, rej) => { const r = indexedDB.open('vairaco-fs', 1); r.onupgradeneeded = () => r.result.createObjectStore('kv'); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
const kv = async (mode, fn) => { const db = await idb(); return new Promise((res, rej) => { const q = fn(db.transaction('kv', mode).objectStore('kv')); q.onsuccess = () => res(q.result); q.onerror = () => rej(q.error); }); };

export const getDir = () => kv('readonly', s => s.get('dir')).catch(() => null);
export const setDir = h => kv('readwrite', s => (h ? s.put(h, 'dir') : s.delete('dir')));
export const pickDir = () => window.showDirectoryPicker({ id: 'vairaco-scripts', mode: 'readwrite' });   // needs a user gesture, and a full tab (a popup closes when the picker opens)

// Must be called from a click handler (the permission prompt needs a user gesture)
export async function ensureWrite(h) {
  const o = { mode: 'readwrite' };
  try { if ((await h.queryPermission(o)) === 'granted') return true; return (await h.requestPermission(o)) === 'granted'; } catch { return false; }
}
export async function writeScript(h, name, code) {
  const fh = await h.getFileHandle(name + '.js', { create: true });
  const w = await fh.createWritable(); await w.write(code); await w.close();
}
export const removeScript = (h, name) => h.removeEntry(name + '.js');
