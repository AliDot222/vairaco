# Contributing

Thanks for helping RTL users enjoy AI chats!

## Run locally
1. Clone the repo, open `chrome://extensions/`, enable Developer mode, **Load unpacked** → `extension/`.
2. After changing anything in `src-scripts/`, run `node tools/build-run.mjs` and reload the extension.

## Add a translation
Open `extension/i18n.js`, copy the `en` block, translate it, add the language to `LANGS` (and to `RTL_LANGS` if right-to-left). Optionally add `extension/_locales/<code>/messages.json` for the store name/description.

## Quick way to try a script (no build)
Use the popup's **Editor** tab (needs *Allow User Scripts*), or drop `name.js` into `extension/my-scripts/` and click the icon. When it's good, move it to `src-scripts/` to ship it built-in.

## Add or fix a site script
1. Drop `name.js` into `src-scripts/` — that's it. It appears in the popup as **`name`** (no `.js`). `scripts.json` is optional.
2. Run `node tools/build-run.mjs` (or `node tools/build-run.mjs --watch` to rebuild on every change), then press Reload on `chrome://extensions/`.
3. Optional header comments (first 10 lines): `// @title Pretty name`, `// @sites chat.example.com, other.com` (adds it to "Suggested rules"), `// @sticky` (page reloads after Reset).
4. A file may be plain code or contain `export function X() {…}`. A file with a syntax error is skipped with a warning; the rest still build.
5. Changes made by the script are tracked automatically, so *Reset Styles* undoes them.

## Rules
- No new network requests, no remote code, no analytics, no ads.
- Keep fonts local (Vazirmatn only).
- Test on a page with a strict CSP when touching injection code.
