// ساخت فایل‌های اجرایی افزونه از اسکریپت‌های اصلی (بدون هیچ تغییری در خود اسکریپت‌ها).
// اجرا:  node tools/build-run.mjs            (از پوشه‌ی اصلی پروژه)
//        node tools/build-run.mjs --watch    (با هر تغییر/افزودن فایل در src-scripts خودکار دوباره می‌سازد)
//
// ✦ اسکریپت جدید: فقط فایل «name.js» را در src-scripts بگذارید؛ در پاپ‌آپ با نام «name» (بدون .js) ظاهر می‌شود.
//   (نیازی به scripts.json نیست.) تنظیمات اختیاری با کامنت در ۱۰ خط اول فایل:
//     // @title  عنوان دلخواه          // @sites  chat.example.com, other.com          // @sticky
// ورودی: src-scripts/*.js (+ src-scripts/scripts.json)     خروجی: extension/run/*.js و extension/registry.js
//
// اسکریپت‌های قدیمی با «export function X()» → export حذف و X() فراخوانی می‌شود؛ فایل ساده (بدون export) همان‌طور اجرا می‌شود.
// هر اسکریپت بین __vc.begin()/__vc.end() (ردیاب Reset) اجرا می‌شود تا Reset دقیق همه‌چیز را برگرداند.
import { readFileSync, writeFileSync, mkdirSync, readdirSync, unlinkSync, existsSync, watch } from 'node:fs';
import vm from 'node:vm';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const SRC = join(root, 'src-scripts'), OUT = join(root, 'extension', 'run');
mkdirSync(OUT, { recursive: true });
function build() {
const listed = existsSync(join(SRC, 'scripts.json')) ? JSON.parse(readFileSync(join(SRC, 'scripts.json'), 'utf8')) : [];
const list = [...listed];
const used = new Set(['RTL', 'Vazir', ...listed.map(x => x.id)]), usedFiles = new Set(listed.map(x => x.file));
for (const f of readdirSync(SRC).sort()) {                       // فایل‌های جدید که در scripts.json نیستند: خودکار اضافه می‌شوند
  if (!f.endsWith('.js') || usedFiles.has(f)) continue;
  const id = f.slice(0, -3);
  if (!/^[A-Za-z0-9._ -]+$/.test(id) || f === 'vazir.js' || used.has(id)) { console.warn('SKIP ' + f + ' (نام نامعتبر یا تکراری)'); continue; }
  const head = readFileSync(join(SRC, f), 'utf8').split('\n').slice(0, 10).join('\n');
  const tag = n => { const r = head.match(new RegExp('^\\s*//\\s*@' + n + '\\b[ \\t]*(.*)$', 'm')); return r ? r[1].trim() : null; };
  const sites = (tag('sites') || '').split(/[,\s]+/).filter(Boolean);
  list.push({ id, title: tag('title') || id, file: f, sites, sticky: tag('sticky') !== null, builtin: false });
  used.add(id);
}
let count = 0;
const keep = new Set(['vazir.js']);                                    // vazir.js دستی نوشته شده و پاک نمی‌شود
const reg = [{ id: 'RTL', title: 'RTL', kind: 'rtl', builtin: true }, { id: 'Vazir', title: 'Vazir', file: 'vazir.js', desc: 'فونت وزیر روی کل صفحه', builtin: true }];
for (const it of list) {
  let src = readFileSync(join(SRC, it.file), 'utf8').replace(/^﻿/, '');
  const m = src.match(/export\s+function\s+([A-Za-z0-9_$]+)\s*\(/);
  const body = m ? src.replace(/export\s+function/, 'function') + '\n;' + m[1] + '();\n' : src + '\n';
  const out = it.file.replace(/[^A-Za-z0-9._-]/g, '_');   // نام امن برای فایل خروجی
  const code = '// تولیدشده توسط tools/build-run.mjs از src-scripts/' + it.file + ' (کد اصلی بدون تغییر)\n' +
    ';(() => { const vc = globalThis.__vc; if (vc) vc.begin();\ntry {\n' + body + '\n} finally { if (vc) vc.end(); } })();\n';
  try { new vm.Script(code, { filename: it.file }); } catch (e) { console.warn('SKIP ' + it.file + ' — خطای نحو: ' + e.message); continue; }   // یک فایل خراب بقیه را خراب نکند
  writeFileSync(join(OUT, out), code); count++;
  keep.add(out);
  reg.push({ id: it.id, title: it.title || it.id, file: out, sites: it.sites || [], sticky: !!it.sticky, builtin: it.builtin !== false });
}
for (const f of readdirSync(OUT)) if (!keep.has(f) && f.endsWith('.js')) unlinkSync(join(OUT, f));
writeFileSync(join(root, 'extension', 'registry.js'),
  '// فهرست اسکریپت‌ها؛ توسط tools/build-run.mjs ساخته می‌شود (دستی ویرایش نکنید)\nexport const SCRIPTS = ' + JSON.stringify(reg, null, 1) + ';\n');
console.log('OK: ' + count + ' اسکریپت ساخته شد (' + reg.filter(r => r.file).map(r => r.id).join(', ') + ').');
}
build();
if (process.argv.includes('--watch')) {
  console.log('در حال نظارت بر src-scripts … (Ctrl+C برای خروج). بعد از هر ساخت، افزونه را در chrome://extensions Reload کنید.');
  let t; watch(SRC, () => { clearTimeout(t); t = setTimeout(() => { try { build(); } catch (e) { console.warn(e.message); } }, 300); });
}
