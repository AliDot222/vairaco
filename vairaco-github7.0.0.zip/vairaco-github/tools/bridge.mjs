// vairaco — پل محلی بین پاپ‌آپ افزونه و پوشه‌ی پروژه.
//
// چرا لازم است؟ صفحه‌ی افزونه در مرورگر نمی‌تواند Node اجرا کند یا در پوشه بنویسد؛
// این سرور کوچک سه کار انجام می‌دهد:
//   ۱) ذخیره‌ی اسکریپتِ ویرایش‌شده مستقیم در src-scripts/  (منبع اصلی پروژه)
//   ۲) اجرای node tools/build-run.mjs  (و در صورت روشن‌بودن Watch، ساخت خودکار بعد از هر تغییر)
//   ۳) حذف اسکریپتِ کاربر از src-scripts/ + build
//
// اجرا:  node tools/bridge.mjs      (یا دوبار کلیک روی bridge.bat)
// فقط روی 127.0.0.1 گوش می‌دهد و فقط درخواست‌های همین افزونه را قبول می‌کند.

import { createServer } from 'node:http';
import { readFileSync, writeFileSync, unlinkSync, watch, openSync, closeSync, rmSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const SRC = join(root, 'src-scripts');
const BUILD = join(root, 'tools', 'build-run.mjs');
const PORT = Number(process.env.VAIRACO_BRIDGE_PORT || 47654);

// شناسه‌ی افزونه از کلید manifest محاسبه می‌شود (همان روش کروم) تا فقط Origin همین افزونه پذیرفته شود.
let EXT_ID = '';
try {
  const key = JSON.parse(readFileSync(join(root, 'extension', 'manifest.json'), 'utf8')).key;
  if (key) {
    const hex = createHash('sha256').update(Buffer.from(key, 'base64')).digest('hex').slice(0, 32);
    EXT_ID = [...hex].map(c => 'abcdefghijklmnop'.charAt(parseInt(c, 16))).join('');
  }
} catch { /* بدون کلید: هر Originِ chrome-extension پذیرفته می‌شود */ }

const cors = {
  'Access-Control-Allow-Origin': EXT_ID ? 'chrome-extension://' + EXT_ID : '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Cache-Control': 'no-store',
};
const send = (res, status, obj) => {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', ...cors });
  res.end(JSON.stringify(obj));
};
// مرورگر همیشه Origin می‌فرستد؛ ابزارهای محلی (curl) نمی‌فرستند. صفحات وب نمی‌توانند Origin جعل کنند.
const originOk = req => {
  const o = req.headers.origin;
  if (!o) return true;
  if (o === 'chrome-extension://' + EXT_ID) return true;
  return !EXT_ID && o.startsWith('chrome-extension://');
};

const readJson = req => new Promise((resolve, reject) => {
  const chunks = []; let size = 0;
  req.on('data', c => {
    size += c.length;
    if (size > 5 * 1024 * 1024) { reject(new Error('body too large')); req.destroy(); }
    else chunks.push(c);
  });
  req.on('end', () => {
    if (!chunks.length) return resolve({});
    try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); } catch { reject(new Error('invalid JSON')); }
  });
  req.on('error', reject);
});

// نام امن برای فایل: همان قاعده‌ی tools/build-run.mjs برای فایل‌های جدید
const NAME_RE = /^[A-Za-z0-9._ -]+$/;
function safeName(raw) {
  const n = String(raw || '').trim().replace(/\.js$/i, '').trim();
  if (!n) throw new Error('empty name');
  if (n.length > 60 || !NAME_RE.test(n) || n.startsWith('.') || /[. ]$/.test(n) || n === 'vazir') {
    throw new Error('invalid name: use English letters, digits, space, dot or dash');
  }
  return n;
}

let buildSeq = 0;
function build() {
  // خروجی build در فایل نوشته می‌شود (نه pipe) تا در محیط‌های محدود هم کار کند.
  const logFile = join(root, '.bridge-build-' + process.pid + '-' + (++buildSeq) + '.log');
  let fd = null;
  try {
    fd = openSync(logFile, 'w');
    const r = spawnSync(process.execPath, [BUILD], { cwd: root, stdio: ['ignore', fd, fd], timeout: 180000, windowsHide: true });
    closeSync(fd); fd = null;
    let log = '';
    try { log = readFileSync(logFile, 'utf8').trim(); } catch { /* خالی */ }
    const ok = r.status === 0;
    return { ok, log: log || (ok ? 'OK' : 'exit ' + (r.status === null ? (r.signal || 'error') : r.status)) };
  } catch (e) {
    if (fd !== null) { try { closeSync(fd); } catch { /* */ } }
    return { ok: false, log: String((e && e.message) || e) };
  } finally {
    try { rmSync(logFile, { force: true }); } catch { /* */ }
  }
}

// Watch: هر تغییر در src-scripts (مثلاً ویرایش در VS Code) خودکار build می‌شود.
let watcher = null, wTimer = null;
function setWatch(on) {
  if (on && !watcher) {
    watcher = watch(SRC, () => {
      clearTimeout(wTimer);
      wTimer = setTimeout(() => {
        const r = build();
        console.log('[watch] ' + (r.ok ? 'build OK' : 'build FAILED') + (r.ok ? '' : '\n' + r.log));
      }, 250);
    });
    console.log('[watch] روشن — تغییرات src-scripts خودکار ساخته می‌شوند.');
  } else if (!on && watcher) {
    watcher.close(); watcher = null; clearTimeout(wTimer);
    console.log('[watch] خاموش.');
  }
  return !!watcher;
}

const server = createServer(async (req, res) => {
  try {
    if (req.method === 'OPTIONS') { res.writeHead(204, cors); return res.end(); }
    if (!originOk(req)) return send(res, 403, { ok: false, error: 'origin not allowed' });
    const url = new URL(req.url, 'http://localhost');

    if (req.method === 'GET' && url.pathname === '/status') {
      return send(res, 200, { ok: true, port: PORT, watching: !!watcher, root });
    }

    if (req.method === 'POST' && url.pathname === '/save') {
      const body = await readJson(req);
      const name = safeName(body.name);
      const code = String(body.code ?? '');
      if (!code.trim()) throw new Error('empty code');
      writeFileSync(join(SRC, name + '.js'), code, 'utf8');
      if (body.remove) {
        const old = safeName(body.remove);
        if (old !== name) { try { unlinkSync(join(SRC, old + '.js')); } catch { /* نبود */ } }
      }
      const r = build();
      console.log('[save] ' + name + '.js → ' + (r.ok ? 'build OK' : 'build FAILED'));
      return send(res, 200, { ok: r.ok, file: name + '.js', log: r.log });
    }

    if (req.method === 'POST' && url.pathname === '/delete') {
      const body = await readJson(req);
      const name = safeName(body.name);
      try { unlinkSync(join(SRC, name + '.js')); } catch { /* از قبل نبود */ }
      const r = build();
      console.log('[delete] ' + name + '.js → build ' + (r.ok ? 'OK' : 'FAILED'));
      return send(res, 200, { ok: r.ok, log: r.log });
    }

    if (req.method === 'POST' && url.pathname === '/build') {
      const r = build();
      return send(res, 200, { ok: r.ok, log: r.log });
    }

    if (req.method === 'POST' && url.pathname === '/watch') {
      const body = await readJson(req);
      return send(res, 200, { ok: true, watching: setWatch(!!body.on) });
    }

    if (req.method === 'GET' && url.pathname === '/') {
      res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' });
      return res.end('vairaco bridge is running.\nPOST /save, /delete, /build, /watch\n');
    }

    return send(res, 404, { ok: false, error: 'not found' });
  } catch (e) {
    return send(res, 400, { ok: false, error: String((e && e.message) || e) });
  }
});

server.on('error', e => {
  if (e && e.code === 'EADDRINUSE') {
    console.error('پورت ' + PORT + ' اشغال است. یک پنجره‌ی bridge دیگر باز است؛ آن را ببندید یا VAIRACO_BRIDGE_PORT را تغییر دهید.');
  } else console.error(e);
  process.exit(1);
});

server.listen(PORT, '127.0.0.1', () => {
  console.log('');
  console.log('vairaco bridge  ➜  http://127.0.0.1:' + PORT);
  console.log('root   : ' + root);
  if (EXT_ID) console.log('origin : chrome-extension://' + EXT_ID);
  console.log('watch  : خاموش (از دکمه‌ی «Watch» در پاپ‌آپ روشن کنید)');
  console.log('');
  console.log('این پنجره را باز بگذارید؛ برای خروج Ctrl+C.');
});
process.on('SIGINT', () => { try { watcher && watcher.close(); } catch { /* */ } process.exit(0); });
