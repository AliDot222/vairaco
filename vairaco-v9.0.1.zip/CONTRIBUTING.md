# Contributing

Thanks for helping RTL users enjoy AI chats!

## Run locally
Clone the repo, open `chrome://extensions/`, enable Developer mode, **Load unpacked** → `extension/`.

## Add or fix a script
Scripts are plain files in `extension/my-scripts/` — no build step. Add `name.js` by hand and reload the extension:
- Plain JavaScript wrapped in `(() => { ... })();`, no `import`/`export`, so it also works when pasted into the console.
- Optional first lines: `// @title Pretty name`, `// @sites chat.example.com, other.com` (adds it to "Suggested rules"), `// @sticky` (the page reloads once after Reset).
- Changes made to the page are tracked automatically, so *Reset Styles* undoes them.
- If it should ship by default, run `node tools/make-seed.mjs` (updates the first-run list `extension/registry.js`).

## Add a translation
Open `extension/i18n.js`, copy the `en` block, translate it, add the language to `LANGS` (and to `RTL_LANGS` if right-to-left). Optionally add `extension/_locales/<code>/messages.json` for the extension name/description.

## Rules
- No new network requests, no remote code, no analytics, no ads.
- Keep fonts local (Vazirmatn only).
- Test on a page with a strict CSP when touching injection code.
