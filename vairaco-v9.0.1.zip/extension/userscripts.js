// vairaco — the scripts folder. Every *.js in my-scripts/ is a script (name = file name without .js).
// The popup/editor scan it live (no build, no reload) and store the list for the background worker (menu, auto-apply).
//   Optional header comments (first 10 lines):  // @title Pretty name   // @sites a.com, b.com   // @sticky
export const DIR_NAME = 'my-scripts';

const listDir = () => new Promise(resolve => {
  if (!chrome.runtime.getPackageDirectoryEntry) return resolve(null);
  chrome.runtime.getPackageDirectoryEntry(root => root.getDirectory(DIR_NAME, {}, dir => {
    const out = [], rd = dir.createReader();
    const more = () => rd.readEntries(es => { if (!es.length) return resolve(out); es.forEach(e => e.isFile && out.push(e.name)); more(); }, () => resolve(out));
    more();
  }, () => resolve(null)));
});
export const scriptUrl = file => chrome.runtime.getURL(DIR_NAME + '/' + encodeURIComponent(file));
export const readScript = async file => (await fetch(scriptUrl(file))).text();

export function parseMeta(code) {
  const head = String(code).split('\n').slice(0, 10).join('\n');
  const tag = n => { const m = head.match(new RegExp('^\\s*//\\s*@' + n + '\\b[ \\t]*(.*)$', 'm')); return m ? m[1].trim() : null; };
  return { title: tag('title'), sites: (tag('sites') || '').split(/[,\s]+/).filter(Boolean), sticky: tag('sticky') !== null };
}

export async function scanScripts() {
  const names = await listDir();
  if (names === null) return null;                       // could not read the folder (keep the previous list)
  const list = [];
  for (const file of names.filter(n => /\.js$/i.test(n)).sort((a, b) => a.localeCompare(b))) {
    const id = file.replace(/\.js$/i, '');
    let txt = '', bad = null;
    try { txt = await readScript(file); if (/^\s*(export|import)\s/m.test(txt)) bad = 'module'; } catch { bad = 'read'; }
    const m = parseMeta(txt);
    list.push({ id, title: m.title || id, file, sites: m.sites, sticky: m.sticky, bad });
  }
  return list;
}

// Scan + save (only if something changed, so the menu is rebuilt only when needed). Returns the list.
export async function syncScripts() {
  const list = await scanScripts();
  const { scriptList } = await chrome.storage.local.get('scriptList');
  if (list === null) return Array.isArray(scriptList) ? scriptList : null;
  if (JSON.stringify(scriptList || null) !== JSON.stringify(list)) await chrome.storage.local.set({ scriptList: list });
  return list;
}
