// vairaco — popup translations. To add a language: copy the `en` block, translate, add it to RTL_LANGS if right-to-left.
export const LANGS = { fa: 'فارسی', ar: 'العربية', en: 'English' };
export const RTL_LANGS = ['fa', 'ar'];

const D = {
  fa: {
    updates: 'گیت‌هاب', tabRules: 'قوانین سایت', tabMenu: 'منوی راست‌کلیک', tabScripts: 'اسکریپت‌ها', tabHelp: 'راهنما',
    ver: 'نسخه {0}',
    rulesTitle: 'اجرای خودکار روی سایت‌های من',
    rulesDesc: 'آدرس سایت را بنویسید و اسکریپت‌ها را بکشید داخل باکسش. از این به بعد هر بار وارد آن سایت شوید، بدون انتخاب دستی اعمال می‌شود. اگر مشکلی پیش آمد، <b>Reset Styles</b> از منوی راست‌کلیک همه‌چیز را برمی‌گرداند.',
    addSite: '+ افزودن سایت', addCurrent: '+ سایت فعلی', suggest: 'قوانین پیشنهادی',
    exportBtn: '⬆ کپی تنظیمات', importBtn: '⬇ وارد کردن تنظیمات', importPh: 'تنظیمات کپی‌شده را اینجا Paste کنید', importGo: 'اعمال تنظیمات',
    available: 'اسکریپت‌های در دسترس (بکشید و رها کنید داخل باکس یک سایت):',
    rulesEmpty: 'هنوز سایتی اضافه نکرده‌اید. روی «+ افزودن سایت» بزنید.',
    menuTitle: 'اسکریپت‌های منوی راست‌کلیک',
    menuDesc: 'فقط اسکریپت‌هایی که اینجا بگذارید در منوی راست‌کلیک (vairaco) دیده می‌شوند. از لیست پایین بکشید یا روی اسکریپت بزنید. ترتیب با کشیدن عوض می‌شود. Cursor و Reset Styles همیشه هستند.',
    menuAll: 'نمایش همه', menuClear: 'خالی کردن منو', myMenu: 'منوی من', search: 'جستجوی اسکریپت…',
    runTitle: 'اجرا روی تب فعلی', resetBtn: 'Reset Styles (برگرداندن همه‌چیز)',
    help1T: 'اجرای خودکار روی یک سایت (تب «قوانین سایت»)',
    help1: ['روی <b>+ افزودن سایت</b> بزنید (یا داخل خود سایت <b>+ سایت فعلی</b>) و آدرس را بنویسید؛ مثلاً <span dir="ltr">claude.ai</span>.', 'اسکریپت‌ها را از لیست بالا <b>بکشید</b> داخل باکس آن سایت (یا از منوی «+ افزودن اسکریپت» انتخاب کنید).', 'ترتیب اسکریپت‌ها = ترتیب اجرا؛ با کشیدن جابه‌جا کنید. از این به بعد با هر بار ورود به آن سایت خودکار اعمال می‌شود.', '<b>قوانین پیشنهادی</b> بهترین اسکریپت هر سایت معروف را یک‌جا اضافه می‌کند.'],
    help2T: 'منوی راست‌کلیک (تب «منوی راست‌کلیک»)',
    help2: ['داخل هر صفحه راست‌کلیک کنید ← <b>vairaco</b>؛ اسکریپت دلخواه را بزنید تا همان لحظه اعمال شود.', 'در تب «منوی راست‌کلیک» اسکریپت‌ها را بکشید داخل «منوی من» تا فقط همان‌ها در منو دیده شوند. «نمایش همه» منو را کامل برمی‌گرداند.', '<b>Reset Styles</b> همه‌ی تغییرات را از صفحه برمی‌دارد (به‌جز موشواره‌ی Cursor که فعال می‌ماند).'],
    help3T: 'انتقال تنظیمات به پروفایل دیگر', help3: 'در تب «قوانین سایت»: <b>کپی تنظیمات</b> را بزنید و در پروفایل دیگر با <b>وارد کردن تنظیمات</b> Paste کنید.',
    help4T: 'پروژه‌ی متن‌باز', help4: 'vairaco رایگان و متن‌باز است (MIT). گزارش مشکل، ترجمه و مشارکت در گیت‌هاب.',
    runFail: 'اجرا ناموفق بود: {0}', noAccess: 'این صفحه قابل دسترسی نیست.', tabNoAccess: 'تب فعلی قابل دسترسی نیست.',
    applied: 'اعمال شد: {0}', resetDone: 'ریست شد.', resetReload: 'ریست شد (صفحه یک بار رفرش شد تا هیچ ردی نماند).', resetNo: 'ریست این صفحه ممکن نیست.',
    appliedHere: 'روی این صفحه هم اعمال شد.', missing: 'این اسکریپت در این نسخه وجود ندارد. قانون حفظ می‌شود.', removeSite: 'حذف از این سایت',
    sitePh: 'آدرس سایت، مثلاً claude.ai', badDomain: 'آدرس سایت معتبر نیست (مثال: claude.ai).', toggle: 'فعال / غیرفعال', delSite: 'حذف سایت',
    dropHint: 'اسکریپت را اینجا بکشید و رها کنید…', addScript: '+ افزودن اسکریپت…', dup: 'این سایت قبلاً در لیست هست.', max100: 'حداکثر ۱۰۰ سایت.',
    notNormal: 'این صفحه سایت معمولی نیست.', sugAdded: '{0} مورد پیشنهادی اضافه شد.', sugNone: 'همه‌ی پیشنهادها قبلاً اضافه شده‌اند.',
    menuAllCount: '(همه — {0})', menuEmpty: 'منو خالی است. اسکریپت را از پایین بکشید اینجا…', menuAllMsg: 'همه‌ی اسکریپت‌ها در منو نمایش داده می‌شوند.',
    copied: 'تنظیمات کپی شد. در پروفایل دیگر «وارد کردن» را بزنید و Paste کنید.', copyManual: 'متن را دستی کپی کنید.',
    tabEdit: 'استایل من', edTitle: 'استایل (CSS) دلخواه من', edDesc: 'برای هر سایت یک CSS بنویسید؛ همان لحظه اعمال می‌شود. بدون پوشه، بدون ری‌لود.',
    edNew: '+ استایل جدید', edSave: 'ذخیره', edDelete: 'حذف', edDeleteSure: 'مطمئنید؟ دوباره بزنید', edPrompt: '✨ کپی پرامپت هوش مصنوعی', edPromptDone: 'کپی شد. در ChatGPT/Claude بچسبانید و بعد از «My request:» خواسته‌تان را بنویسید.',
    edName: 'نام (مثلاً صورتی)', edSites: 'سایت‌ها (با ویرگول): chat.deepseek.com, claude.ai', edCss: 'CSS اینجا...', edSaved: 'ذخیره و اعمال شد ✓', edDeleted: 'حذف شد.', edNeedName: 'یک نام بنویسید.', edNeedSite: 'حداقل یک سایت معتبر بنویسید.', edNeedCss: 'CSS خالی است.', edEmpty: 'هنوز استایلی نساخته‌اید.',
    badText: 'متن معتبر نیست.', notOurs: 'این فایل تنظیمات vairaco نیست.', imported: '{0} سایت وارد شد.',
  },
  ar: {
    updates: 'GitHub', tabRules: 'قواعد المواقع', tabMenu: 'قائمة النقر الأيمن', tabScripts: 'السكربتات', tabHelp: 'مساعدة',
    ver: 'الإصدار {0}',
    rulesTitle: 'تشغيل تلقائي على مواقعي',
    rulesDesc: 'اكتب عنوان الموقع واسحب السكربتات إلى مربّعه. بعد ذلك تُطبَّق تلقائياً في كل مرة تفتح فيها هذا الموقع. إن حدثت مشكلة، فإن <b>Reset Styles</b> من قائمة النقر الأيمن يعيد كل شيء.',
    addSite: '+ إضافة موقع', addCurrent: '+ الموقع الحالي', suggest: 'قواعد مقترحة',
    exportBtn: '⬆ نسخ الإعدادات', importBtn: '⬇ استيراد الإعدادات', importPh: 'الصق الإعدادات المنسوخة هنا', importGo: 'تطبيق الإعدادات',
    available: 'السكربتات المتاحة (اسحبها وأفلتها داخل مربّع موقع):',
    rulesEmpty: 'لم تضف أي موقع بعد. اضغط «+ إضافة موقع».',
    menuTitle: 'سكربتات قائمة النقر الأيمن',
    menuDesc: 'تظهر في قائمة النقر الأيمن (vairaco) السكربتات التي تضعها هنا فقط. اسحب من القائمة السفلية أو اضغط على السكربت. يتغيّر الترتيب بالسحب. Cursor وReset Styles موجودان دائماً.',
    menuAll: 'إظهار الكل', menuClear: 'تفريغ القائمة', myMenu: 'قائمتي', search: 'ابحث عن سكربت…',
    runTitle: 'تشغيل على التبويب الحالي', resetBtn: 'Reset Styles (إعادة كل شيء)',
    help1T: 'التشغيل التلقائي على موقع (تبويب «قواعد المواقع»)',
    help1: ['اضغط <b>+ إضافة موقع</b> (أو <b>+ الموقع الحالي</b> من داخل الموقع) واكتب العنوان، مثل <span dir="ltr">claude.ai</span>.', '<b>اسحب</b> السكربتات من القائمة العلوية إلى مربّع ذلك الموقع (أو اخترها من «+ إضافة سكربت»).', 'ترتيب السكربتات = ترتيب التنفيذ؛ غيّره بالسحب. بعدها يُطبَّق تلقائياً عند كل دخول إلى الموقع.', '<b>قواعد مقترحة</b> تضيف أفضل سكربت لكل موقع مشهور دفعة واحدة.'],
    help2T: 'قائمة النقر الأيمن (تبويب «قائمة النقر الأيمن»)',
    help2: ['انقر بزر الفأرة الأيمن داخل أي صفحة ← <b>vairaco</b> ثم اختر السكربت ليُطبَّق فوراً.', 'في تبويب «قائمة النقر الأيمن» اسحب السكربتات إلى «قائمتي» لتظهر هي فقط. «إظهار الكل» يعيد القائمة الكاملة.', '<b>Reset Styles</b> يزيل كل التغييرات من الصفحة (عدا مؤشر Cursor الذي يبقى مفعّلاً).'],
    help3T: 'نقل الإعدادات إلى ملف تعريف آخر', help3: 'في تبويب «قواعد المواقع»: اضغط <b>نسخ الإعدادات</b> ثم الصقها في ملف التعريف الآخر عبر <b>استيراد الإعدادات</b>.',
    help4T: 'مشروع مفتوح المصدر', help4: 'vairaco مجاني ومفتوح المصدر (MIT). الإبلاغ عن المشاكل والترجمة والمساهمة على GitHub.',
    runFail: 'فشل التنفيذ: {0}', noAccess: 'لا يمكن الوصول إلى هذه الصفحة.', tabNoAccess: 'لا يمكن الوصول إلى التبويب الحالي.',
    applied: 'تم التطبيق: {0}', resetDone: 'تمت إعادة الضبط.', resetReload: 'تمت إعادة الضبط (أُعيد تحميل الصفحة مرة لإزالة كل أثر).', resetNo: 'لا يمكن إعادة ضبط هذه الصفحة.',
    appliedHere: 'طُبّق على هذه الصفحة أيضاً.', missing: 'هذا السكربت غير موجود في هذا الإصدار. تم الاحتفاظ بالقاعدة.', removeSite: 'إزالة من هذا الموقع',
    sitePh: 'عنوان الموقع، مثل claude.ai', badDomain: 'عنوان الموقع غير صالح (مثال: claude.ai).', toggle: 'تفعيل / تعطيل', delSite: 'حذف الموقع',
    dropHint: 'اسحب السكربت وأفلته هنا…', addScript: '+ إضافة سكربت…', dup: 'هذا الموقع موجود في القائمة.', max100: 'الحد الأقصى 100 موقع.',
    notNormal: 'هذه ليست صفحة موقع عادية.', sugAdded: 'أُضيف {0} من المقترحات.', sugNone: 'كل المقترحات مضافة مسبقاً.',
    menuAllCount: '(الكل — {0})', menuEmpty: 'القائمة فارغة. اسحب سكربتاً من الأسفل إلى هنا…', menuAllMsg: 'تظهر كل السكربتات في القائمة.',
    copied: 'تم نسخ الإعدادات. في ملف التعريف الآخر اضغط «استيراد» والصق.', copyManual: 'انسخ النص يدوياً.',
    tabEdit: 'أنماطي', edTitle: 'أنماط CSS الخاصة بي', edDesc: 'اكتب CSS لكل موقع؛ يُطبَّق فوراً. بلا مجلدات وبلا إعادة تحميل.',
    edNew: '+ نمط جديد', edSave: 'حفظ', edDelete: 'حذف', edDeleteSure: 'متأكد؟ اضغط مرة أخرى', edPrompt: '✨ نسخ طلب الذكاء الاصطناعي', edPromptDone: 'تم النسخ. الصقه في ChatGPT/Claude واكتب طلبك بعد «My request:».',
    edName: 'الاسم (مثل وردي)', edSites: 'المواقع (بفاصلة): chat.deepseek.com, claude.ai', edCss: 'CSS هنا...', edSaved: 'تم الحفظ والتطبيق ✓', edDeleted: 'تم الحذف.', edNeedName: 'اكتب اسماً.', edNeedSite: 'اكتب موقعاً صالحاً واحداً على الأقل.', edNeedCss: 'الـ CSS فارغ.', edEmpty: 'لا توجد أنماط بعد.',
    badText: 'النص غير صالح.', notOurs: 'هذا ليس ملف إعدادات vairaco.', imported: 'تم استيراد {0} موقع.',
  },
  en: {
    updates: 'GitHub', tabRules: 'Site rules', tabMenu: 'Right-click menu', tabScripts: 'Scripts', tabHelp: 'Help',
    ver: 'Version {0}',
    rulesTitle: 'Auto-apply on my sites',
    rulesDesc: 'Type a site address and drag scripts into its box. From then on they are applied every time you open that site. If anything goes wrong, <b>Reset Styles</b> in the right-click menu restores everything.',
    addSite: '+ Add site', addCurrent: '+ Current site', suggest: 'Suggested rules',
    exportBtn: '⬆ Copy settings', importBtn: '⬇ Import settings', importPh: 'Paste copied settings here', importGo: 'Apply settings',
    available: 'Available scripts (drag and drop into a site box):',
    rulesEmpty: 'No sites yet. Click “+ Add site”.',
    menuTitle: 'Right-click menu scripts',
    menuDesc: 'Only the scripts you put here appear in the right-click menu (vairaco). Drag from the list below or click a script. Drag to reorder. Cursor and Reset Styles are always there.',
    menuAll: 'Show all', menuClear: 'Empty the menu', myMenu: 'My menu', search: 'Search scripts…',
    runTitle: 'Run on current tab', resetBtn: 'Reset Styles (undo everything)',
    help1T: 'Auto-apply on a site (“Site rules” tab)',
    help1: ['Click <b>+ Add site</b> (or <b>+ Current site</b> while on it) and type the address, e.g. <span dir="ltr">claude.ai</span>.', '<b>Drag</b> scripts from the list into that site’s box (or pick from “+ Add script”).', 'Script order = run order; drag to reorder. From then on it is applied automatically each time you visit.', '<b>Suggested rules</b> adds the best script for each popular site at once.'],
    help2T: 'Right-click menu (“Right-click menu” tab)',
    help2: ['Right-click anywhere on a page → <b>vairaco</b>, then choose a script to apply it instantly.', 'In the “Right-click menu” tab drag scripts into “My menu” so only those appear. “Show all” restores the full menu.', '<b>Reset Styles</b> removes every change from the page (except the Cursor, which stays on).'],
    help3T: 'Move settings to another profile', help3: 'In “Site rules”: click <b>Copy settings</b>, then paste in the other profile with <b>Import settings</b>.',
    help4T: 'Open-source project', help4: 'vairaco is free and open source (MIT). Report issues, translate and contribute on GitHub.',
    runFail: 'Failed: {0}', noAccess: 'This page cannot be accessed.', tabNoAccess: 'The current tab cannot be accessed.',
    applied: 'Applied: {0}', resetDone: 'Reset done.', resetReload: 'Reset done (page reloaded once so nothing is left behind).', resetNo: 'This page cannot be reset.',
    appliedHere: 'Also applied to this page.', missing: 'This script does not exist in this version. The rule is kept.', removeSite: 'Remove from this site',
    sitePh: 'Site address, e.g. claude.ai', badDomain: 'Invalid site address (example: claude.ai).', toggle: 'Enable / disable', delSite: 'Delete site',
    dropHint: 'Drag and drop a script here…', addScript: '+ Add script…', dup: 'This site is already in the list.', max100: 'Maximum 100 sites.',
    notNormal: 'This is not a regular website.', sugAdded: '{0} suggested rule(s) added.', sugNone: 'All suggestions are already added.',
    menuAllCount: '(all — {0})', menuEmpty: 'The menu is empty. Drag a script here from below…', menuAllMsg: 'All scripts are shown in the menu.',
    copied: 'Settings copied. In the other profile click “Import” and paste.', copyManual: 'Copy the text manually.',
    tabEdit: 'My styles', edTitle: 'My own CSS styles', edDesc: 'Write CSS for any site; it applies instantly. No folders, no reload.',
    edNew: '+ New style', edSave: 'Save', edDelete: 'Delete', edDeleteSure: 'Sure? Click again', edPrompt: '✨ Copy AI prompt', edPromptDone: 'Copied. Paste it into ChatGPT/Claude and write your request after “My request:”.',
    edName: 'Name (e.g. pink)', edSites: 'Sites (comma-separated): chat.deepseek.com, claude.ai', edCss: 'CSS here...', edSaved: 'Saved and applied ✓', edDeleted: 'Deleted.', edNeedName: 'Enter a name.', edNeedSite: 'Enter at least one valid site.', edNeedCss: 'The CSS is empty.', edEmpty: 'No styles yet.',
    badText: 'Invalid text.', notOurs: 'This is not a vairaco settings file.', imported: '{0} site(s) imported.',
  },
};

let lang = 'en';
export const getLang = () => lang;
export function guessLang() {
  const l = String((chrome.i18n && chrome.i18n.getUILanguage && chrome.i18n.getUILanguage()) || 'en').toLowerCase();
  if (/^(fa|prs|ps)/.test(l)) return 'fa';
  if (/^(ar|ur)/.test(l)) return 'ar';
  return 'en';
}
export function setLang(l) {
  lang = D[l] ? l : 'en';
  document.documentElement.lang = lang;
  document.documentElement.dir = RTL_LANGS.includes(lang) ? 'rtl' : 'ltr';
}
export function t(key, ...args) {
  const s = (D[lang] && D[lang][key]) ?? D.en[key] ?? key;
  return typeof s === 'string' ? s.replace(/\{(\d+)\}/g, (_, i) => args[i] ?? '') : s;
}
// Static markup: data-i18n (text), data-i18n-html (trusted strings from this file only), data-i18n-ph (placeholder), data-i18n-list="key" (array → <li>)
export function applyI18n(root = document) {
  root.querySelectorAll('[data-i18n]').forEach(e => { e.textContent = t(e.dataset.i18n); });
  root.querySelectorAll('[data-i18n-html]').forEach(e => { e.innerHTML = t(e.dataset.i18nHtml); });
  root.querySelectorAll('[data-i18n-ph]').forEach(e => { e.placeholder = t(e.dataset.i18nPh); });
  root.querySelectorAll('[data-i18n-list]').forEach(e => { e.innerHTML = t(e.dataset.i18nList).map(x => '<li>' + x + '</li>').join(''); });
}
