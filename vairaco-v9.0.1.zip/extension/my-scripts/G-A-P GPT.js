// @title G-A-P GPT
(() => {
function GAPGPT() {
  // G-A-P GPT

  // 1. ایجاد و تزریق لینک CSS فونت وزیر
  const fontLink = document.createElement("link");
  fontLink.href = "https://cdn.jsdelivr.net/gh/rastikerdar/vazir-font@v30.1.0/dist/font-face.css";
  fontLink.rel = "stylesheet";
  document.head.appendChild(fontLink);

  // 2. ایجاد و تزریق تگ استایل
  const s = document.createElement("style");
  s.textContent = `
/* -------------------------------------------------- */
/* استایل‌دهی برای بلاک‌های کد (Pre/Code) */
code, pre {
  /* افزایش فاصله بین حروف (letter-spacing) برای خوانایی بهتر کد */
  font-family: 'Vazirmatn', 'Vazir', monospace !important;
  font-size: calc(1em + 1px) !important;
  line-height: 1.7 !important;
  
  /* 🌟 مقدار نهایی: فاصله بین حروف در کدها */
  letter-spacing: 1.8px !important;
  
  /* تنظیمات جهت‌دهی برای نمایش صحیح کاراکترهای مختلط */
  unicode-bidi: plaintext !important;
  direction: ltr !important;
  white-space: pre-wrap !important;
  overflow-x: auto !important;
}

/* -------------------------------------------------- */
/* استایل‌دهی برای متن اصلی (بدنه) */
body, p, span, div {
  /* اعمال فونت وزیر به متن اصلی */
  font-family: "Vazirmatn", "Vazir", "IranSans", sans-serif !important;
}
    `;
  document.head.appendChild(s);
}

GAPGPT();
})();
