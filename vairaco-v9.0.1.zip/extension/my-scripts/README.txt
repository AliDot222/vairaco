vairaco — built-in scripts
==========================
These are the ready-made scripts (shown in the popup and the right-click menu).
Want your own look for a site? Use the popup tab "My styles": write CSS, Save, done. No files, no reload.

Advanced: you can also drop a plain-JS  name.js  here (wrapped in  (() => { ... })();  with no import/export),
then press Reload on the extension in chrome://extensions. Optional first lines:
    // @title Pretty name
    // @sites chat.example.com, other.com
    // @sticky
Keep this README.txt.
