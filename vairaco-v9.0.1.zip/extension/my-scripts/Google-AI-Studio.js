// @title Google AI Studio
// @sites aistudio.google.com
(() => {
function GoogleAIStudio() {
  (function () {
    'use strict';

    const FONT_NAME = 'Vazirmatn';
    const FONT_URL = 'https://cdn.jsdelivr.net/npm/vazirmatn@33.0.3/Vazirmatn-font-face.css';

    if (!document.getElementById('fa-font-link')) {
      const link = document.createElement('link');
      link.id = 'fa-font-link';
      link.rel = 'stylesheet';
      link.href = FONT_URL;
      document.head.appendChild(link);
    }

    if (!document.getElementById('fa-dir-style')) {
      const style = document.createElement('style');
      style.id = 'fa-dir-style';
      style.textContent = `
        textarea[cdktextareaautosize] {
          direction: rtl;
          unicode-bidi: plaintext;
          text-align: start;
          font-family: '${FONT_NAME}', Tahoma, sans-serif !important;
          line-height: 1.9 !important;
        }

        .bubble p,
        .bubble li,
        .bubble h1,
        .bubble h2,
        .bubble h3,
        .bubble h4,
        .bubble blockquote,
        .bubble td,
        .bubble th {
          direction: rtl;
          unicode-bidi: plaintext;
          text-align: start !important;
          font-family: '${FONT_NAME}', Tahoma, sans-serif !important;
          line-height: 1.9 !important;
        }

        .bubble ul,
        .bubble ol {
          padding-inline-start: 1.5em;
        }

        .bubble .inline-code {
          direction: ltr;
          unicode-bidi: embed;
          font-family: 'Consolas', 'Courier New', monospace !important;
        }
      `;
      document.head.appendChild(style);
    }

    console.log('Google AI Studio Persian font and direction styles are active.');
  })();
}

GoogleAIStudio();
})();
