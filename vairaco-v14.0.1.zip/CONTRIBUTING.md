# Contributing

Thanks for helping RTL users enjoy AI chats!

## Run locally
Clone the repo, open `chrome://extensions/`, enable Developer mode, **Load unpacked** → `extension/`.

## Add or fix a script
Scripts are plain files in `extension/my-scripts/` — no build step. Add `name.js` by hand (it is picked up instantly, no reload):
- Plain JavaScript wrapped in `(() => { ... })();`, no `import`/`export`, so it also works when pasted into the console.
- Optional first lines: `// @title Pretty name`, `// @sites chat.example.com, other.com` (adds it to "Suggested rules"), `// @auto` (runs by itself on its @sites), `// @sticky` (the page reloads once after Reset).
- Changes made to the page are tracked automatically, so *Reset Styles* undoes them.
- If it should ship by default, run `node tools/make-seed.mjs` (updates the first-run list `extension/registry.js`).

## Add a translation
Open `extension/i18n.js`, copy the `en` block, translate it, add the language to `LANGS` (and to `RTL_LANGS` if right-to-left). Optionally add `extension/_locales/<code>/messages.json` for the extension name/description.

## Rules
- No new network requests, no remote code, no analytics, no ads.
- Keep fonts local (Vazirmatn only).
- Test on a page with a strict CSP when touching injection code.


**Every new script must be Reset-safe.** Apply it, press *Reset Styles*, and check the site is exactly as before. If anything is left behind, update `extension/my-scripts/reset/reset-extra.js` in the same change (see "Writing your own scripts" in the README).
