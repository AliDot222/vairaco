// @title GPT-Dev
// @sites chatgpt.com
(() => {
function GPTDev() {
  //                              - GPT-

  // فونت وزیر از داخل خود افزونه می‌آید (inject/vazir-faces.js)؛ لینک CDN حذف شد.

  const s = document.createElement("style");
  s.textContent = `
code, pre {
  font-family: monospace !important;
  font-size: calc(1em + 1px) !important;
  white-space: pre-wrap !important;
  overflow-x: auto !important;
  line-height: 1.7 !important;
  letter-spacing: 0.6px !important;

  /* 👇 این‌ها باعث می‌شن " و < و > دقیق نمایش داده بشن */
  unicode-bidi: plaintext !important;
  direction: ltr !important;
}

body, p, span, div {
  font-family: "Vazirmatn", "Vazir", Tahoma, sans-serif !important;
}
    `;
  document.head.appendChild(s);

  // تنظیم جهت متن خودکار
  const css = `
    * {
      unicode-bidi: plaintext !important;
      direction: auto !important;
    }
  `;
  const styleSheet = document.createElement('style');
  styleSheet.textContent = css;
  document.head.appendChild(styleSheet);


  






}

GPTDev();
})();
