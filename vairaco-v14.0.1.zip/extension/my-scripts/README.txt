vairaco — scripts folder
========================
Every  name.js  in this folder is a script. Edit with Notepad (or any editor), Save, switch back to Chrome:
it is applied to the open pages instantly. A brand-new file is picked up the next time you open the popup (then it shows in the right-click menu too). No reload, no buttons.

Write plain JavaScript wrapped in  (() => { ... })();  with no import/export.
Optional first lines:
    // @title Pretty name
    // @sites chat.example.com, other.com      (the sites this script is for)
    // @auto                                   (run on those @sites by itself, every visit)
    // @sticky                                 (the page reloads once after Reset)
Keep this README.txt. Handy: popup -> "My scripts" -> "Copy new-script template".

IMPORTANT - keep Reset in mind
  The "Reset Styles" button must bring the site back exactly as it was. vairaco undoes most of what a script does
  (elements, attributes, classes, styles, timers, listeners, observers, globals, localStorage via setItem...).
  If your script does something it cannot see (shadow DOM, cookies, server-side settings...), also add its cleanup to
  extension/my-scripts/reset/reset-extra.js. After writing a script: apply it, press Reset Styles, check the site is unchanged.

THE WHOLE WORKSHOP IS THIS FOLDER (my-scripts/)
  my-scripts/*.js              your scripts (one file each; edit, Ctrl+S, it applies)
  my-scripts/reset/            Reset Styles:  reset-styles.js (main reset)  +  reset-extra.js (extra cleanup)
                               also cursor.js and rtl.js
  my-scripts/fonts/            Vazirmatn fonts (Vazirmatn-Regular/Bold/...woff2)

  Open this folder in your editor / AI tool. To use a font in a script, load it from the extension:
      chrome.runtime.getURL('my-scripts/fonts/Vazirmatn-Regular.woff2')
  (the Vazirmatn / Vazir family is already registered on every page the scripts run on, so
   font-family: Vazirmatn  just works.)

  When you add or change a script, update my-scripts/reset/reset-styles.js (new keywords/selectors)
  or reset-extra.js in the same change, so Reset Styles removes what the new script left behind.
  After editing reset files: reload the extension once (chrome://extensions -> reload).
