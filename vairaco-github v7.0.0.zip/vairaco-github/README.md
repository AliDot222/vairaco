# vairaco

**Free, open-source Chrome extension that gives AI chat sites beautiful RTL support and the Vazirmatn font.**
Persian · Arabic · Dari/Pashto · Urdu · Hebrew — any right-to-left language.

No ads. No account. No server. No tracking. Scripts and fonts are bundled inside the extension. Your own scripts stay in your browser.

Works on ChatGPT, Claude, Gemini, DeepSeek, Google AI Studio, Copilot and more — code blocks and math stay untouched.

## Install

1. Download the latest zip from [Releases](https://github.com/vairawp/vairaco/releases) and unzip it (or clone this repo).
2. Open `chrome://extensions/` and turn on **Developer mode** (top right).
3. Click **Load unpacked** and choose the **`extension`** folder — the one that contains `manifest.json`.
4. Pin vairaco from the puzzle-piece menu.

Keep the folder in place after installing. To update: replace the folder contents and press the reload button on `chrome://extensions/`; your settings are kept.

## Use

- **Right-click menu:** right-click on a page → *vairaco* → pick a script (RTL, Vazir, or a site-specific style). *Reset Styles* undoes everything (the Cursor stays).
- **Site rules:** open the popup → *Site rules* → add a site (e.g. `claude.ai`) and drag scripts into it. They are applied automatically on every visit.
- **Right-click menu editor:** choose which scripts appear in the menu and in what order.
- **Editor tab:** create your own scripts (`+ New script`, give it a name like `pink`, write the code, Save) and view/edit the code of any built-in script right inside the popup. Saved scripts appear instantly in the right-click menu, site rules and lists; built-in edits can be undone with *Restore original*. This tab runs code through Chrome's `userScripts` API, so turn on **Allow User Scripts** for vairaco (`chrome://extensions` → vairaco → Details; on older Chrome: Developer mode). Everything else works without it.
- **Save to your project folder:** in the Editor tab press **📁 Save to disk…** (opens a tab), then link the `extension/my-scripts` folder once (or `src-scripts` for project source). From then on every script you save is written as a real `name.js` file there — and with `my-scripts` it also runs instantly. The browser asks for write permission, and may ask again in a new session.
- **Drop-in folder:** or just put a `name.js` file in `extension/my-scripts/` and click the extension icon — no build, no reload.
- **Languages:** the popup is available in فارسی, العربية and English (selector in the header).

## Privacy

vairaco itself makes **no network requests** and has no analytics. Settings are stored locally in your browser (`chrome.storage`). The only exception is the optional *Cursor* feature: when you enable it, the page loads a cursor image from `cur.cursors-4u.net`. Also, the Claude site script loads the Fira Code code font from a public CDN (jsdelivr); everything else, including all Persian/Arabic fonts, is local. Bundling Fira Code too is a good first contribution.

## Project layout

| Path | Purpose |
|---|---|
| `extension/` | The extension itself (load this folder) |
| `extension/fonts/` | Vazirmatn woff2 files (SIL OFL) — registered locally via `FontFace`, CSP-safe |
| `extension/i18n.js` | Popup translations (fa / ar / en) |
| `src-scripts/` | Site style scripts — drop a `name.js` here and it shows up in the popup as `name` |
| `tools/build-run.mjs` | Generates `extension/run/*` and `extension/registry.js` from `src-scripts` |

## Contributing

Issues and pull requests are welcome — see [CONTRIBUTING.md](CONTRIBUTING.md). Translations, new site styles and bug reports for AI sites are especially useful.

## License

MIT — see [LICENSE](LICENSE). Vazirmatn font: SIL OFL 1.1 ([extension/fonts/OFL.txt](extension/fonts/OFL.txt)).

---

## فارسی

**افزونه‌ی رایگان و متن‌باز کروم برای راست‌چین و فونت وزیر در سایت‌های هوش مصنوعی** (ChatGPT، Claude، Gemini، Google AI Studio، Copilot و …). بدون تبلیغ، بدون ثبت‌نام، بدون سرور؛ فونت‌ها و اسکریپت‌ها همه داخل خود افزونه‌اند.

**نصب:** zip را از بخش [Releases](https://github.com/vairawp/vairaco/releases) بگیرید و از حالت فشرده خارج کنید ← در `chrome://extensions/` گزینه‌ی **Developer mode** را روشن کنید ← **Load unpacked** ← پوشه‌ی **`extension`** (همان که `manifest.json` دارد) را انتخاب کنید.

**استفاده:** راست‌کلیک روی صفحه ← vairaco ← اسکریپت دلخواه. برای اجرای خودکار، در پاپ‌آپ تب «قوانین سایت» را باز کنید، آدرس سایت را اضافه و اسکریپت‌ها را به آن بکشید.

## العربية

**إضافة Chrome مجانية ومفتوحة المصدر تضيف دعم الكتابة من اليمين إلى اليسار وخط Vazirmatn لمواقع الذكاء الاصطناعي.** بلا إعلانات ولا حساب ولا خادم؛ الخطوط والسكربتات كلها داخل الإضافة.

**التثبيت:** حمّل ملف zip من [Releases](https://github.com/vairawp/vairaco/releases) وفكّ ضغطه ← افتح `chrome://extensions/` وفعّل **Developer mode** ← **Load unpacked** ← اختر المجلد **`extension`** (الذي يحتوي على `manifest.json`).

**الاستخدام:** انقر بزر الفأرة الأيمن في الصفحة ← vairaco ← اختر السكربت. وللتشغيل التلقائي افتح النافذة المنبثقة وتبويب «قواعد المواقع» وأضف الموقع واسحب السكربتات إليه.
