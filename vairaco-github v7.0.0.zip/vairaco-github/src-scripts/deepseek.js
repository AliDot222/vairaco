export function DeepSeek() {
  // DeepSeek (chat.deepseek.com): Vazirmatn font + per-paragraph automatic direction (RTL/LTR) for RTL languages.
  // Written for vairaco (selector-free on purpose, so it survives site redesigns). Code blocks, math and the
  // composer keep their own direction handling.
  document.getElementById('vc-deepseek-style')?.remove();
  const s = document.createElement('style');
  s.id = 'vc-deepseek-style';
  s.textContent = `
    body, body *:not(pre):not(pre *):not(code):not(code *):not(kbd):not(samp):not(svg):not(svg *):not(.katex):not(.katex *):not([class*="icon" i]):not(i) {
      font-family: "Vazirmatn", "Vazir", Tahoma, sans-serif !important;
    }
    main p, main li, main h1, main h2, main h3, main h4, main h5, main h6, main blockquote, main td, main th,
    textarea, [contenteditable="true"] {
      unicode-bidi: plaintext !important;
      text-align: start !important;
    }
    main ul, main ol { padding-inline-start: 1.6em; }
    pre, pre *, code, .katex, .katex * { direction: ltr !important; unicode-bidi: normal !important; text-align: left !important; }
  `;
  (document.head || document.documentElement).appendChild(s);
}
