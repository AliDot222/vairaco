// تولیدشده توسط tools/build-run.mjs از src-scripts/copilot_v2.js (کد اصلی بدون تغییر)
;(() => { const vc = globalThis.__vc; if (vc) vc.begin();
try {
function COPILOT_V2() {
  // - COPILOT_V2

document.head.innerHTML += `
<style>
    /* تنظیم فونت فارسی برای کل صفحه */
    *:not(textarea):not(input):not([contenteditable="true"]) {
        font-family: Vazirmatn, IranSans, Tahoma, sans-serif !important;
    }
    
    /* تنظیم جهت متن پیش‌فرض */
    * { 
        direction: rtl !important; 
        text-align: right !important; 
    }
    
    /* استثنا برای کد و فرمول‌های ریاضی */
    pre, code, pre *, code *,
    [class*="code"], [class*="code"] *,
    [class*="Code"], [class*="Code"] *,
    [class*="math"], [class*="math"] *,
    [class*="Math"], [class*="Math"] *,
    [class*="equation"], [class*="equation"] *,
    [class*="Equation"], [class*="Equation"] *,
    [class*="formula"], [class*="formula"] *,
    [class*="Formula"], [class*="Formula"] *,
    [class*="katex"], [class*="katex"] *,
    [class*="latex"], [class*="latex"] *,
    .math, .Math, .equation, .Equation,
    .formula, .Formula, .katex, .latex,
    mjx-container, mjx-container * {
        direction: ltr !important;
        text-align: left !important;
        unicode-bidi: embed !important; /* جلوگیری از جابه‌جایی کاراکترها */
        font-size: calc(100% + 0.7px) !important;
        font-family: monospace, "Courier New", Courier !important;
        letter-spacing: 0.5px !important;
        overflow: auto !important;
        max-height: 60vh !important;
    }


    /* پیام‌های داخل چت (برای اینکه LTR دیده بشن) */
    .chat-message, .message, .user-message,
    [class*="message"], [class*="chat"], [class*="msg"] {
        direction: ltr !important;
        text-align: left !important;
        unicode-bidi: embed !important;
    }
        /* مخفی کردن نوار اسکرول در مرورگرهای WebKit (مثل Chrome و Edge) */
    pre::-webkit-scrollbar {
      display: none;
    }

    pre {
    overflow-x: auto !important;
    overflow-y: hidden !important;
    max-height: none !important;
    scrollbar-width: auto;
    }

    pre::-webkit-scrollbar:vertical {
    display: none;
    }

    /* باکس تایپ پیام از چپ به راست */
    textarea, input[type="text"], [contenteditable="true"] {
        direction: auto !important;
        unicode-bidi: plaintext !important;
        text-align: start !important;
    }
        
    }

</style>
`;

document.querySelector('.pointer-events-auto.absolute.inset-0.h-14.overflow-hidden.backdrop-blur-2xl.backdrop-saturate-200.bg-background-150\\/95.dark\\:bg-background-150\\/90')?.remove();


document.addEventListener("copy", function (e) {
  const selection = window.getSelection();
  if (!selection.rangeCount) return;

  const range = selection.getRangeAt(0);
  const container = range.commonAncestorContainer;

  // فقط اگر داخل pre یا code باشه
  if (container && (container.nodeName === "PRE" || container.nodeName === "CODE" ||
      container.parentElement?.closest("pre, code"))) {
    e.preventDefault();
    const text = selection.toString();
    e.clipboardData.setData("text/plain", text);
  }
});

//####











}

;COPILOT_V2();

} finally { if (vc) vc.end(); } })();
