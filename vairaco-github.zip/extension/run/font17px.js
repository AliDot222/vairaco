// تولیدشده توسط tools/build-run.mjs از src-scripts/font17px.js (کد اصلی بدون تغییر)
;(() => { const vc = globalThis.__vc; if (vc) vc.begin();
try {
function FONT17PX() {

// Hame element hayi ke matn darand ro migire
const allElements = document.querySelectorAll('body *');

allElements.forEach(el => {
    // Check mikonad ke element matn dashte bashe ya na
    const hasText = el.childNodes.length > 0 && 
                    Array.from(el.childNodes).some(node => 
                        node.nodeType === 3 && // Text node
                        node.textContent.trim().length > 0
                    );
    
    // Check mikonad ke khode element matn dashte bashe
    const hasOwnText = el.textContent && el.textContent.trim().length > 0;
    
    if (hasText || hasOwnText || el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
        el.style.fontSize = '20px';
    }
});

// Style e koli baraye hame
const style = document.createElement('style');
style.textContent = `
    body { font-size: 20px !important; }
    div, p, span, a, li, td, button, input, textarea, 
    h1, h2, h3, h4, h5, h6, label, strong, b, i, em, 
    code, pre, blockquote, article, section, main, 
    header, footer, nav, aside, form, select, option {
        font-size: inherit !important;
    }
`;
document.head.appendChild(style);

}

;FONT17PX();

} finally { if (vc) vc.end(); } })();
