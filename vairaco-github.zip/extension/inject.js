// اجرای اسکریپت‌ها (همه لوکال، از داخل خود افزونه) با ردیاب Reset. هیچ کدی از اینترنت لود نمی‌شود.
import { RTL } from './scripts/rtl.js';
import { SCRIPTS } from './registry.js';

export const BY_ID = new Map(SCRIPTS.map(s => [s.id, s]));
const dirtyKey = tabId => 'dirty_' + tabId;
// اسکریپت‌هایی که Observer / شنونده / حذف المان باقی می‌گذارند: Reset بعدش یک بار تب را رفرش می‌کند تا ردی نماند
export async function isDirty(tabId) { const k = dirtyKey(tabId); return !!(await chrome.storage.session.get(k))[k]; }
export async function clearDirty(tabId) { await chrome.storage.session.remove(dirtyKey(tabId)); }

export async function runRtl(tabId) {
  await chrome.scripting.executeScript({ target: { tabId }, files: ['inject/tracker.js'] });
  return chrome.scripting.executeScript({ target: { tabId }, func: RTL });
}

// id → اجرا روی تب. ترتیب: ردیاب، فونت وزیر لوکال، خودِ اسکریپت (همه در یک تزریق، دنیای ISOLATED، سازگار با CSP)
export async function runScript(tabId, id) {
  const s = BY_ID.get(id);
  if (!s) throw new Error('NOT_AVAILABLE');
  if (s.kind === 'rtl') return runRtl(tabId);
  await chrome.scripting.executeScript({ target: { tabId }, files: ['inject/tracker.js', 'inject/vazir-faces.js', 'run/' + s.file] });
  if (s.sticky) await chrome.storage.session.set({ [dirtyKey(tabId)]: 1 });
}

// برگرداندن همه‌ی تغییرات ثبت‌شده‌ی هر اسکریپتی. خطا نباید ریست را متوقف کند.
export async function undoTracked(tabId) {
  try { await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, func: () => (globalThis.__vc ? globalThis.__vc.undo() : 0) }); } catch (e) { /* صفحه‌ی محافظت‌شده */ }
}
