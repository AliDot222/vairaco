// vairaco — MV3 (رایگان، کاملاً لوکال)
import { runRtl, runScript, undoTracked, BY_ID, isDirty, clearDirty } from "./inject.js";
import { ResetStyles } from "./scripts/reset-styles.js";      // فایل اصلی، بدون تغییر
import { ResetExtra, StashSiteStyles, RestoreSiteStyles } from "./scripts/reset-extra.js";   // تکمیل ریست: آثار باقی‌مانده
import { CursorEnable, CursorDisable } from "./scripts/cursor.js";                           // فایل اصلی، بدون تغییر
import { SCRIPTS } from "./registry.js";
import { loadRules, scriptsForUrl } from "./rules.js";

// ترتیب پیش‌فرض منو (مثل قبل)
const ORDER = ["FONT17PX", "GPT-Dev", "COPILOT_V2", "RTL", "Vazir", "G-A-P GPT", "Gemini", "GPT--MATH", "Claude-AI", "Google-AI-Studio"];
const RESET_ID = "Reset Styles";
// اگر در تب اسکریپتی اجرا شده که Observer / شنونده‌ی کپی / حذف المان باقی می‌گذارد (Gemini، Claude-AI، COPILOT_V2)،
// ریست بعد از پاک‌سازی صفحه را یک بار رفرش می‌کند تا «هیچ ردی» نماند. اگر نمی‌خواهید false کنید.
const RESET_RELOAD_DIRTY = true;

async function resetAll(tabId) {
  // هر مرحله مستقل است؛ در صفحه‌ی محافظت‌شده (chrome://، فروشگاه) یکی خطا بدهد بقیه متوقف نمی‌شوند
  let ok = 0;
  const step = async fn => { try { await fn(); ok++; } catch (e) { /* صفحه قابل دسترسی نیست */ } };
  await undoTracked(tabId);   // ۱) برگرداندن دقیق هر چیزی که هر اسکریپتی ساخته؛ بدون لیست
  await chrome.scripting.executeScript({ target: { tabId }, func: StashSiteStyles }).catch(() => {});             // استایل‌های سایت (Prism و...) که ریست اصلی به‌اشتباه می‌برد
  await step(() => chrome.scripting.executeScript({ target: { tabId }, func: ResetStyles }));                    // ۲) ریست اصلی (شبکه‌ی اطمینان)
  await chrome.scripting.executeScript({ target: { tabId }, func: RestoreSiteStyles }).catch(() => {});
  await step(() => chrome.scripting.executeScript({ target: { tabId, allFrames: true }, func: ResetExtra }));    // ۳) آثار باقی‌مانده، همه‌ی فریم‌ها
  if (!ok) throw new Error("PAGE_NOT_ACCESSIBLE");
  if (RESET_RELOAD_DIRTY && await isDirty(tabId)) { await clearDirty(tabId); await chrome.tabs.reload(tabId).catch(() => {}); return { reloaded: true }; }
  return { reloaded: false };
}

// ---------- منوی راست‌کلیک ----------
let menuChain = Promise.resolve();
function buildMenu() {   // پشت‌سرهم اجرا می‌شود تا ساخت هم‌زمان منو باعث خطای id تکراری نشود
  menuChain = menuChain.then(buildMenuNow).catch(() => {});
  return menuChain;
}
async function buildMenuNow() {
  await new Promise(res => chrome.contextMenus.removeAll(res));
  const add = (o) => chrome.contextMenus.create({ parentId: "mainMenu", contexts: ["page"], ...o }, () => void chrome.runtime.lastError);
  chrome.contextMenus.create({ id: "mainMenu", title: "vairaco", contexts: ["page"] }, () => void chrome.runtime.lastError);
  const { menuScripts } = await chrome.storage.local.get("menuScripts");
  let ids;
  if (Array.isArray(menuScripts)) ids = [...new Set(menuScripts)].filter(id => BY_ID.has(id));          // انتخاب کاربر، به همان ترتیب
  else { ids = ORDER.filter(id => BY_ID.has(id)); for (const s of SCRIPTS) if (!ids.includes(s.id)) ids.push(s.id); }   // پیش‌فرض: همه
  for (const id of ids) add({ id, title: BY_ID.get(id).title });
  add({ id: RESET_ID, title: RESET_ID });
  add({ id: "Cursor", title: "Cursor" });
  add({ id: "CursorEnable", parentId: "Cursor", title: "✓ Enable" });
  add({ id: "CursorDisable", parentId: "Cursor", title: "✗ Disable" });
}
chrome.runtime.onInstalled.addListener(() => buildMenu());
chrome.runtime.onStartup.addListener(buildMenu);
chrome.storage.onChanged.addListener((ch, area) => { if (area === "local" && ch.menuScripts) buildMenu(); });

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (!tab || !tab.id) return;
  const id = info.menuItemId;
  if (id === RESET_ID) return resetAll(tab.id).catch(() => {});
  if (id === "CursorEnable") return CursorEnable();
  if (id === "CursorDisable") return CursorDisable();
  if (BY_ID.has(id)) { try { await runScript(tab.id, id); } catch (e) { /* صفحه‌ی محافظت‌شده */ } }
});

// ---------- اجرای خودکار قوانین سایت ----------
const appliedKey = tabId => 'applied_' + tabId;   // هر تب یک کلید مستقل (دو تبِ هم‌زمان همدیگر را بازنویسی نمی‌کنند)
async function getApplied(tabId) { const k = appliedKey(tabId); return (await chrome.storage.session.get(k))[k] || null; }   // شناسه‌ی ناوبریِ اعمال‌شده
async function setApplied(tabId, navId) {
  if (navId) await chrome.storage.session.set({ [appliedKey(tabId)]: navId });
  else await chrome.storage.session.remove(appliedKey(tabId));
}
async function autoApply(tabId, url, stale = () => false) {
  const ids = scriptsForUrl(await loadRules(), url);
  for (const id of ids) {
    if (stale()) return;   // صفحه عوض شده؛ ادامه‌ی اسکریپت‌ها با قانونِ صفحه‌ی قبل اشتباه است
    try { await runScript(tabId, id); } catch (e) { /* خطای صفحه (مثلاً محافظت‌شده) بقیه را متوقف نکند */ }
  }
}

chrome.runtime.onMessage.addListener((msg, _s, send) => {
  if (msg.type === "reset") { resetAll(msg.tabId).then(r => send({ ok: true, reloaded: !!(r && r.reloaded) }), () => send({ ok: false })); return true; }
});

const inFlight = new Set();   // کلید: tabId:شناسه‌ی ناوبری
const gens = new Map();       // tabId → شناسه‌ی ناوبری جاری (هر loading یک شناسه‌ی تازه می‌گیرد)
const navReset = new Map();   // آخرین «پاک‌کردن پرچم‌های تب» که هنوز تمام نشده
let navCounter = 0;
const newNav = () => Date.now().toString(36) + '.' + (++navCounter);
chrome.tabs.onUpdated.addListener(async (tabId, ci, tab) => {
  if (ci.status === "loading") {
    gens.set(tabId, newNav());
    const p = Promise.resolve(clearDirty(tabId)).catch(() => {});
    navReset.set(tabId, p); p.then(() => { if (navReset.get(tabId) === p) navReset.delete(tabId); });
    return;
  }
  if (ci.status === "complete" && tab && tab.url) {
    try {
      if (navReset.has(tabId)) await navReset.get(tabId);
      let nav = gens.get(tabId);
      if (!nav) { nav = (await getApplied(tabId)) || newNav(); if (!gens.has(tabId)) gens.set(tabId, nav); nav = gens.get(tabId); }   // service worker بعد از خواب: همان ناوبریِ قبلی را ادامه بده
      const stale = () => gens.get(tabId) !== nav;     // کاربر وسط کار ناوبری کرد؟ این اجرا دیگر مال صفحه‌ی جاری نیست
      const key = tabId + ':' + nav;
      if (inFlight.has(key)) return;                    // دو complete برای «همین» صفحه هم‌زمان دوباره اجرا نشود
      inFlight.add(key);
      try {
        if ((await getApplied(tabId)) === nav || stale()) return;   // برای هر لود صفحه فقط یک بار
        await setApplied(tabId, nav);
        autoApply(tabId, tab.url, stale).catch(() => {});
      } finally { inFlight.delete(key); }
    } catch (e) { /* خطای storage نباید listener را بشکند */ }
  }
});
chrome.tabs.onRemoved.addListener(tabId => {
  clearDirty(tabId); setApplied(tabId, null);
  navReset.delete(tabId); gens.delete(tabId);
  for (const k of inFlight) if (k.startsWith(tabId + ':')) inFlight.delete(k);   // ورودی یتیم نماند
});
