# Contributing

Thanks for helping RTL users enjoy AI chats!

## Run locally
1. Clone the repo, open `chrome://extensions/`, enable Developer mode, **Load unpacked** → `extension/`.
2. After changing anything in `src-scripts/`, run `node tools/build-run.mjs` and reload the extension.

## Add a translation
Open `extension/i18n.js`, copy the `en` block, translate it, add the language to `LANGS` (and to `RTL_LANGS` if right-to-left). Optionally add `extension/_locales/<code>/messages.json` for the store name/description.

## Add or fix a site script
1. Put the script in `src-scripts/` and add an entry to `src-scripts/scripts.json` (`id`, `title`, `file`, optional `sites`, `sticky`).
2. Run `node tools/build-run.mjs`.
3. Scripts should make their DOM changes in a way the tracker can undo (see `extension/inject/tracker.js`), so *Reset Styles* leaves no trace.

## Rules
- No new network requests, no remote code, no analytics, no ads.
- Keep fonts local (Vazirmatn only).
- Test on a page with a strict CSP when touching injection code.
