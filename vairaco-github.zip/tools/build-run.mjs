// ساخت فایل‌های اجرایی افزونه از اسکریپت‌های اصلی (بدون هیچ تغییری در خود اسکریپت‌ها).
// اجرا:  node tools/build-run.mjs        (از پوشه‌ی اصلی پروژه)
// ورودی: src-scripts/*.js (+ src-scripts/scripts.json)     خروجی: extension/run/*.js و extension/registry.js
//
// اسکریپت‌های قدیمی با «export function X()» → export حذف و X() فراخوانی می‌شود؛ فایل ساده (بدون export) همان‌طور اجرا می‌شود.
// هر اسکریپت بین __vc.begin()/__vc.end() (ردیاب Reset) اجرا می‌شود تا Reset دقیق همه‌چیز را برگرداند.
import { readFileSync, writeFileSync, mkdirSync, readdirSync, unlinkSync, existsSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const SRC = join(root, 'src-scripts'), OUT = join(root, 'extension', 'run');
mkdirSync(OUT, { recursive: true });
const list = JSON.parse(readFileSync(join(SRC, 'scripts.json'), 'utf8'));
const keep = new Set(['vazir.js']);                                    // vazir.js دستی نوشته شده و پاک نمی‌شود
const reg = [{ id: 'RTL', title: 'RTL', kind: 'rtl' }, { id: 'Vazir', title: 'Vazir', file: 'vazir.js', desc: 'فونت وزیر روی کل صفحه' }];
for (const it of list) {
  let src = readFileSync(join(SRC, it.file), 'utf8').replace(/^﻿/, '');
  const m = src.match(/export\s+function\s+([A-Za-z0-9_$]+)\s*\(/);
  const body = m ? src.replace(/export\s+function/, 'function') + '\n;' + m[1] + '();\n' : src + '\n';
  const out = it.file;
  writeFileSync(join(OUT, out),
    '// تولیدشده توسط tools/build-run.mjs از src-scripts/' + it.file + ' (کد اصلی بدون تغییر)\n' +
    ';(() => { const vc = globalThis.__vc; if (vc) vc.begin();\ntry {\n' + body + '\n} finally { if (vc) vc.end(); } })();\n');
  keep.add(out);
  reg.push({ id: it.id, title: it.title || it.id, file: out, sites: it.sites || [], sticky: !!it.sticky });
}
for (const f of readdirSync(OUT)) if (!keep.has(f) && f.endsWith('.js')) unlinkSync(join(OUT, f));
writeFileSync(join(root, 'extension', 'registry.js'),
  '// فهرست اسکریپت‌ها؛ توسط tools/build-run.mjs ساخته می‌شود (دستی ویرایش نکنید)\nexport const SCRIPTS = ' + JSON.stringify(reg, null, 1) + ';\n');
console.log('OK: ' + list.length + ' اسکریپت ساخته شد.');
