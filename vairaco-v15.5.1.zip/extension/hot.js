// vairaco — instant apply. Edit or delete a file in my-scripts/ with any editor: the moment Chrome gets focus (or a tab is
// activated) every KNOWN file is re-read and each open tab that uses a changed script is updated. A brand-new file is
// discovered when the popup opens (only a window page can list a folder).
import { SCRIPTS as SEED } from './registry.js';
import { loadScripts, BY_ID, runScript, undoTracked, ranList, clearRan } from './inject.js';
import { loadRules, scriptsForUrl, matchHost, normalizeDomain } from './rules.js';
import { describe } from './userscripts.js';
import { logEv, badge } from './devlog.js';

// ids that should run on this URL by themselves: user rules + scripts with "// @auto" whose "// @sites" match
export async function idsForUrl(url) {
  await loadScripts();
  const ids = scriptsForUrl(await loadRules(), url);
  let host; try { const u = new URL(url); if (u.protocol !== 'http:' && u.protocol !== 'https:') return ids; host = u.hostname.toLowerCase(); } catch { return ids; }
  for (const s of BY_ID.values()) if (s.auto && (s.sites || []).some(d => { const n = normalizeDomain(d); return n && matchHost(host, n); }) && !ids.includes(s.id)) ids.push(s.id);
  return ids;
}

let chain = Promise.resolve();
const serial = fn => (chain = chain.catch(() => {}).then(fn));

// Re-read every file we already know (cheap, no UI). 404 = deleted. Any other failure keeps the old entry.
export function refresh() {
  return serial(async () => {
    const { scriptList: old, hashes: oldHashes, gone } = await chrome.storage.local.get(['scriptList', 'hashes', 'gone']);
    const base = Array.isArray(old) && old.length ? old : SEED;
    const read = async file => { let d = await describe(file); if (!d) { await new Promise(r => setTimeout(r, 200)); d = await describe(file); } return d; };   // editors that save by delete+rename: look twice
    const list = [], nowGone = [];
    for (const s of base) {
      try { const d = await read(s.file); if (d) list.push(d); else nowGone.push(s.file); }
      catch { list.push({ ...s, hash: (oldHashes || {})[s.id] }); }
    }
    for (const file of Array.isArray(gone) ? gone : []) {   // a deleted file that comes back (undo, git checkout...) is picked up again without opening the popup
      try { const d = await describe(file); if (d) list.push(d); else nowGone.push(file); } catch { nowGone.push(file); }
    }
    if (JSON.stringify(gone || []) !== JSON.stringify(nowGone)) await chrome.storage.local.set({ gone: nowGone });
    return commit(list);
  });
}
// The popup scanned the whole folder (it can) and hands us the full list, new files included.
export const ingest = list => serial(() => (Array.isArray(list) ? commit(list) : null));

async function commit(list) {
  const { scriptList: old, hashes: oldHashes } = await chrome.storage.local.get(['scriptList', 'hashes']);
  const hashes = Object.fromEntries(list.map(s => [s.id, s.hash]));
  const meta = list.map(({ hash, ...rest }) => rest);
  const changed = oldHashes ? [...new Set([...Object.keys(hashes), ...Object.keys(oldHashes)])].filter(id => hashes[id] !== oldHashes[id]) : [];
  if (JSON.stringify(old || null) !== JSON.stringify(meta)) await chrome.storage.local.set({ scriptList: meta });
  if (JSON.stringify(oldHashes || null) !== JSON.stringify(hashes)) await chrome.storage.local.set({ hashes });
  await loadScripts();
  if (changed.length) {
    const had = new Set(Object.keys(oldHashes || {}));
    for (const id of changed) await logEv(!(id in hashes) ? 'del' : had.has(id) ? 'chg' : 'new', id + '.js ' + (!(id in hashes) ? 'deleted' : had.has(id) ? 'changed (saved)' : 'found (new file)'));
    await hotApply(changed, old || []);
  }
  return meta;
}

async function hotApply(changed, oldList) {
  let applied = 0, reloaded = 0;
  const wasSticky = id => { const o = oldList.find(s => s.id === id); return !!(o && o.sticky); };
  for (const tab of await chrome.tabs.query({ url: ['http://*/*', 'https://*/*'] })) {
    try {
      const ran = await ranList(tab.id), want = await idsForUrl(tab.url);
      if (![...ran, ...want].some(id => changed.includes(id))) continue;        // this tab does not use a changed script
      const all = [...new Set([...ran, ...want])].filter(id => BY_ID.has(id));
      if (ran.some(id => wasSticky(id) || (BY_ID.get(id) || {}).sticky)) { await clearRan(tab.id); await chrome.tabs.reload(tab.id); reloaded++; continue; }   // observers/listeners left behind: a clean reload is the only honest undo
      await undoTracked(tab.id); await clearRan(tab.id);
      for (const id of all) await runScript(tab.id, id, true).catch(() => {});
      applied++;
    } catch { /* tab closed or protected */ }
  }
  const names = changed.filter(id => BY_ID.has(id)).map(id => id + '.js').join(', ');
  const { scriptErr } = await chrome.storage.local.get('scriptErr'), failed = changed.filter(id => scriptErr && scriptErr[id]);
  if (names && failed.length) { await logEv('err', `${failed.map(i => i + '.js').join(', ')} was applied but FAILED — see the red error in the file list`); return; }
  if (names) await logEv(applied || reloaded ? 'ok' : 'info', applied || reloaded ? `applied ${names} → ${applied} tab(s) updated${reloaded ? ', ' + reloaded + ' reloaded (sticky)' : ''}` : `${names}: no open tab uses it yet — add a rule or @auto, or press “Apply now”`);
}

// The always-works button: re-read everything, then re-run every script that belongs on this tab, from scratch.
export function applyNow(tabId) {
  return serial(async () => {
    const tab = await chrome.tabs.get(tabId);
    await loadScripts();
    const ran = await ranList(tabId), want = await idsForUrl(tab.url || '');
    const all = [...new Set([...want, ...ran])].filter(id => BY_ID.has(id));
    if (all.some(id => (BY_ID.get(id) || {}).sticky) && ran.length) { await clearRan(tabId); await chrome.tabs.reload(tabId); await logEv('ok', 'apply now → page reloaded (sticky script)'); return { ids: all, reloaded: true }; }
    await undoTracked(tabId); await clearRan(tabId);
    for (const id of all) await runScript(tabId, id, true).catch(() => {});
    await logEv(all.length ? 'ok' : 'info', all.length ? 'apply now → ' + all.map(i => i + '.js').join(', ') : 'apply now → nothing belongs on this tab (no rule, no @auto match)');
    return { ids: all, reloaded: false };
  });
}
// what vairaco expects on this tab vs what actually ran there
export async function diagnose(tabId) {
  const tab = await chrome.tabs.get(tabId);
  await loadScripts();
  let host = ''; try { host = new URL(tab.url).hostname; } catch { /* internal page */ }
  const ok = /^https?:/i.test(tab.url || '');
  return { host, ok, want: ok ? await idsForUrl(tab.url) : [], ran: ok ? (await ranList(tabId)).filter(id => BY_ID.has(id)) : [] };
}
