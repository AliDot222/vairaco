// vairaco — what just happened, in plain words, for the script author (shown in the popup, "My scripts" tab) + a tiny badge on the toolbar icon.
export async function logEv(kind, msg) {
  try {
    const { devLog } = await chrome.storage.local.get('devLog'), a = Array.isArray(devLog) ? devLog : [];
    if (a[0] && a[0].k === kind && a[0].m === msg && Date.now() - a[0].t < 1500) return;   // same event twice in a row
    a.unshift({ t: Date.now(), k: kind, m: String(msg).slice(0, 220) });
    await chrome.storage.local.set({ devLog: a.slice(0, 25) });
  } catch { /* logging must never break a run */ }
}
// ✓ = scripts ran on this tab, ! = a script failed. Chrome clears a tab's badge by itself when the tab navigates.
export async function badge(tabId, bad) {
  try {
    await chrome.action.setBadgeText({ tabId, text: bad ? '!' : '✓' });
    await chrome.action.setBadgeBackgroundColor({ tabId, color: bad ? '#b42318' : '#0f766e' });
  } catch { /* tab gone */ }
}
export const clearBadge = tabId => chrome.action.setBadgeText({ tabId, text: '' }).catch(() => {});
