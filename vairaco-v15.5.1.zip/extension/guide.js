// vairaco guide — language, light/dark theme (light by default), copy buttons. No network; works when the file is double-clicked too.
(() => {
  const root = document.documentElement;
  const L = { fa: { copy: 'کپی', ok: 'کپی شد ✓' }, en: { copy: 'Copy', ok: 'Copied ✓' } };
  const get = k => { try { return localStorage.getItem(k); } catch (e) { return null; } };
  const put = (k, v) => { try { localStorage.setItem(k, v); } catch (e) {} };
  const lang = () => (root.dataset.lang === 'en' ? 'en' : 'fa');

  function setLang(l) {
    root.dataset.lang = l; root.lang = l; root.dir = l === 'fa' ? 'rtl' : 'ltr'; put('vc-guide-lang', l);
    document.querySelectorAll('.cb button').forEach(b => { b.textContent = L[b.closest('.fa') ? 'fa' : 'en'].copy; b.classList.remove('ok'); });
  }
  function setTheme(t) { root.dataset.theme = t; put('vc-guide-theme', t); document.getElementById('theme').textContent = t === 'dark' ? '☾' : '☀'; }

  document.querySelectorAll('[data-set]').forEach(b => b.addEventListener('click', () => setLang(b.dataset.set)));
  document.getElementById('theme').addEventListener('click', () => setTheme(root.dataset.theme === 'dark' ? 'light' : 'dark'));

  document.querySelectorAll('.cb').forEach(cb => {
    const pre = cb.querySelector('pre'), b = cb.querySelector('button'); if (!b) return;
    b.type = 'button';
    b.onclick = async () => {
      const text = pre.innerText.trim() + '\n', l = b.closest('.fa') ? 'fa' : 'en';
      try { await navigator.clipboard.writeText(text); }
      catch (e) { const t = document.createElement('textarea'); t.value = text; document.body.append(t); t.select(); try { document.execCommand('copy'); } catch (_) {} t.remove(); }
      b.textContent = L[l].ok; b.classList.add('ok'); setTimeout(() => { b.textContent = L[l].copy; b.classList.remove('ok'); }, 1600);
    };
  });

  try { document.getElementById('ver').textContent = 'v' + chrome.runtime.getManifest().version; } catch (e) { /* opened as a plain file */ }
  const saved = get('vc-guide-lang');
  setLang(saved === 'fa' || saved === 'en' ? saved : ((navigator.language || '').toLowerCase().startsWith('fa') ? 'fa' : 'en'));
  setTheme(get('vc-guide-theme') === 'dark' ? 'dark' : 'light');     // light unless you chose dark
})();
