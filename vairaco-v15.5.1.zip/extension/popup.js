import { scanInfo } from './userscripts.js';
import { runScript, BY_ID, loadScripts } from './inject.js';
import { SCRIPTS as SEED } from './registry.js';
import { UPDATE_URL } from './config.js';
import { scanScripts } from './userscripts.js';
import { t, setLang, getLang, guessLang, applyI18n, LANGS } from './i18n.js';
import { normalizeDomain, matchHost, loadRules, saveRules, newRuleId } from './rules.js';

const $ = id => document.getElementById(id);
const show = (id, on = true) => $(id).classList.toggle('hidden', !on);
const setMsg = (id, t, ok = false) => { $(id).textContent = t || ''; $(id).classList.toggle('ok', ok); };
const store = (k) => chrome.storage.local.get(k);
const CUR = chrome.runtime.getManifest().version;

// ---------- تب‌ها ----------
function openTab(name) {
  if (!document.getElementById('tab-' + name)) name = 'rules';
  document.querySelectorAll('.tabs button').forEach(b => b.classList.toggle('on', b.dataset.tab === name));
  document.querySelectorAll('.panel').forEach(p => p.classList.toggle('on', p.id === 'tab-' + name));
  chrome.storage.local.set({ lastTab: name });
}
document.querySelectorAll('.tabs button').forEach(b => { b.onclick = () => openTab(b.dataset.tab); });

// ---------- GitHub link ----------
const openUpdates = () => chrome.tabs.create({ url: UPDATE_URL });
$('btn-updates').onclick = openUpdates;

// ---------- اسکریپت‌ها (همه لوکال و رایگان) ----------
let AVAILABLE = SEED.filter(s => !s.bad).map(s => ({ id: s.id, title: s.title, sites: s.sites || [] })), ACTIVE = null, RULES = [];
const infoOf = id => AVAILABLE.find(a => a.id === id);
const runScriptById = (tabId, id) => runScript(tabId, id, true);
const explain = e => t('runFail', e && e.message ? e.message : t('noAccess'));

function makeChip(id, opts = {}) {
  const info = infoOf(id);
  const el = document.createElement('span');
  el.className = 'chip' + (info ? '' : ' locked');
  const label = document.createElement('span');
  label.textContent = (info ? '' : '🔒 ') + (info ? info.title : id);
  el.dataset.id = id;
  el.append(label);
  if (!info) el.title = t('missing');
  if (info) {
    el.draggable = true;
    el.addEventListener('dragstart', e => {
      e.dataTransfer.setData('text/plain', JSON.stringify({ id, from: opts.from || null }));
      e.dataTransfer.effectAllowed = 'copyMove';
    });
  }
  if (opts.onRemove) {
    const x = document.createElement('button'); x.className = 'x'; x.type = 'button'; x.textContent = '×'; x.title = t('removeSite');
    x.onclick = opts.onRemove; el.append(x);
  }
  return el;
}

// ---------- تب «اسکریپت‌ها» (اجرای دستی) ----------
function renderScripts() {
  $('scriptList').innerHTML = '';
  AVAILABLE.forEach(a => {
    const b = document.createElement('button'); b.className = 'chip btnchip'; b.type = 'button'; b.textContent = a.title;
    b.onclick = async () => {
      if (!ACTIVE) return setMsg('msg-scripts', t('tabNoAccess'));
      try { await runScriptById(ACTIVE.id, a.id); setMsg('msg-scripts', t('applied', a.title), true); }
      catch (e) { setMsg('msg-scripts', explain(e)); }
    };
    $('scriptList').append(b);
  });
}
$('btn-reset').onclick = async () => {
  if (!ACTIVE) return setMsg('msg-scripts', t('tabNoAccess'));
  const r = await chrome.runtime.sendMessage({ type: 'reset', tabId: ACTIVE.id });
  setMsg('msg-scripts', r && r.ok ? (r.reloaded ? t('resetReload') : t('resetDone')) + (r.restored ? ' ' + t('resetCount', r.restored) : '') : t('resetNo'), !!(r && r.ok));
};

// ---------- تب «قوانین سایت» ----------
let saveTimer = null;
function persist() { saveRules(RULES); }   // فوری ذخیره می‌شود (پاپ‌آپ ممکن است بلافاصله بسته شود)

function activeHost() {
  try { const u = new URL(ACTIVE.url); return /^https?:$/.test(u.protocol) ? u.hostname.toLowerCase() : null; } catch { return null; }
}
async function applyNow(rule, id) {   // اگر همین الان روی همان سایت هستید، اسکریپتِ تازه‌اضافه‌شده فوراً اعمال شود
  const h = ACTIVE && activeHost();
  if (!h || rule.enabled === false || !rule.domain || !matchHost(h, rule.domain)) return;
  try { await runScriptById(ACTIVE.id, id); setMsg('msg-rules', t('appliedHere'), true); }
  catch (e) { if (e.message !== 'NOT_AVAILABLE') setMsg('msg-rules', explain(e)); }
}
function addToRule(rule, id, from, beforeId) {
  const had = rule.scripts.includes(id);
  if (had) rule.scripts = rule.scripts.filter(s => s !== id);      // جابجایی = تغییر ترتیب اجرا
  const at = beforeId ? rule.scripts.indexOf(beforeId) : -1;
  if (at >= 0) rule.scripts.splice(at, 0, id); else rule.scripts.push(id);
  if (from && from !== rule.id) { const src = RULES.find(x => x.id === from); if (src) src.scripts = src.scripts.filter(s => s !== id); }
  persist(); renderRules(); if (!had) applyNow(rule, id);
}

function renderPalette() {
  $('palette').innerHTML = '';
  AVAILABLE.forEach(a => $('palette').append(makeChip(a.id)));
  show('btn-suggest', AVAILABLE.some(a => a.sites && a.sites.length));
}

function renderRules() {
  const list = $('ruleList');
  list.innerHTML = '';
  show('rulesEmpty', RULES.length === 0);
  RULES.forEach(r => {
    const card = document.createElement('div'); card.className = 'rule' + (r.enabled === false ? ' off' : ''); card.dataset.id = r.id;

    const head = document.createElement('div'); head.className = 'rhead';
    const inp = document.createElement('input'); inp.className = 'dom'; inp.type = 'text'; inp.placeholder = t('sitePh'); inp.value = r.domain || '';
    inp.onchange = () => {
      const raw = inp.value.trim();
      if (!raw) { r.domain = ''; inp.classList.remove('bad'); persist(); return; }
      const d = normalizeDomain(raw);
      if (!d) { inp.classList.add('bad'); setMsg('msg-rules', t('badDomain')); return; }
      inp.classList.remove('bad'); setMsg('msg-rules', ''); r.domain = d; inp.value = d; persist();
    };
    const sw = document.createElement('label'); sw.className = 'sw'; sw.title = t('toggle');
    const cb = document.createElement('input'); cb.type = 'checkbox'; cb.checked = r.enabled !== false;
    cb.onchange = () => { r.enabled = cb.checked; persist(); renderRules(); };
    const knob = document.createElement('span'); sw.append(cb, knob);
    const del = document.createElement('button'); del.className = 'btn red small'; del.type = 'button'; del.textContent = t('delSite');
    del.onclick = () => { RULES = RULES.filter(x => x.id !== r.id); persist(); renderRules(); };
    head.append(inp, sw, del);

    const drop = document.createElement('div'); drop.className = 'drop';
    if (!r.scripts.length) { const h = document.createElement('span'); h.className = 'hint'; h.textContent = t('dropHint'); drop.append(h); }
    r.scripts.forEach(id => drop.append(makeChip(id, {
      from: r.id,
      onRemove: () => { r.scripts = r.scripts.filter(s => s !== id); persist(); renderRules(); }
    })));
    drop.addEventListener('dragover', e => { e.preventDefault(); drop.classList.add('over'); });
    drop.addEventListener('dragleave', () => drop.classList.remove('over'));
    drop.addEventListener('drop', e => {
      e.preventDefault(); drop.classList.remove('over');
      try { const d = JSON.parse(e.dataTransfer.getData('text/plain')); if (d && typeof d.id === 'string') { const c = e.target.closest && e.target.closest('.chip'); addToRule(r, d.id, d.from, c && c.dataset.id !== d.id ? c.dataset.id : null); } } catch { /* داده‌ی نامربوط */ }
    });

    // جایگزین بدون درگ (موبایل/دسترسی‌پذیری)
    const sel = document.createElement('select'); sel.style.marginTop = '8px';
    const o0 = document.createElement('option'); o0.value = ''; o0.textContent = t('addScript'); sel.append(o0);
    AVAILABLE.filter(a => !r.scripts.includes(a.id)).forEach(a => { const o = document.createElement('option'); o.value = a.id; o.textContent = a.title; sel.append(o); });
    sel.onchange = () => { if (sel.value) addToRule(r, sel.value, null); };

    card.append(head, drop, sel);
    list.append(card);
  });
}

function addRule(domain) {
  if (domain && RULES.some(r => r.domain === domain)) { setMsg('msg-rules', t('dup')); return; }
  if (RULES.length >= 100) { setMsg('msg-rules', t('max100')); return; }
  RULES.unshift({ id: newRuleId(), domain: domain || '', scripts: [], enabled: true });
  setMsg('msg-rules', ''); persist(); renderRules();
  if (!domain) { const i = document.querySelector('.rule .dom'); if (i) i.focus(); }
}
$('btn-add-rule').onclick = () => addRule('');
$('btn-add-current').onclick = () => { const h = ACTIVE && activeHost(); const d = h && normalizeDomain(h); if (d) addRule(d); else setMsg('msg-rules', t('notNormal')); };
$('btn-suggest').onclick = () => {
  let added = 0;
  AVAILABLE.forEach(a => (a.sites || []).forEach(site => {
    const d = normalizeDomain(site); if (!d) return;
    let r = RULES.find(x => x.domain === d);
    if (!r) { r = { id: newRuleId(), domain: d, scripts: [], enabled: true }; RULES.unshift(r); }
    if (!r.scripts.includes(a.id)) { r.scripts.push(a.id); added++; }
  }));
  persist(); renderRules(); setMsg('msg-rules', added ? t('sugAdded', added) : t('sugNone'), !!added);
};

// ---------- تب «منوی راست‌کلیک» ----------
let MENU = null, SEEN = [];     // MENU: null = همه نمایش داده می‌شوند؛ آرایه = فقط همین‌ها به همین ترتیب
const materialize = () => { if (MENU === null) MENU = AVAILABLE.map(a => a.id); };
function saveMenu() { chrome.storage.local.set({ menuScripts: MENU }); }
function menuAdd(id, beforeId) {
  materialize();
  MENU = MENU.filter(x => x !== id);
  const at = beforeId ? MENU.indexOf(beforeId) : -1;
  if (at >= 0) MENU.splice(at, 0, id); else MENU.push(id);
  saveMenu(); renderMenuTab();
}
function renderMenuTab() {
  const list = MENU === null ? AVAILABLE.map(a => a.id) : MENU;
  const drop = $('menuDrop'); drop.innerHTML = '';
  $('menuCount').textContent = MENU === null ? t('menuAllCount', list.length) : '(' + list.filter(id => infoOf(id)).length + ')';
  if (!list.length) { const h = document.createElement('span'); h.className = 'hint'; h.textContent = t('menuEmpty'); drop.append(h); }
  list.forEach(id => drop.append(makeChip(id, {
    from: 'menu',
    onRemove: () => { materialize(); MENU = MENU.filter(x => x !== id); saveMenu(); renderMenuTab(); }
  })));
  drop.ondragover = e => { e.preventDefault(); drop.classList.add('over'); };
  drop.ondragleave = () => drop.classList.remove('over');
  drop.ondrop = e => {
    e.preventDefault(); drop.classList.remove('over');
    try {
      const d = JSON.parse(e.dataTransfer.getData('text/plain'));
      if (d && typeof d.id === 'string') { const c = e.target.closest && e.target.closest('.chip'); menuAdd(d.id, c && c.dataset.id !== d.id ? c.dataset.id : null); }
    } catch { /* داده‌ی نامربوط */ }
  };
  const q = $('menuSearch').value.trim().toLowerCase();
  const inMenu = new Set(list);
  $('palette2').innerHTML = '';
  AVAILABLE.filter(a => !q || a.title.toLowerCase().includes(q) || a.id.toLowerCase().includes(q) || (a.sites || []).some(x => String(x).toLowerCase().includes(q))).forEach(a => {
    const c = makeChip(a.id);
    if (inMenu.has(a.id)) c.classList.add('inmenu');
    if (!SEEN.includes(a.id)) { c.classList.add('new'); c.dataset.new = { fa: 'جدید', ar: 'جديد', en: 'new' }[getLang()]; }
    c.onclick = () => { if (!inMenu.has(a.id)) menuAdd(a.id, null); };
    $('palette2').append(c);
  });
}
$('menuSearch').oninput = renderMenuTab;
$('btn-menu-all').onclick = () => { MENU = null; saveMenu(); renderMenuTab(); setMsg('msg-menu', t('menuAllMsg'), true); };
$('btn-menu-clear').onclick = () => { MENU = []; saveMenu(); renderMenuTab(); setMsg('msg-menu', ''); };
async function loadMenu() {
  const o = await store(['menuScripts', 'seenScripts']);
  MENU = Array.isArray(o.menuScripts) ? o.menuScripts : null; SEEN = Array.isArray(o.seenScripts) ? o.seenScripts : [];
}
async function markSeen() {   // برچسب «جدید» فقط تا وقتی تب منو را ببینید می‌ماند
  const ids = AVAILABLE.map(a => a.id);
  if (ids.some(id => !SEEN.includes(id))) { SEEN = ids; await chrome.storage.local.set({ seenScripts: ids }); }
}


async function refreshUi() { renderFiles(LAST_FILES, LAST_ERRS); renderDev(); await loadMenu(); renderScripts(); renderPalette(); renderRules(); renderMenuTab(); }

function mountLang(cur) {
  const sel = $('lang'); sel.innerHTML = '';
  for (const [k, v] of Object.entries(LANGS)) { const o = document.createElement('option'); o.value = k; o.textContent = v; sel.append(o); }
  sel.value = cur;
  sel.onchange = async () => { await chrome.storage.local.set({ lang: sel.value }); setLang(sel.value); applyI18n(); $('ver').textContent = t('ver', CUR); await refreshUi(); };
}
async function init() {
  const { lang } = await store('lang'); const L = LANGS[lang] ? lang : guessLang();
  setLang(L); applyI18n(); mountLang(L);
  $('ver').textContent = t('ver', CUR);
  const [{ lastTab }, tabs, rules] = await Promise.all([store('lastTab'), chrome.tabs.query({ active: true, currentWindow: true }), loadRules()]);
  RULES = rules;
  // اسکن کامل پوشه (فقط صفحه‌ی پنجره‌ای می‌تواند پوشه را لیست کند) و دادن آن به background: فایل تازه همین لحظه اعمال می‌شود
  let list = await scanScripts().catch(() => null);
  list = await chrome.runtime.sendMessage(list ? { type: 'ingest', list } : { type: 'refresh' }).then(r => r && r.list, () => null) || (list && list.map(({ hash, ...r }) => r));
  renderFiles(list, (await store('scriptErr')).scriptErr || {});
  if (list) { await loadScripts(); AVAILABLE = list.filter(u => !u.bad).map(u => ({ id: u.id, title: u.title, sites: u.sites })); }
  ACTIVE = tabs[0] ? { id: tabs[0].id, url: tabs[0].url || '' } : null;
  const h = ACTIVE && activeHost(); const d = h && normalizeDomain(h);
  $('curSite').textContent = d ? '(' + d + ')' : '';
  $('btn-add-current').disabled = !d;
  openTab(lastTab || 'rules');
  await refreshUi();
  renderDev();
}
init();

// ---------- خروجی / ورودی تنظیمات (برای انتقال به پروفایل‌های دیگر) ----------
function exportRules() {
  const data = { app: 'vairaco-rules', v: 1, rules: RULES.map(r => ({ domain: r.domain, scripts: r.scripts, enabled: r.enabled !== false })) };
  return JSON.stringify(data, null, 1);
}
$('btn-export').onclick = async () => {
  const txt = exportRules();
  try { await navigator.clipboard.writeText(txt); setMsg('msg-rules', t('copied'), true); }
  catch { $('ioBox').classList.remove('hidden'); $('ioText').value = txt; $('ioText').select(); setMsg('msg-rules', t('copyManual')); }
};
$('btn-import').onclick = () => { $('ioBox').classList.toggle('hidden'); $('ioText').value = ''; $('ioText').focus(); };
$('btn-import-go').onclick = () => {
  let d;
  try { d = JSON.parse($('ioText').value); } catch { return setMsg('msg-rules', t('badText')); }
  if (!d || d.app !== 'vairaco-rules' || !Array.isArray(d.rules)) return setMsg('msg-rules', t('notOurs'));
  let n = 0;
  for (const x of d.rules) {
    const dom = normalizeDomain(x && x.domain); if (!dom || !Array.isArray(x.scripts)) continue;
    const scripts = [...new Set(x.scripts.filter(s => typeof s === 'string'))].slice(0, 50);
    const ex = RULES.find(r => r.domain === dom);
    if (ex) { ex.scripts = scripts; ex.enabled = x.enabled !== false; }
    else if (RULES.length < 100) RULES.push({ id: newRuleId(), domain: dom, scripts, enabled: x.enabled !== false });
    else continue;
    n++;
  }
  persist(); renderRules(); $('ioBox').classList.add('hidden');
  setMsg('msg-rules', t('imported', n), true);
};


// ---------- تب «اسکریپت من»: راهنمای ویرایش با نوت‌پد + لیست فایل‌ها ----------
let LAST_FILES = [], LAST_ERRS = {};
function renderFiles(list, errs = {}) {
  LAST_FILES = list || []; LAST_ERRS = errs;
  const box = $('fileList'); box.textContent = '';
  const info = document.createElement('div'); info.dir = 'ltr'; info.className = 'soft'; info.style.marginBottom = '4px';
  info.textContent = scanInfo.names ? 'my-scripts/: ' + scanInfo.names.filter(n => /\.js$/i.test(n)).length + ' .js file(s)' + (scanInfo.names.some(n => !/\.js$/i.test(n)) ? ' · ignored: ' + scanInfo.names.filter(n => !/\.js$/i.test(n)).join(', ') : '') : 'my-scripts/: could not read the folder (' + (scanInfo.why || 'not scanned') + ')';
  box.append(info);
  const d = document.createElement('div'); d.className = 'soft'; d.style.marginBottom = '6px'; d.textContent = t('edDetect'); info.after(d);
  if (!list || !list.length) { const m = document.createElement('div'); m.textContent = t('edNoFiles'); box.append(m); return; }
  for (const s of list) {
    const row = document.createElement('div'); row.dir = 'ltr'; row.style.cssText = 'display:flex;gap:6px;align-items:center;margin:2px 0';
    const n = document.createElement('code'); n.textContent = s.file; row.append(n);
    if (errs[s.id]) { const w = document.createElement('span'); w.textContent = '✖ ' + errs[s.id]; w.style.color = 'var(--bad)'; w.dir = 'ltr'; row.append(w); }
    else if (s.bad) { const w = document.createElement('span'); w.textContent = '⚠ ' + t('edBad'); w.style.color = 'var(--bad)'; row.append(w); }
    else if (s.auto) { const a = document.createElement('span'); a.textContent = '● ' + t('edAutoTag') + (s.sites.length ? ' · ' + s.sites.join(', ') : ''); a.style.color = 'var(--ok)'; row.append(a); }
    const go = document.createElement('button'); go.className = 'btn ghost small'; go.textContent = '▶'; go.title = t('edRun'); go.style.marginInlineStart = 'auto';
    go.onclick = async () => { if (!ACTIVE) return setMsg('msg-edit', t('tabNoAccess')); try { await runScriptById(ACTIVE.id, s.id); setMsg('msg-edit', t('applied', s.file), true); } catch (e) { setMsg('msg-edit', explain(e)); } renderDev(); };
    row.append(go);
    box.append(row);
  }
}
// ---------- "what is happening" for the script author ----------
const hhmmss = ms => new Date(ms).toLocaleTimeString([], { hour12: false });
async function renderDev() {
  const box = $('devLog'); if (!box) return;
  const { devLog } = await store('devLog'), a = Array.isArray(devLog) ? devLog : [];
  box.textContent = '';
  if (!a.length) { const m = document.createElement('div'); m.className = 'soft'; m.textContent = t('edLogEmpty'); box.append(m); }
  for (const e of a.slice(0, 12)) {
    const r = document.createElement('div'); r.className = 'soft'; r.dir = 'ltr'; r.style.cssText = 'margin:1px 0;word-break:break-word';
    if (e.k === 'err') r.style.color = 'var(--bad)'; else if (e.k === 'ok' || e.k === 'new' || e.k === 'chg') r.style.color = 'var(--ok)';
    r.textContent = hhmmss(e.t) + '  ' + e.m; box.append(r);
  }
  const el = $('tabNow'); el.textContent = '';
  if (!ACTIVE) { el.textContent = t('tabNoAccess'); return; }
  const d = await chrome.runtime.sendMessage({ type: 'diag', tabId: ACTIVE.id }).catch(() => null);
  if (!d || !d.ok) { el.textContent = t('edTabNo'); return; }
  const none = t('edNoneWord'), j = x => x.length ? x.map(i => i + '.js').join(', ') : none;
  const line = document.createElement('div'); line.dir = 'ltr'; line.textContent = t('edTabLine', d.host, j(d.ran), j(d.want)); el.append(line);
  const miss = d.want.filter(i => !d.ran.includes(i));
  const hint = document.createElement('div'); hint.style.cssText = 'margin-top:4px;color:var(--warn)';
  if (!d.want.length) { hint.textContent = t('edTabNothing'); el.append(hint); }
  else if (miss.length) { hint.textContent = t('edTabMiss', j(miss)); el.append(hint); }
}
$('btn-apply').onclick = async () => {
  if (!ACTIVE) return setMsg('msg-apply', t('tabNoAccess'));
  setMsg('msg-apply', '…');
  try {
    const list = await scanScripts().catch(() => null);                                   // pick up brand-new files first
    if (list) { await chrome.runtime.sendMessage({ type: 'ingest', list }); await loadScripts(); AVAILABLE = list.filter(u => !u.bad).map(u => ({ id: u.id, title: u.title, sites: u.sites })); renderFiles(list, (await store('scriptErr')).scriptErr || {}); }
    const r = await chrome.runtime.sendMessage({ type: 'applyNow', tabId: ACTIVE.id });
    if (!r || !r.ok) setMsg('msg-apply', t('edApplyFail', (r && r.error) || '?'));
    else if (!r.ids.length) setMsg('msg-apply', t('edApplyNone'));
    else setMsg('msg-apply', t('edApplyOk', r.ids.map(i => i + '.js').join(', ')), true);
  } catch (e) { setMsg('msg-apply', t('edApplyFail', e && e.message ? e.message : '?')); }
  renderDev();
};
$('btn-logclear').onclick = async () => { await chrome.storage.local.set({ devLog: [] }); renderDev(); };
const openGuide = () => chrome.tabs.create({ url: chrome.runtime.getURL('guide.html') });
$('btn-guide').onclick = openGuide;
$('btn-tpl').onclick = async () => {
  try { await navigator.clipboard.writeText(t('edTemplate')); setMsg('msg-edit', t('edTplDone'), true); }
  catch { setMsg('msg-edit', t('copyManual')); }
};

chrome.storage.onChanged.addListener(async (ch, area) => {
  if (area !== 'local') return;
  if (ch.devLog) renderDev();
  if (ch.scriptErr) { const o = await store('scriptList'); renderFiles(o.scriptList || [], ch.scriptErr.newValue || {}); }
  if (ch.rules && JSON.stringify(ch.rules.newValue || []) !== JSON.stringify(RULES)) { RULES = await loadRules(); renderRules(); }   // از پروفایل دیگر / از فایل رسید
  if (ch.menuScripts && JSON.stringify(ch.menuScripts.newValue || null) !== JSON.stringify(MENU)) { const o = await store('menuScripts'); MENU = Array.isArray(o.menuScripts) ? o.menuScripts : null; renderMenuTab(); }
});
