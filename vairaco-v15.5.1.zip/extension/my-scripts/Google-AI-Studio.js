// @title Google AI Studio
// @sites aistudio.google.com
(() => {
  'use strict';

  const FONT_NAME = 'Vazirmatn';

  // فونت وزیر «لوکال»: از پوشهٔ my-scripts/fonts خودِ افزونه می‌آید (به‌جای لینک CDN که قبلاً اینجا بود).
  // دو راه هم‌زمان: ۱) inject/vazir-faces.js با FontFace API  ۲) همین @font-face که جای لینک قبلی نشسته (بیمهٔ هم‌دیگر).
  if (!document.getElementById('fa-font-link') && typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getURL) {
    const link = document.createElement('style');
    link.id = 'fa-font-link';
    link.textContent = [['Light', '100 300'], ['Regular', '400'], ['Medium', '500 600'], ['Bold', '700'], ['ExtraBold', '800'], ['Black', '900']]
      .map(([f, w]) => `@font-face{font-family:'${FONT_NAME}';font-style:normal;font-weight:${w};font-display:swap;src:url("${chrome.runtime.getURL('my-scripts/fonts/Vazirmatn-' + f + '.woff2')}") format('woff2');}`)
      .join('\n');
    document.head.appendChild(link);
  }

  if (!document.getElementById('fa-dir-style')) {
    const style = document.createElement('style');
    style.id = 'fa-dir-style';
    style.textContent = `
        textarea[cdktextareaautosize] {
          direction: rtl;
          unicode-bidi: plaintext;
          text-align: start;
          font-family: '${FONT_NAME}', Tahoma, sans-serif !important;
          line-height: 1.9 !important;
        }

        .bubble p,
        .bubble li,
        .bubble h1,
        .bubble h2,
        .bubble h3,
        .bubble h4,
        .bubble blockquote,
        .bubble td,
        .bubble th {
          direction: rtl;
          unicode-bidi: plaintext;
          text-align: start !important;
          font-family: '${FONT_NAME}', Tahoma, sans-serif !important;
          line-height: 1.9 !important;
        }

        .bubble ul,
        .bubble ol {
          padding-inline-start: 1.5em;
        }

        .bubble .inline-code {
          direction: ltr;
          unicode-bidi: embed;
          font-family: 'Consolas', 'Courier New', monospace !important;
        }
      `;
    document.head.appendChild(style);
  }

  console.log('Google AI Studio Persian font and direction styles are active.');
})();
