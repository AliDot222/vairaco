// vairaco — Reset Styles: یک فایل برای همه‌ی ریست (جایگزین reset-styles.js و reset-extra.js).
// ترتیب کار: ۱) استایل‌های خودِ سایت که به‌اشتباه در خطرند کنار گذاشته می‌شوند → ۲) ریست اصلی (کد قدیمیِ خودتان) →
//            ۳) برگرداندن استایل‌های سایت → ۴) پاک‌کردن آثار باقی‌مانده (در همه‌ی فریم‌ها).
// مهم: قبل از همه‌ی این‌ها خودِ افزونه هر تغییری را که اسکریپت‌ها ساخته‌اند «دقیق» برمی‌گرداند (ردیاب)، پس معمولاً لازم نیست این فایل را عوض کنید.
// فقط اگر اسکریپتتان چیزی ساخت که با Reset نرفت، همین‌جا در بخش «ویرایش» اسمش را اضافه کنید و افزونه را در chrome://extensions ↻ کنید.
export function ResetAll() {
  // ✏️ ===================== بخش ویرایش (فقط اینجا را عوض کنید) =====================
  // شناسه‌ی <style> و <link>هایی که اسکریپت‌های شما می‌سازند و Reset باید حذف کند:
  const IDS = ['tm-persian-font-style', 'claude-fa-style', 'fa-dir-style', 'sc-rtl-style', 'sc-font-style',
    'claude-fa-link', 'claude-fa-link2', 'claude-fa-link3', 'fa-font-link', 'sc-font-link'];
  // چیزهایی که اسکریپت‌های شما در مرورگر «ذخیره» می‌کنند و با رفرش هم نمی‌روند (فقط اسم‌هایی که خودتان ساخته‌اید، نه اسم‌های خود سایت):
  const MY_LOCALSTORAGE_KEYS = [];   // مثال: ['my-theme', 'my-size']
  const MY_COOKIES = [];             // مثال: ['my-flag']   (فقط کوکی‌های path=/ )
  // ✏️ ============================== پایان بخش ویرایش ==============================

  const IS_TOP = window === window.top;

  // ---------- ۱ و ۳) محافظت از استایل‌های خود سایت ----------
  function StashSiteStyles() {
    try {
      const STRONG = ['Vazir', 'IranSans', 'IRANSans', 'Fira Code', 'tm-persian-font-applied', '.custom-rtl', 'unicode-bidi: plaintext', 'mjx-container', 'sc-rtl-style', 'sc-font-style'];   // font-size: 20px عمداً نیست (در CSS سایت‌ها رایج است)
      const OWN_IDS = ['tm-persian-font-style', 'claude-fa-style', 'fa-dir-style', 'sc-rtl-style', 'sc-font-style'];
      const keep = [];
      document.querySelectorAll('style').forEach(s => {
        const t = s.textContent || '';
        if (OWN_IDS.includes(s.id)) return;
        if (!(t.includes('language-') || t.includes('box-content'))) return;
        if (STRONG.some(m => t.includes(m))) return;
        keep.push({ el: s, parent: s.parentNode });
      });
      // جای هر استایل = اولین همسایه‌ی بعدی که خودش کنار گذاشته نشده (تا چند استایل کنار هم با ترتیب اصلی برگردند)
      const set = new Set(keep.map(k => k.el));
      keep.forEach(k => { let n = k.el.nextSibling; while (n && set.has(n)) n = n.nextSibling; k.next = n; });
      globalThis.__vcStash = keep;
    } catch (e) { globalThis.__vcStash = []; console.warn('[vairaco] stash failed', e); }
  }

  function RestoreSiteStyles() {
    try {
      (globalThis.__vcStash || []).forEach(k => {
        if (!k.el.isConnected && k.parent && k.parent.isConnected) k.parent.insertBefore(k.el, k.next && k.next.parentNode === k.parent ? k.next : null);   // به ترتیب اصلی: هر کدام قبل از همان همسایه‌ی پایدار
      });
    } catch (e) { console.warn('[vairaco] restore failed', e); }
    globalThis.__vcStash = [];
  }

  // ---------- ۲) ریست اصلی: کد قدیمیِ خودتان، بدون تغییر در منطق ----------
  function LegacyResetStyles() {
    (function () {
      try {
        // 1. حذف لینک‌های فونت تزریق شده
        document.querySelectorAll(
          'link[href*="vazir"], link[href*="vazirmatn"], link[href*="iransans"], link[href*="fira_code"], link[href*="firacode"], link[href*="fira-code"], #claude-fa-link, #claude-fa-link2, #claude-fa-link3, #fa-font-link'
        ).forEach(n => n.remove());

        // 2. حذف استایل‌های تزریق شده (تگ‌های style)
        document.querySelectorAll('style').forEach(s => {
          const txt = s.textContent || "";
          if (
            s.id === 'tm-persian-font-style' ||
            s.id === 'claude-fa-style' ||
            s.id === 'fa-dir-style' ||
            txt.includes('Vazir') || txt.includes('Vazirmatn') ||
            txt.includes('IranSans') || txt.includes('IRANSans') ||
            txt.includes('Fira Code') ||
            txt.includes('tm-persian-font-applied') ||
            txt.includes('.custom-rtl') ||
            txt.includes('unicode-bidi: plaintext') ||
            txt.includes('mjx-container') ||
            txt.includes('font-size: 20px') ||
            txt.includes('box-content') ||
            txt.includes('language-') ||
            // 👇 کلمات کلیدی جدید برای شناسایی استایل دیپ‌سیک
            txt.includes('scrollbar-width: thin') ||
            txt.includes('div[class*="think"]') ||
            txt.includes('max-height: 400px')
          ) {
            s.remove();
          }
        });

        // 3. حذف استایل‌های درون‌خطی (Inline Styles)
        document.querySelectorAll('body *').forEach(el => {
          // ریست فونت 20px
          if (el.style.fontSize === '20px') {
            el.style.fontSize = ''; 
          }
          // 👇 ریست کردن user-select که اسکریپت دیپ‌سیک موقع کلیک اعمال می‌کند
          if (el.style.userSelect || el.style.webkitUserSelect) {
            el.style.removeProperty('user-select');
            el.style.removeProperty('-webkit-user-select');
          }
        });

        // 4. حذف کلاس‌ها و ویژگی‌های تزریق شده
        document.documentElement.classList.remove('custom-rtl', 'tm-persian-font-applied');
        if (document.documentElement.getAttribute('lang') === 'fa') {
          document.documentElement.removeAttribute('lang');
        }

        // 5. پاک کردن فلگ‌های سراسری (تا اگر دوباره اسکریپت را اجرا کردید، تازه شروع شود)
        if (window.__deepseek_think_select_handler__) delete window.__deepseek_think_select_handler__;
        if (window.__deepseek_think_copy_handler__) delete window.__deepseek_think_copy_handler__;

        // 6. تلاش برای پاکسازی iframe ها
        document.querySelectorAll('iframe').forEach(fr => {
          try {
            const doc = fr.contentDocument;
            if (!doc) return;
            doc.querySelectorAll('#tm-persian-font-style, style').forEach(s => {
              const txt = s.textContent || "";
              if (
                s.id === 'tm-persian-font-style' ||
                txt.includes('tm-persian-font-applied') ||
                txt.includes('IranSans') || txt.includes('Vazir') ||
                txt.includes('Vazirmatn') || txt.includes('font-size: 20px')
              ) s.remove();
            });
            doc.querySelectorAll('.tm-persian-font-applied').forEach(el => el.classList.remove('tm-persian-font-applied'));
          } catch (e) {}
        });

        console.clear();
        console.log('✅ ResetStyles: تمام تغییرات (فونت‌ها، استایل‌ها، user-select و کلاس‌ها) با موفقیت پاک شد');
      } catch (e) {
        console.error('Reset Styles failed:', e);
      }
    })();
  }

  // ---------- ۴) آثار باقی‌مانده، همه‌ی فریم‌ها ----------
  function ResetExtra() {
    MY_LOCALSTORAGE_KEYS.forEach(k => { try { localStorage.removeItem(k); } catch (e) {} });
    MY_COOKIES.forEach(n => { try { document.cookie = n + '=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/'; } catch (e) {} });
    try {
      // نشانه‌های اختصاصی خودمان: همیشه پاک می‌شوند
      const OWN = ['tm-persian-font-applied', '.custom-rtl', 'sc-rtl-style', 'sc-font-style'];
      // نشانه‌های عمومی (ممکن است سایت هم داشته باشد، مثل language- در Prism یا box-content در Tailwind):
      // فقط وقتی پاک می‌شوند که حداقل ۲ نشانه با هم در یک استایلِ «کوچک» باشند (استایل تزریق‌شده کوچک است، CSS سایت بزرگ)
      const GENERIC = ['Vazir', 'IranSans', 'IRANSans', 'Fira Code', 'unicode-bidi: plaintext', 'mjx-container', 'font-size: 20px'];   // language- و box-content عمداً نیست (CSS سایت‌ها هم دارند)؛ ریست اصلی خودش آن‌ها را مدیریت می‌کند
      // استایل Cursor عمداً در هیچ لیستی نیست؛ ریست آن را پاک نمی‌کند

      // لینک فونت‌ها
      document.querySelectorAll('link[href*="vazir" i], link[href*="iransans" i], link[href*="fira" i]').forEach(n => n.remove());
      IDS.forEach(id => { const n = document.getElementById(id); if (n) n.remove(); });

      // استایل‌های تزریق‌شده (Cursor شامل نمی‌شود)
      document.querySelectorAll('style').forEach(s => {
        const t = s.textContent || '';
        if (OWN.some(m => t.includes(m)) || (t.length < 4000 && GENERIC.filter(m => t.includes(m)).length >= 2)) s.remove();
      });

      // کلاس‌ها
      document.querySelectorAll('.tm-persian-font-applied').forEach(el => el.classList.remove('tm-persian-font-applied'));
      document.documentElement.classList.remove('custom-rtl', 'tm-persian-font-applied');
      if (document.body) document.body.classList.remove('custom-rtl', 'tm-persian-font-applied');
      document.querySelectorAll('[class=""]').forEach(el => el.removeAttribute('class'));

      // اندازه‌ی فونت اینلاین FONT17PX
      document.querySelectorAll('[style]').forEach(el => { if (el.style.fontSize === '20px') el.style.fontSize = ''; });

      // spanهای GPT--MATH: دوباره به متن ساده برگردند
      const wrapped = [];
      document.querySelectorAll('span[style]').forEach(sp => {
        if (sp.attributes.length === 1 &&
            sp.style.direction === 'ltr' && sp.style.unicodeBidi === 'plaintext' &&
            /monospace/.test(sp.style.fontFamily) && sp.childNodes.length === 1 && sp.firstChild.nodeType === 3) wrapped.push(sp);
      });
      wrapped.forEach(sp => {
        const p = sp.parentNode;
        if (!p) return;
        p.replaceChild(document.createTextNode(sp.textContent), sp);
        p.normalize();
      });

      // style="" خالی
      document.querySelectorAll('[style]').forEach(el => { if (!el.getAttribute('style').trim()) el.removeAttribute('style'); });

      if (document.documentElement.getAttribute('lang') === 'fa') document.documentElement.removeAttribute('lang');
    } catch (e) { /* ریست نباید صفحه را خراب کند */ }
  }

  // ریست اصلی فقط در فریم اصلی بود (مثل قبل)؛ پاک‌سازی آثار باقی‌مانده در همه‌ی فریم‌ها
  if (IS_TOP) { StashSiteStyles(); LegacyResetStyles(); RestoreSiteStyles(); }
  ResetExtra();
}
