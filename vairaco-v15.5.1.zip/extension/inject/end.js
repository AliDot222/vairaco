// vairaco — closes the change-tracking window; the last expression is the script's error text (or null) for the extension.
if (globalThis.__vc) globalThis.__vc.end();
removeEventListener('error', globalThis.__vcOnErr); removeEventListener('unhandledrejection', globalThis.__vcOnErr);
(() => { const e = globalThis.__vcErr || null; delete globalThis.__vcErr; delete globalThis.__vcOnErr; return e; })();
