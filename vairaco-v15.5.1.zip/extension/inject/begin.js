// vairaco — opens the change-tracking window (closed by inject/end.js after the script file ran). Also catches the script's own errors
// so the popup can show them to the script author.
globalThis.__vcErr = null;
globalThis.__vcOnErr = e => { if (!globalThis.__vcErr) globalThis.__vcErr = String((e && (e.message || (e.reason && (e.reason.message || e.reason)))) || 'error') + (e && e.lineno ? ' (line ' + e.lineno + ')' : ''); };
addEventListener('error', globalThis.__vcOnErr); addEventListener('unhandledrejection', globalThis.__vcOnErr);
if (globalThis.__vc) globalThis.__vc.begin(true);
