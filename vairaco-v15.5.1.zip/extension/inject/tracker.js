// ردیاب تغییرات اسکریپت‌ها (عمومی؛ برای هر اسکریپتی، حتی جدید، بدون دانستن محتوایش).
// begin() پنجره‌ی ثبت را باز می‌کند، end() آن را می‌بندد؛ undo() همه‌ی تغییرات ثبت‌شده را برمی‌گرداند.
// چه ثبت و برگردانده می‌شود (v4):
//  • DOM: المان، attribute، کلاس، style درون‌خطی، متن  — حین اجرا و هر وقت بعداً callbackهای خودِ اسکریپت چیزی عوض کنند
//  • پنهان‌ها: MutationObserver/IntersectionObserver/ResizeObserver، setTimeout/setInterval، requestAnimationFrame/IdleCallback،
//    addEventListener (و تغییراتی که handlerها بعداً می‌دهند)، متغیرهای سراسریِ تازه، localStorage/sessionStorage،
//    adoptedStyleSheets، FontFaceهای تازه و insertRule/deleteRule روی stylesheetها.
// تنها داخل «پنجره‌ی اجرای اسکریپت» یا داخل callbackهای خودِ اسکریپت پچ می‌شود؛ بقیه‌ی کد افزونه (مثلاً موس) دست‌نخورده می‌ماند.
(() => {
  if (globalThis.__vc && globalThis.__vc.v === 4) return;
  const G = globalThis, MAX = 20000, MAXU = 5000;
  const OPT = { subtree: true, childList: true, attributes: true, attributeOldValue: true, characterData: true, characterDataOldValue: true };
  const NativeMO = G.MutationObserver, nSetTimeout = G.setTimeout.bind(G);
  const pend = [];   // رکوردهایی که بین دو فایلِ تزریق‌شده تحویل داده می‌شوند (وگرنه takeRecords خالی برمی‌گرداند)
  const rec = new NativeMO(rs => { for (const r of rs) pend.push(r); });
  const S = { v: 4, log: [], undoers: [], open: false, depth: 0, saved: null, stat: {}, globals: [], sheets: [], faces: [] };
  const NAT = { ael: EventTarget.prototype.addEventListener, rel: EventTarget.prototype.removeEventListener, ins: G.CSSStyleSheet && CSSStyleSheet.prototype.insertRule, del: G.CSSStyleSheet && CSSStyleSheet.prototype.deleteRule,
    set: Storage.prototype.setItem, rem: Storage.prototype.removeItem, clr: Storage.prototype.clear };

  const flush = () => {
    for (const r of [...pend.splice(0), ...rec.takeRecords()]) {
      if (S.log.length >= MAX) break;
      const e = { type: r.type, t: r.target, name: r.attributeName, ns: r.attributeNamespace, old: r.oldValue };
      if (r.type === 'attributes') e.after = e.ns ? r.target.getAttributeNS(e.ns, e.name) : r.target.getAttribute(e.name);
      else if (r.type === 'characterData') e.after = r.target.data;
      else { e.add = Array.from(r.addedNodes); e.rem = Array.from(r.removedNodes); e.prev = r.previousSibling; e.next = r.nextSibling; }
      S.log.push(e);
    }
  };
  const track = fn => {   // یک callback را با ثبت تغییراتش اجرا می‌کند (و هرچه داخلش ساخته شود هم ثبت می‌شود)
    const outer = S.depth > 0;
    if (!outer) { rec.observe(document, OPT); rec.takeRecords(); pend.length = 0; }
    const mine = !S.saved; if (mine) patch();
    S.depth++;
    try { return fn(); }
    finally { S.depth--; if (mine) unpatch(); if (!outer) { flush(); rec.disconnect(); } }
  };
  const wrap = fn => typeof fn !== 'function' ? fn : function (...a) { return track(() => fn.apply(this, a)); };
  const keep = (u, kind = 'hook') => { if (S.undoers.length < MAXU) { S.undoers.push(u); S.stat[kind] = (S.stat[kind] || 0) + 1; } };

  S.cleanup = fn => keep(fn);   // اسکریپت‌ها می‌توانند کار پاک‌سازیِ خودشان را (مثلاً حذف FontFace) برای Reset ثبت کنند

  // removeEventListener: دائمی ولی بی‌خطر (فقط اگر شنونده‌ی پیچیده‌شده‌ای پیدا شد جایگزین می‌کند؛ وگرنه همان رفتار اصلی)
  const reg = new WeakMap();   // target -> Map(listener -> Map("type|capture" -> wrapped))
  const capOf = o => typeof o === 'boolean' ? o : !!(o && o.capture);
  EventTarget.prototype.removeEventListener = function (t, l, o) {
    const w = typeof l === 'function' && reg.get(this) && reg.get(this).get(l) && reg.get(this).get(l).get(t + '|' + capOf(o));
    return NAT.rel.call(this, t, w || l, o);
  };
  const stor = new Map();      // Storage -> Map(key -> { old: previous value | null, last: value the script left there | null })
  const remember = (st, k) => { k = String(k); let m = stor.get(st); if (!m) { stor.set(st, m = new Map()); keep(() => { for (const [key, g] of m) { try { if (st.getItem(key) === g.last) { g.old === null ? NAT.rem.call(st, key) : NAT.set.call(st, key, g.old); } } catch (e) {} } stor.delete(st); }, 'storage'); } if (!m.has(k)) m.set(k, { old: st.getItem(k), last: null }); return m.get(k); };   // restored only if the page has not changed it since

  const patch = () => {
    const P = S.saved = {};
    for (const k of ['MutationObserver', 'IntersectionObserver', 'ResizeObserver']) {
      const N = G[k]; if (!N) continue;
      P[k] = N;
      const W = function (cb, ...r) { const o = new N(wrap(cb), ...r); keep(() => { try { o.disconnect(); } catch (e) {} }, 'observer'); return o; };
      W.prototype = N.prototype; G[k] = W;
    }
    for (const k of ['setTimeout', 'setInterval']) {
      const N = G[k]; P[k] = N;
      G[k] = function (f, ...r) { const id = N.call(G, wrap(f), ...r); keep(() => { G.clearTimeout(id); G.clearInterval(id); }, 'timer'); return id; };
    }
    for (const [k, cancel] of [['requestAnimationFrame', 'cancelAnimationFrame'], ['requestIdleCallback', 'cancelIdleCallback']]) {
      const N = G[k]; if (!N) continue; P[k] = N;
      G[k] = function (f, ...r) { const id = N.call(G, wrap(f), ...r); keep(() => { try { G[cancel](id); } catch (e) {} }, 'timer'); return id; };
    }
    EventTarget.prototype.addEventListener = function (t, l, o) {
      if (typeof l !== 'function') { if (l) keep(() => { try { NAT.rel.call(this, t, l, o); } catch (e) {} }, 'listener'); return NAT.ael.call(this, t, l, o); }
      let byL = reg.get(this); if (!byL) reg.set(this, byL = new Map());
      let byK = byL.get(l); if (!byK) byL.set(l, byK = new Map());
      const key = t + '|' + capOf(o); let w = byK.get(key); if (!w) byK.set(key, w = wrap(l));   // handler هم زیر نظر است: تغییراتی که بعداً در DOM می‌دهد برگردانده می‌شود
      keep(() => { try { NAT.rel.call(this, t, w, o); } catch (e) {} }, 'listener');
      return NAT.ael.call(this, t, w, o);
    };
    const SP = Storage.prototype;
    SP.setItem = function (k, v) { const g = remember(this, k); const r = NAT.set.call(this, k, v); g.last = this.getItem(String(k)); return r; };
    SP.removeItem = function (k) { const g = remember(this, k); const r = NAT.rem.call(this, k); g.last = null; return r; };
    SP.clear = function () { const gs = []; for (let i = 0; i < this.length; i++) gs.push(remember(this, this.key(i))); const r = NAT.clr.call(this); gs.forEach(g => { g.last = null; }); return r; };
    if (NAT.ins) {
      const CP = CSSStyleSheet.prototype;
      CP.insertRule = function (rule, i) { const idx = NAT.ins.call(this, rule, i); const r = this.cssRules[idx]; keep(() => { const j = [...this.cssRules].indexOf(r); if (j >= 0) NAT.del.call(this, j); }, 'css'); return idx; };
      CP.deleteRule = function (i) { const r = this.cssRules[i], text = r && r.cssText; NAT.del.call(this, i); if (text) keep(() => { NAT.ins.call(this, text, Math.min(i, this.cssRules.length)); }, 'css'); };
    }
  };
  const unpatch = () => {
    const P = S.saved; if (!P) return;
    for (const k in P) G[k] = P[k];
    EventTarget.prototype.addEventListener = NAT.ael;
    Storage.prototype.setItem = NAT.set; Storage.prototype.removeItem = NAT.rem; Storage.prototype.clear = NAT.clr;
    if (NAT.ins) { CSSStyleSheet.prototype.insertRule = NAT.ins; CSSStyleSheet.prototype.deleteRule = NAT.del; }
    S.saved = null;
  };

  // «تفاضل» چیزهایی که تغییرشان MutationObserver نمی‌بیند: متغیرهای سراسری، adoptedStyleSheets، FontFace
  const snap = () => ({ g: new Set(Object.getOwnPropertyNames(G)), a: [...(document.adoptedStyleSheets || [])], f: document.fonts ? new Set(document.fonts) : null });
  const SKIP = /^__vc/;
  const diff = b => {
    for (const n of Object.getOwnPropertyNames(G)) if (!b.g.has(n) && !SKIP.test(n)) S.globals.push(n);
    for (const x of (document.adoptedStyleSheets || [])) if (!b.a.includes(x)) S.sheets.push(x);
    if (b.f) for (const f of document.fonts) if (!b.f.has(f)) S.faces.push(f);
  };

  S.begin = (hold) => {   // hold=true: the window stays open until end() (used when the script is a separate injected file); safety timeout 3s
    if (S.open) return;
    S.open = true; S.depth++;
    S.snap = snap(); patch(); rec.observe(document, OPT); rec.takeRecords(); pend.length = 0;
    nSetTimeout(S.end, hold ? 3000 : 0);   // اگر اسکریپت خطا داد و end اجرا نشد، پنجره همین‌جا بسته می‌شود
  };
  S.end = () => {
    if (!S.open) return;
    flush(); rec.disconnect(); unpatch(); S.open = false; S.depth = Math.max(0, S.depth - 1);
    try { if (S.snap) diff(S.snap); } catch (e) {} S.snap = null;
  };

  const tokens = v => new Set(String(v || '').split(/\s+/).filter(Boolean));
  const styleMap = v => { const d = document.createElement('div'); d.style.cssText = v || ''; const m = {}; for (let i = 0; i < d.style.length; i++) { const p = d.style[i]; m[p] = d.style.getPropertyValue(p) + '|' + d.style.getPropertyPriority(p); } return m; };

  S.undo = () => {
    S.end();
    const R = { dom: 0, ...S.stat }; S.stat = {};
    for (const u of S.undoers.splice(0).reverse()) { try { u(); } catch (e) {} }   // آخرین ساخته‌شده اول برگردد
    for (const n of S.globals.splice(0)) { try { delete G[n]; R.globals = (R.globals || 0) + 1; } catch (e) {} }
    try { const dead = new Set(S.sheets.splice(0)); if (dead.size) { document.adoptedStyleSheets = document.adoptedStyleSheets.filter(x => !dead.has(x)); R.css = (R.css || 0) + dead.size; } } catch (e) {}
    for (const f of S.faces.splice(0)) { try { document.fonts.delete(f); R.fonts = (R.fonts || 0) + 1; } catch (e) {} }
    const log = S.log.splice(0);
    let n = 0;
    // ۱) ساختار DOM، از آخر به اول
    for (let i = log.length - 1; i >= 0; i--) {
      const e = log[i]; if (e.type !== 'childList') continue;
      try {
        for (const x of e.add) if (x.parentNode === e.t) { e.t.removeChild(x); n++; }
        for (const x of e.rem) {
          if (x.parentNode) continue;
          const ref = e.next && e.next.parentNode === e.t ? e.next : (e.prev && e.prev.parentNode === e.t ? e.prev.nextSibling : null);
          e.t.insertBefore(x, ref); n++;
        }
      } catch (err) {}
    }
    // ۲) attributeها: برای هر (المان، نام) اولین مقدار قبلی و آخرین مقدار بعدی
    const attrs = new Map(), texts = new Map();
    for (const e of log) {
      if (e.type === 'attributes') {
        let m = attrs.get(e.t); if (!m) attrs.set(e.t, m = new Map());
        const k = (e.ns || '') + '|' + e.name, g = m.get(k);
        if (!g) m.set(k, { name: e.name, ns: e.ns, old: e.old, after: e.after }); else g.after = e.after;
      } else if (e.type === 'characterData') {
        const g = texts.get(e.t); if (!g) texts.set(e.t, { old: e.old, after: e.after }); else g.after = e.after;
      }
    }
    for (const [el, m] of attrs) for (const g of m.values()) {
      try {
        const cur = g.ns ? el.getAttributeNS(g.ns, g.name) : el.getAttribute(g.name);
        const set = v => { if (v === null) { g.ns ? el.removeAttributeNS(g.ns, g.name) : el.removeAttribute(g.name); } else { g.ns ? el.setAttributeNS(g.ns, g.name, v) : el.setAttribute(g.name, v); } };
        if (cur === g.after) set(g.old);                                  // بعد از اسکریپت کسی دست نزده: برگرداندن کامل
        else if (g.name === 'class') {                                    // صفحه هم کلاس عوض کرده: فقط سهم اسکریپت
          const o = tokens(g.old), a = tokens(g.after), c = tokens(cur);
          a.forEach(t => { if (!o.has(t)) c.delete(t); }); o.forEach(t => { if (!a.has(t)) c.add(t); });
          el.setAttribute('class', [...c].join(' '));
        } else if (g.name === 'style') {                                  // فقط پراپرتی‌هایی که اسکریپت عوض کرده
          const o = styleMap(g.old), a = styleMap(g.after), c = styleMap(cur);
          for (const p in a) if (o[p] !== a[p] && c[p] === a[p]) { if (o[p] === undefined) el.style.removeProperty(p); else { const [v, pr] = o[p].split('|'); el.style.setProperty(p, v, pr); } }
        }
        if (g.name === 'style' && el.getAttribute('style') === '' && g.old === null) el.removeAttribute('style');
        if (g.name === 'class' && el.getAttribute('class') === '' && g.old === null) el.removeAttribute('class');
        n++;
      } catch (err) {}
    }
    for (const [t, g] of texts) { try { if (t.data === g.after) { t.data = g.old; n++; } } catch (err) {} }
    R.dom = n; S.last = R;
    return Object.values(R).reduce((a, b) => a + b, 0);   // مجموع چیزهای برگردانده‌شده
  };

  G.__vc = S;
})();
