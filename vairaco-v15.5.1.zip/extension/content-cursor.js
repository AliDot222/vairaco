// Content Script برای اعمال خودکار استایل نشانگر موس
(function() {
  try {
    chrome.storage.local.get(['cursorEnabled'], (result) => {
      try {
        if (result.cursorEnabled === true) {
          const style = document.createElement('style');
          // the pointer image is a local file of the extension (my-scripts/cursor/cur116.cur): no network request
          const file = chrome.runtime.getURL('my-scripts/cursor/cur116.cur');
          style.textContent = `
* {
    cursor: url("${file}"), auto !important;
}
          `;
          document.documentElement.appendChild(style);
        }
      } catch (e) {
        console.warn('Cursor style injection failed:', e);
      }
    });
  } catch (e) {
    console.warn('Cursor content script error:', e);
  }
})();
