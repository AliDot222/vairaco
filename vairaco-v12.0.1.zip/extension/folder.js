// vairaco — settings live in settings.json next to manifest.json. Every profile that loads this folder reads it
// (on Chrome focus / startup), and zipping the folder carries the settings to a friend. Writing happens wherever the
// folder has been linked once (diskfs.js). Local storage stays the runtime copy.
import { getDir, hasWrite, writeText } from './diskfs.js';
export const FILE = 'settings.json';
const hashOf = s => { let h = 5381; for (let i = 0; i < s.length; i++) h = ((h * 33) ^ s.charCodeAt(i)) | 0; return (h >>> 0).toString(36) + '.' + s.length; };
const ok = r => r && typeof r.id === 'string' && typeof r.domain === 'string' && Array.isArray(r.scripts);
export const serialize = (rules, menu) => JSON.stringify({ app: 'vairaco-settings', v: 1, rules, menu: Array.isArray(menu) ? menu : null }, null, 2) + '\n';

export async function readFile() {
  try {
    const r = await fetch(chrome.runtime.getURL(FILE), { cache: 'no-store' }); if (!r.ok) return null;
    const text = await r.text(), j = JSON.parse(text);
    return j && j.app === 'vairaco-settings' && Array.isArray(j.rules) ? { text, j } : null;
  } catch { return null; }
}
let chain = Promise.resolve();
const serial = fn => (chain = chain.catch(() => {}).then(fn));

// folder -> this profile. First time on a profile that already has its own rules: merge (file wins on the same id).
export const pull = () => serial(async () => {
  const f = await readFile(); if (!f) return;
  const st = await chrome.storage.local.get(['rules', 'menuScripts', 'fileHash', 'fileDirty']);
  const h = hashOf(f.text); if (st.fileHash === h) return;
  let rules = f.j.rules.filter(ok), menu = Array.isArray(f.j.menu) ? f.j.menu : null, dirty = false;
  const local = Array.isArray(st.rules) ? st.rules : [], hasLocal = local.length || Array.isArray(st.menuScripts);
  if (st.fileDirty || (st.fileHash === undefined && hasLocal)) {
    const ids = new Set(rules.map(r => r.id)); rules = [...rules, ...local.filter(r => ok(r) && !ids.has(r.id))];
    if (!menu && Array.isArray(st.menuScripts)) menu = st.menuScripts;
    dirty = true;
  }
  await chrome.storage.local.set({ rules, fileHash: h, fileDirty: dirty, ...(menu ? { menuScripts: menu } : {}) });
  if (!menu) await chrome.storage.local.remove('menuScripts');
  if (dirty) await doPush(false);
});

// this profile -> folder (only where the folder is linked and writable; otherwise remember that the file is behind)
export const push = force => serial(() => doPush(force));
async function doPush(force) {
  const st = await chrome.storage.local.get(['rules', 'menuScripts', 'fileHash']);
  const text = serialize((Array.isArray(st.rules) ? st.rules : []).filter(ok), st.menuScripts), h = hashOf(text);
  if (!force && h === st.fileHash) { await chrome.storage.local.set({ fileDirty: false }); return 'same'; }
  const dir = await getDir();
  if (dir && !force) {   // somebody else (another profile, a friend's copy) changed the file since we last synced: keep their additions
    const cur = await readFile();
    if (cur && hashOf(cur.text) !== st.fileHash && st.fileHash !== undefined) {
      const mine = (Array.isArray(st.rules) ? st.rules : []).filter(ok), ids = new Set(mine.map(r => r.id));
      const theirs = cur.j.rules.filter(r => ok(r) && !ids.has(r.id));
      if (theirs.length) { await chrome.storage.local.set({ rules: [...mine, ...theirs], fileHash: hashOf(cur.text) }); return doPush(true); }
    }
  }
  if (!dir || !(await hasWrite(dir))) { await chrome.storage.local.set({ fileDirty: true }); return dir ? 'allow' : 'link'; }
  try { await writeText(dir, FILE, text); await chrome.storage.local.set({ fileHash: h, fileDirty: false, fileErr: null }); return 'written'; }
  catch (e) { await chrome.storage.local.set({ fileDirty: true, fileErr: String((e && e.message) || e).slice(0, 160) }); return 'error'; }
}

export function watchLocal() {
  let t = null;
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area !== 'local' || ch.fileHash) return;            // our own apply
    if (ch.rules || ch.menuScripts) { chrome.storage.local.set({ fileDirty: true }); clearTimeout(t); t = setTimeout(() => push().catch(() => {}), 700); }   // dirty at once, so a pull in the debounce window merges instead of overwriting
  });
}
