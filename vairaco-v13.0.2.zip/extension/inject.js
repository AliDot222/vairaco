// vairaco — runs scripts from my-scripts/ on a tab. Everything is local; no code is loaded from the internet.
import { SCRIPTS as SEED } from './registry.js';

// BY_ID: id -> {id,title,file,sites,sticky}. First-run list = registry.js; afterwards the popup re-scans my-scripts/ and store storage.scriptList.
export const BY_ID = new Map();
const fill = list => { BY_ID.clear(); for (const s of list) if (s && s.id && s.file && !s.bad) BY_ID.set(s.id, s); };
fill(SEED);
export async function loadScripts() {
  const { scriptList } = await chrome.storage.local.get('scriptList');
  fill(Array.isArray(scriptList) ? scriptList : SEED);
}

const dirtyKey = tabId => 'dirty_' + tabId;
// Which scripts already ran on THIS document is remembered in the page itself (isolated world), so a real navigation starts clean
// while SPA route changes (pushState, same document) do not run everything again. Ordered, top frame only.
export async function ranList(tabId) {
  try { return (await chrome.scripting.executeScript({ target: { tabId }, func: () => [...(globalThis.__vcRan || [])] }))[0].result || []; } catch { return []; }
}
export async function clearRan(tabId) { try { await chrome.scripting.executeScript({ target: { tabId }, func: () => { globalThis.__vcRan = null; } }); } catch { /* protected page */ } }
const markRan = (tabId, id) => chrome.scripting.executeScript({ target: { tabId }, func: id => { (globalThis.__vcRan = globalThis.__vcRan || new Set()).add(id); }, args: [id] }).catch(() => {});
// Scripts that leave observers/listeners behind: Reset reloads the tab once afterwards so nothing remains
export async function isDirty(tabId) { const k = dirtyKey(tabId); return !!(await chrome.storage.session.get(k))[k]; }
export async function clearDirty(tabId) { await chrome.storage.session.remove(dirtyKey(tabId)); }

// Infinite-loop safety net: a "running" flag is set before a script runs and cleared after. If a tab hangs the flag stays,
// and that script is not AUTO-run again until the user runs it by hand once (menu or popup), which clears the flag.
const GUARD_MS = 20000;
async function guardSet(id, on) {
  const { guard } = await chrome.storage.local.get('guard'); const g = { ...(guard || {}) };
  if (on) g[id] = Date.now(); else delete g[id];
  await chrome.storage.local.set({ guard: g });
}
export async function frozenIds() {
  const { guard } = await chrome.storage.local.get('guard');
  return Object.entries(guard || {}).filter(([, at]) => Date.now() - at > GUARD_MS).map(([id]) => id);
}
export const clearGuard = id => guardSet(id, false);

// Order: tracker (for Reset), local Vazir fonts, begin-window, the script file itself, end-window — one injection, ISOLATED world, CSP-safe
export async function runScript(tabId, id, manual = false) {   // manual = the user clicked it: always allowed, and clears an old freeze flag
  if (!BY_ID.has(id)) await loadScripts();
  const s = BY_ID.get(id);
  if (!s) throw new Error('NOT_AVAILABLE');
  if (manual) await clearGuard(id);
  else {
    if ((await frozenIds()).includes(id)) throw new Error('SCRIPT_FROZE');
    if ((await ranList(tabId)).includes(id)) return;          // automatic run: this document already has it (SPA route change)
  }
  await guardSet(id, true);
  try { await chrome.scripting.executeScript({ target: { tabId }, files: ['inject/tracker.js', 'inject/vazir-faces.js', 'inject/begin.js', 'my-scripts/' + s.file, 'inject/end.js'] }); }
  finally { await guardSet(id, false); }
  if (s.sticky) await chrome.storage.session.set({ [dirtyKey(tabId)]: 1 });
  await markRan(tabId, id);
}

// برگرداندن همه‌ی تغییرات ثبت‌شده‌ی هر اسکریپتی. خطا نباید ریست را متوقف کند.
export async function undoTracked(tabId) {   // returns how many things were put back (all frames)
  try {
    const rs = await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, func: () => (globalThis.__vc ? globalThis.__vc.undo() : 0) });
    return rs.reduce((a, r) => a + (typeof r.result === 'number' ? r.result : 0), 0);
  } catch (e) { return 0; /* صفحه‌ی محافظت‌شده */ }
}
