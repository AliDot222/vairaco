// vairaco — the scripts folder. Every *.js in my-scripts/ is a script (name = file name without .js).
// scanScripts() lists the folder live (needs a window page, e.g. the popup); describe(file) re-reads ONE known file (works in the service worker).
//   Optional header comments (first 10 lines):  // @title Pretty name   // @sites a.com, b.com   // @auto (run on those sites by itself)   // @sticky
export const DIR_NAME = 'my-scripts';

const listDir = () => new Promise(resolve => {
  if (!chrome.runtime.getPackageDirectoryEntry) return resolve(null);
  chrome.runtime.getPackageDirectoryEntry(root => root.getDirectory(DIR_NAME, {}, dir => {
    const out = [], rd = dir.createReader();
    const more = () => rd.readEntries(es => { if (!es.length) return resolve(out); es.forEach(e => e.isFile && out.push(e.name)); more(); }, () => resolve(out));
    more();
  }, () => resolve(null)));
});
export const scriptUrl = file => chrome.runtime.getURL(DIR_NAME + '/' + encodeURIComponent(file));
export const readScript = async file => (await fetch(scriptUrl(file), { cache: 'no-store' })).text();
const hashOf = str => { let h = 5381; for (let i = 0; i < str.length; i++) h = ((h * 33) ^ str.charCodeAt(i)) | 0; return (h >>> 0).toString(36) + '.' + str.length; };

export function parseMeta(code) {
  const head = String(code).split('\n').slice(0, 10).join('\n');
  const tag = n => { const m = head.match(new RegExp('^\\s*//\\s*@' + n + '\\b[ \\t]*(.*)$', 'm')); return m ? m[1].trim() : null; };
  return { title: tag('title'), sites: (tag('sites') || '').split(/[,\s]+/).filter(Boolean), sticky: tag('sticky') !== null, auto: tag('auto') !== null };
}

// Read one file and describe it. Returns null when the file no longer exists (404).
export async function describe(file) {
  const id = file.replace(/\.js$/i, '');
  let txt = '', bad = null;
  let r;
  try { r = await fetch(scriptUrl(file), { cache: 'no-store' }); }
  catch { return null; }                                  // a deleted file makes fetch() reject for chrome-extension:// URLs
  if (r.status === 404) return null;
  try { if (!r.ok) throw new Error('read'); txt = await r.text(); if (/^\s*(export|import)\s/m.test(txt)) bad = 'module'; } catch { bad = 'read'; }
  const m = parseMeta(txt);
  return { id, title: m.title || id, file, sites: m.sites, sticky: m.sticky, auto: m.auto, bad, hash: hashOf(txt) };
}

export async function scanScripts() {
  const names = await listDir();
  if (names === null) return null;                       // could not read the folder (keep the previous list)
  const out = [];
  for (const file of names.filter(n => /\.js$/i.test(n)).sort((a, b) => a.localeCompare(b))) { const d = await describe(file).catch(() => null); if (d) out.push(d); }
  return out;
}
