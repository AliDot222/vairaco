// vairaco — one-time folder link (a full tab, because Chrome's folder picker closes the popup).
import { t, setLang, guessLang, applyI18n, RTL_LANGS } from './i18n.js';
import { getDir, setDir, hasWrite, ensureWrite, pickDir, findOurFolder } from './diskfs.js';
import { push } from './folder.js';
const $ = id => document.getElementById(id);
const say = (txt, cls) => { $('msg').textContent = txt; $('msg').className = cls || ''; };
const { lang } = await chrome.storage.local.get('lang'); setLang(lang || guessLang());
document.documentElement.dir = RTL_LANGS.includes(lang || guessLang()) ? 'rtl' : 'ltr'; applyI18n(document);
let mode = 'link';
async function paint() {
  const d = await getDir();
  mode = d && !(await hasWrite(d)) ? 'allow' : d ? 'done' : 'link';
  $('go').textContent = mode === 'allow' ? t('fileAllowBtn') : mode === 'done' ? t('fileLinked') : t('fileLinkBtn');
}
$('go').onclick = async () => {
  try {
    if (mode === 'allow') { const d = await getDir(); if (!(d && await ensureWrite(d))) return say(t('fileAllow'), 'bad'); await push(true); await paint(); return say(t('fileLinked'), 'ok'); }
    const picked = await pickDir();
    const own = await (await fetch(chrome.runtime.getURL('manifest.json'), { cache: 'no-store' })).text();
    const { h, why } = await findOurFolder(picked, async f => (await fetch(chrome.runtime.getURL(f), { cache: 'no-store' })).text(), own);
    if (!h) return say(t('fileWrong', why), 'bad');
    await setDir(h); await push(true); await paint(); say(t('fileLinked'), 'ok');
  } catch (e) { if (!e || e.name !== 'AbortError') say(String((e && e.message) || e), 'bad'); }
};
await paint();
