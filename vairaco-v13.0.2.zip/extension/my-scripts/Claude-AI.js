// @title Claude-AI
// @sites claude.ai
// @sticky
(() => {
function ClaudeAI() {
  // - Claude.ai Persian Optimizer (Scoped: chat box + prompt box)

    document.getElementById('claude-fa-style')?.remove();

    const chatRoot = ':where(main, .flex-1.flex.flex-col.px-4.max-w-3xl.mx-auto.w-full.pt-1)';

    // باکس نوشتن پرامپت (ویرایشگر ProseMirror)
    const PROMPT = ':is(div[data-testid="chat-input"], div.ProseMirror[contenteditable="true"])';

  // 1) فونت‌های فارسی (وزیر / IRANSans) از داخل خود افزونه می‌آیند (inject/vazir-faces.js)؛ لینک CDN حذف شد.

  // 1.5) فونت کد هم وزیر است و از داخل افزونه می‌آید (Fira Code و لینک CDN حذف شد).

  // 2) استایل محدود به کانتینر چت + باکس پرامپت
  const style = document.createElement("style");
  style.id = 'claude-fa-style';
  const CODE_EXCLUDE = ':not(pre):not(pre *):not(code):not(code *):not([class*="code"]):not([class*="code"] *):not([class*="language-"]):not([class*="language-"] *)';
  style.textContent = `
    ${chatRoot},
    ${chatRoot} *:not(textarea):not(input):not([contenteditable="true"]):not(svg):not(svg *):not(path):not(button):not(button *):not([class*="icon"]):not([class*="icon"] *)${CODE_EXCLUDE} {
        font-family: "IRANSans", Vazirmatn, Tahoma, sans-serif !important;
    }

    ${chatRoot} {
        direction: rtl !important;
        text-align: right !important;
    }

    ${chatRoot} p${CODE_EXCLUDE},
    ${chatRoot} li${CODE_EXCLUDE},
    ${chatRoot} span${CODE_EXCLUDE},
    ${chatRoot} div${CODE_EXCLUDE} {
        direction: rtl !important;
        text-align: right !important;
    }

    /* جلوگیری قطعی از به‌هم‌ریختگی آیکون‌ها */
    ${chatRoot} svg,
    ${chatRoot} svg *,
    ${chatRoot} path,
    ${chatRoot} button svg,
    ${chatRoot} [class*="icon"] {
        font-family: revert !important;
        direction: ltr !important;
    }

    ${chatRoot} svg,
    ${chatRoot} button {
        direction: ltr !important;
    }

    /* بلاک‌های کد بزرگ در ناحیه چت: فونت مخصوص کد + LTR اجباری */
    ${chatRoot} pre,
    ${chatRoot} code,
    ${chatRoot} pre *,
    ${chatRoot} code *,
    ${chatRoot} [class*="code"],
    ${chatRoot} [class*="code"] *,
    ${chatRoot} [class*="language-"],
    ${chatRoot} [class*="language-"] * {
        font-family: Vazirmatn, monospace !important;
        direction: ltr !important;
        text-align: left !important;
        unicode-bidi: normal !important;
    }

    ${chatRoot} textarea,
    ${chatRoot} input[type="text"],
    ${chatRoot} [contenteditable="true"] {
        direction: rtl !important;
        unicode-bidi: plaintext !important;
        text-align: start !important;
        font-family: "IRANSans", Vazirmatn, Tahoma, sans-serif !important;
    }

    /* ===== باکس مخصوص نوشتن پرامپت (پایین صفحه) ===== */

    /* فونت: مستقیم روی خود ویرایشگر و همه فرزندانش (به‌جز کد) */
    html body ${PROMPT},
    html body ${PROMPT} *:not(pre):not(pre *):not(code):not(code *),
    html body ${PROMPT} p::before,
    html body ${PROMPT} p::after {
        font-family: "IRANSans", Vazirmatn, Tahoma, sans-serif !important;
    }

    /* خود ویرایشگر: پیش‌فرض LTR */
    html body ${PROMPT} {
        direction: ltr !important;
        unicode-bidi: normal !important;
        text-align: start !important;
    }

    /* هر خط/پاراگراف: جهت بر اساس اولین حرف همان خط
       فارسی => راست‌به‌چپ ، انگلیسی و بقیه => چپ‌به‌راست */
    html body ${PROMPT} p,
    html body ${PROMPT} li,
    html body ${PROMPT} h1,
    html body ${PROMPT} h2,
    html body ${PROMPT} h3,
    html body ${PROMPT} h4,
    html body ${PROMPT} blockquote {
        direction: ltr !important;
        unicode-bidi: plaintext !important;
        text-align: start !important;
    }

    /* کد داخل باکس پرامپت: فونت کد + LTR اجباری */
    html body ${PROMPT} pre,
    html body ${PROMPT} pre *,
    html body ${PROMPT} code,
    html body ${PROMPT} code * {
        font-family: Vazirmatn, monospace !important;
        direction: ltr !important;
        text-align: left !important;
        unicode-bidi: normal !important;
    }
  `;
  document.head.appendChild(style);

  // 3) کپی تمیز از داخل بلاک کد
  document.addEventListener("copy", function (e) {
    const selection = window.getSelection();
    if (!selection.rangeCount) return;
    const range = selection.getRangeAt(0);
    const container = range.commonAncestorContainer;
    if (container && (container.nodeName === "PRE" || container.nodeName === "CODE" ||
        container.parentElement?.closest("pre, code"))) {
      e.preventDefault();
      e.clipboardData.setData("text/plain", selection.toString());
    }
  });
}

ClaudeAI();
})();
