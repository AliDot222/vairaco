// @title DeepSeek
// @sites chat.deepseek.com
// @sticky
(() => {
function DEEPSEEK() {
  // - DEEP-SEEK

  document.head.innerHTML += `
<style>
    textarea, 
    [contenteditable="true"], 
    [contenteditable="true"] *,
    .ds-markdown, 
    .ds-markdown *,
    div[class*="fbb737a4"], 
    div[class*="fbb737a4"] * {
        font-family: Vazirmatn, IranSans, Tahoma, sans-serif !important;
        direction: rtl !important;
        text-align: right !important;
    }
    
    /* 📝 کدها و فرمول‌های ریاضی */
    pre, code, pre *, code *,
    .ds-markdown pre, .ds-markdown code, .ds-markdown pre *, .ds-markdown code *,
    .fbb737a4 pre, .fbb737a4 code, .fbb737a4 pre *, .fbb737a4 code *,
    [class*="code"], [class*="code"] *,
    [class*="Code"], [class*="Code"] *,
    [class*="math"], [class*="math"] *,
    [class*="Math"], [class*="Math"] *,
    [class*="equation"], [class*="equation"] *,
    [class*="Equation"], [class*="Equation"] *,
    [class*="formula"], [class*="formula"] *,
    [class*="Formula"], [class*="Formula"] *,
    [class*="katex"], [class*="katex"] *,
    [class*="latex"], [class*="latex"] *,
    .math, .Math, .equation, .Equation,
    .formula, .Formula, .katex, .latex,
    mjx-container, mjx-container * {
        direction: ltr !important;
        text-align: left !important;
        font-family: monospace, "Courier New", Courier !important;
        letter-spacing: 0.5px !important;
    }

    /* ==================================================== */
    /* 📦 محدودیت ارتفاع و اسکرول داخلی برای بلاک‌های کد */
    /* ==================================================== */
    [class*="code-block"],
    [class*="CodeBlock"] {
        max-height: none !important;
        overflow: visible !important;
    }

    pre,
    .ds-markdown pre {
        max-height: 400px !important; 
        overflow-y: auto !important;  
        overflow-x: auto !important;  
        border-radius: 8px !important; 
        scrollbar-width: thin;
    }

    pre code {
        overflow: visible !important;
        max-height: none !important;
    }

    /* اسکرول‌بار شیک */
    pre::-webkit-scrollbar {
        width: 8px !important;
        height: 8px !important;
    }
    pre::-webkit-scrollbar-track {
        background: transparent !important;
    }
    pre::-webkit-scrollbar-thumb {
        background-color: rgba(150, 150, 150, 0.4) !important;
        border-radius: 4px !important;
    }
    pre::-webkit-scrollbar-thumb:hover {
        background-color: rgba(150, 150, 150, 0.7) !important;
    }
    pre::-webkit-scrollbar-corner {
        background: transparent !important;
    }

    /* استثنا برای باکس پیوست فایل، آیکون‌ها، فلش‌ها و دکمه‌ها */
    ._6d1b417, 
    ._6d1b417 *,
    svg, 
    svg *, 
    path, 
    button, 
    [role="button"], 
    .ds-icon,
    [class*="icon"] {
        direction: ltr !important;
        text-align: left !important;
        unicode-bidi: normal !important;
        font-family: revert !important;
    }

    textarea, input[type="text"], [contenteditable="true"] {
        direction: auto !important;
        unicode-bidi: plaintext !important;
        text-align: start !important;
    }

    /* 🧠 طراحی باکس فکر کردن */
    div[class*="think"],
    div[class*="Think"],
    div[class*="thought"],
    div[class*="Thought"],
    [class*="reasoning"],
    [class*="ds-think"] {
        max-height: 200px !important; 
        overflow-y: auto !important;  
        overflow-x: hidden !important; 
        display: block !important;
        background-color: rgba(128, 128, 128, 0.05) !important; 
        border: 1px solid rgba(128, 128, 128, 0.15) !important; 
        border-radius: 8px !important;
        padding: 12px !important;
        margin-bottom: 15px !important;
        font-size: 0.85em !important; 
        line-height: 1.6 !important;
        box-shadow: inset 0 0 10px rgba(0,0,0,0.02) !important;
        
        user-select: none !important;
        -webkit-user-select: none !important;
    }

    div[class*="think"]::-webkit-scrollbar,
    div[class*="Think"]::-webkit-scrollbar,
    div[class*="thought"]::-webkit-scrollbar,
    [class*="reasoning"]::-webkit-scrollbar {
        width: 6px !important;
    }
    div[class*="think"]::-webkit-scrollbar-thumb,
    div[class*="Think"]::-webkit-scrollbar-thumb,
    div[class*="thought"]::-webkit-scrollbar-thumb,
    [class*="reasoning"]::-webkit-scrollbar-thumb {
        background-color: rgba(150, 150, 150, 0.4) !important;
        border-radius: 4px !important;
    }
</style>
    `;

  // 🎯 سلکتورها: هم باکس فکر کردن، هم بلاک‌های کد
  const THINK_SELECTOR = 'div[class*="think"], div[class*="Think"], div[class*="thought"], div[class*="Thought"], [class*="reasoning"], [class*="ds-think"]';
  const CODE_SELECTOR = 'pre, .ds-markdown pre';
  const ALL_SCROLL_SELECTORS = `${THINK_SELECTOR}, ${CODE_SELECTOR}`;

  const userScrollState = new WeakMap();

  // 📦 بچ کردن اسکرول‌ها
  const pendingScrolls = new Set();
  let rafId = null;
  const flushScrolls = () => {
    rafId = null;
    pendingScrolls.forEach(box => {
      // اگر کاربر خودش با موس یا انگشت اسکرول نکرده باشد، سیستم اسکرول می‌کند
      if (userScrollState.get(box) !== true) {
        box.scrollTop = box.scrollHeight;
      }
    });
    pendingScrolls.clear();
  };
  
  const scheduleScroll = (box) => {
    pendingScrolls.add(box);
    if (rafId === null) rafId = requestAnimationFrame(flushScrolls);
  };

  // تشخیص اسکرول دستی کاربر (چه در باکس فکر کردن، چه در بلاک کد)
  const markUserScroll = (e) => {
    const box = e.target.closest ? e.target.closest(ALL_SCROLL_SELECTORS) : null;
    if (box) {
      setTimeout(() => {
        const isNearBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 30;
        userScrollState.set(box, !isNearBottom);
      }, 150);
    }
  };
  document.addEventListener('wheel', markUserScroll, { capture: true, passive: true });
  document.addEventListener('touchmove', markUserScroll, { capture: true, passive: true });

  // 👀 رصد تغییرات صفحه
  const observer = new MutationObserver((mutations) => {
    for (const m of mutations) {
      if (m.type === 'characterData') {
        const parent = m.target.parentElement;
        const box = parent && parent.closest ? parent.closest(ALL_SCROLL_SELECTORS) : null;
        if (box) scheduleScroll(box);
      } else if (m.type === 'childList') {
        const target = m.target.nodeType === 1 ? m.target : m.target.parentElement;
        if (target && target.closest) {
          const box = target.closest(ALL_SCROLL_SELECTORS);
          if (box) scheduleScroll(box);
        }
        for (const node of m.addedNodes) {
          if (node.nodeType !== 1) continue;
          if (node.matches && node.matches(ALL_SCROLL_SELECTORS)) {
            scheduleScroll(node);
          } else if (node.querySelectorAll) {
            node.querySelectorAll(ALL_SCROLL_SELECTORS).forEach(b => scheduleScroll(b));
          }
        }
      }
    }
  });
  observer.observe(document.body, {
    childList: true,
    subtree: true,
    characterData: true
  });

  // 🔥 راه‌حل قطعی سلکت نشدن از بیرون (مخصوص باکس فکر کردن)
  if (!window.__deepseek_think_select_handler__) {
    window.__deepseek_think_select_handler__ = true;

    document.addEventListener('mousedown', (e) => {
      const clickedBox = e.target.closest ? e.target.closest(THINK_SELECTOR) : null;
      const allBoxes = document.querySelectorAll(THINK_SELECTOR);

      if (clickedBox) {
        allBoxes.forEach(box => {
          box.style.setProperty('user-select', 'text', 'important');
          box.style.setProperty('-webkit-user-select', 'text', 'important');
        });
      } else {
        allBoxes.forEach(box => {
          box.style.setProperty('user-select', 'none', 'important');
          box.style.setProperty('-webkit-user-select', 'none', 'important');
        });
      }
    }, { capture: true });
  }

  // 🧹 Copy handler
  if (!window.__deepseek_think_copy_handler__) {
    window.__deepseek_think_copy_handler__ = true;
    document.addEventListener('copy', (e) => {
      const selection = window.getSelection();
      if (!selection.rangeCount || selection.isCollapsed) return;
      const range = selection.getRangeAt(0);
      const thinkBoxes = document.querySelectorAll(THINK_SELECTOR);
      if (thinkBoxes.length === 0) return;

      for (const box of thinkBoxes) {
        if (box.contains(range.startContainer) && box.contains(range.endContainer)) return;
      }
      let includesThink = false;
      for (const box of thinkBoxes) {
        if (selection.containsNode(box, true)) { includesThink = true; break; }
      }
      if (!includesThink) return;

      e.preventDefault();
      const clone = range.cloneContents();
      const temp = document.createElement('div');
      temp.appendChild(clone);
      temp.querySelectorAll(THINK_SELECTOR).forEach(b => b.remove());
      const cleaned = (temp.textContent || '').replace(/\n{3,}/g, '\n\n').trim();
      e.clipboardData.setData('text/plain', cleaned);
    });
  }
}
DEEPSEEK();
})();
