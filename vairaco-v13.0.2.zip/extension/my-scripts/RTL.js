// @title RTL
(() => {
  document.documentElement.classList.add('custom-rtl');
  if (document.getElementById('sc-rtl-style')) return;
  const s = document.createElement('style');
  s.id = 'sc-rtl-style';
  s.textContent = `
    .custom-rtl, .custom-rtl body,
    .custom-rtl *:not(pre):not(pre *):not(code):not(code *):not(svg):not(svg *) {
      direction: rtl !important;
      text-align: right !important;
    }
    .custom-rtl textarea, .custom-rtl input, .custom-rtl [contenteditable="true"] {
      unicode-bidi: plaintext;
      text-align: start !important;
    }
  `;
  document.head.appendChild(s);
})();
