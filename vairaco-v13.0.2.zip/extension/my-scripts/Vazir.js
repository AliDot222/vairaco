// @title Vazir
(() => {
  if (document.getElementById('vc-vazir-style')) return;
  const s = document.createElement('style');
  s.id = 'vc-vazir-style';
  s.textContent = `
    body, body *:not(pre):not(pre *):not(code):not(code *):not(kbd):not(samp):not(svg):not(svg *):not([class*="icon" i]):not(i) {
      font-family: "Vazirmatn", "Vazir", Tahoma, sans-serif !important;
    }`;
  (document.head || document.documentElement).appendChild(s);
})();
