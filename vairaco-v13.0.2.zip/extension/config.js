// vairaco — project page (open source). Change if you fork.
export const UPDATE_URL = 'https://github.com/AliDot222/vairaco';
