// vairaco — the one place that writes to disk: settings.json in the extension's own folder.
// Chrome only lets an extension write to a folder the user picked once (File System Access API); the handle is kept in IndexedDB.
const DB = 'vairaco-fs', ST = 'h', KEY = 'dir';
const idb = () => new Promise((res, rej) => { const r = indexedDB.open(DB, 1); r.onupgradeneeded = () => r.result.createObjectStore(ST); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
export async function getDir() { try { const db = await idb(); return await new Promise(res => { const q = db.transaction(ST).objectStore(ST).get(KEY); q.onsuccess = () => res(q.result || null); q.onerror = () => res(null); }); } catch { return null; } }
export async function setDir(h) { const db = await idb(); await new Promise((res, rej) => { const tx = db.transaction(ST, 'readwrite'); h ? tx.objectStore(ST).put(h, KEY) : tx.objectStore(ST).delete(KEY); tx.oncomplete = res; tx.onerror = () => rej(tx.error); }); }
export const hasWrite = async h => { try { return (await h.queryPermission({ mode: 'readwrite' })) === 'granted'; } catch { return false; } };
export async function ensureWrite(h) { if (await hasWrite(h)) return true; try { return (await h.requestPermission({ mode: 'readwrite' })) === 'granted'; } catch { return false; } }   // needs a click
export const pickDir = () => showDirectoryPicker({ id: 'vairaco-ext', mode: 'readwrite' });
export async function writeText(h, name, text) { const f = await h.getFileHandle(name, { create: true }); const w = await f.createWritable(); await w.write(text); await w.close(); }
export const removeFile = async (h, name) => { try { await h.removeEntry(name); } catch { /* already gone */ } };

// The user may pick Downloads, a parent, or the extension folder itself, and may have several vairaco copies around.
// We look (depth <= 3) for folders that contain a manifest.json and accept ONLY the one that is the loaded extension:
// we write a random marker file into the candidate and this running extension must be able to read the same marker back.
// Only folders whose manifest.json is byte-identical to ours are even considered, so unrelated extensions are never written to.
export async function findOurFolder(picked, readBack, ownManifest) {
  const cands = []; let seen = 0;
  async function walk(d, depth) {
    if (++seen > 400) return;
    try {
      const f = await (await d.getFileHandle('manifest.json')).getFile();
      if (ownManifest == null || (await f.text()) === ownManifest) cands.push(d);   // other extensions / other versions are never touched
      return;
    } catch { /* not an extension folder */ }
    if (depth >= 3) return;
    try { for await (const [n, e] of d.entries()) if (e.kind === 'directory' && !n.startsWith('.') && n !== 'node_modules') await walk(e, depth + 1); } catch { /* unreadable */ }
  }
  await walk(picked, 0);
  if (!cands.length) return { h: null, why: 'no folder with the same manifest.json as the running extension' };
  for (const c of cands) {
    const name = 'vc-link-check-' + Math.random().toString(36).slice(2) + '.txt', nonce = Math.random().toString(36).slice(2) + Date.now();
    try { await writeText(c, name, nonce); if ((await readBack(name)) === nonce) return { h: c, why: '' }; } catch { /* try next */ } finally { await removeFile(c, name); }
  }
  return { h: null, why: cands.length + ' extension folder(s) found, none is the loaded copy' };
}
