// Content Script برای اعمال خودکار استایل نشانگر موس
(function() {
  try {
    chrome.storage.local.get(['cursorEnabled'], (result) => {
      try {
        if (result.cursorEnabled === true) {
          const style = document.createElement('style');
          style.textContent = `
* {
    cursor: url("https://cur.cursors-4u.net/cursors/cur-2/cur116.cur"), auto !important;
}
          `;
          document.documentElement.appendChild(style);
        }
      } catch (e) {
        console.warn('Cursor style injection failed:', e);
      }
    });
  } catch (e) {
    console.warn('Cursor content script error:', e);
  }
})();
