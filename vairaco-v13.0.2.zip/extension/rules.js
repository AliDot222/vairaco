// قوانین سایت: «اگر رفتم در این دامنه → این اسکریپت‌ها اجرا شوند». ذخیره در حافظه‌ی خود اکستنشن (chrome.storage.local)
const KEY = 'rules';
export const MAX_RULES = 100;

// ورودی کاربر (آدرس کامل، با www، با مسیر، با پورت...) → دامنه‌ی تمیز. نامعتبر = null
export function normalizeDomain(input) {
  let s = String(input || '').trim().toLowerCase();
  if (!s) return null;
  s = s.replace(/^[a-z][a-z0-9+.-]*:\/\//, '').split(/[\/?#]/)[0].replace(/^\*\./, '').replace(/^www\./, '').replace(/:\d+$/, '').replace(/\.$/, '');
  if (/[^\x00-\x7f]/.test(s)) { try { s = new URL('http://' + s).hostname; } catch { return null; } }   // دامنه‌ی فارسی → punycode (همان که مرورگر می‌بیند)
  if (s.length > 253) return null;
  return /^([a-z0-9-]+\.)*[a-z0-9-]+\.[a-z0-9-]{2,}$/.test(s) || s === 'localhost' ? s : null;
}

// دامنه‌ی قانون، خودش و همه‌ی ساب‌دامین‌هایش را شامل می‌شود
export function matchHost(host, domain) { return host === domain || host.endsWith('.' + domain); }

// اسکریپت‌های قابل‌اجرا برای یک آدرس (به ترتیب قوانین، بدون تکرار)
export function scriptsForUrl(rules, url) {
  let host;
  try { const u = new URL(url); if (u.protocol !== 'http:' && u.protocol !== 'https:') return []; host = u.hostname.toLowerCase(); }
  catch { return []; }
  const ids = [];
  for (const r of rules) {
    if (!r || r.enabled === false || !r.domain || !matchHost(host, r.domain)) continue;
    for (const id of r.scripts || []) if (!ids.includes(id)) ids.push(id);
  }
  return ids;
}

export async function loadRules() { const o = await chrome.storage.local.get(KEY); return Array.isArray(o[KEY]) ? o[KEY] : []; }
export async function saveRules(rules) { await chrome.storage.local.set({ [KEY]: rules.slice(0, MAX_RULES) }); }
export const newRuleId = () => 'r' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
