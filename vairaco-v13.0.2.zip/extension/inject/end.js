// vairaco — closes the change-tracking window.
if (globalThis.__vc) globalThis.__vc.end();
