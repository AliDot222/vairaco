// فونت وزیر «لوکال»: از پوشه‌ی fonts خودِ افزونه خوانده و با FontFace API ثبت می‌شود (نه CDN، نه @font-face).
// چرا؟ سایت‌هایی مثل ChatGPT/Claude با CSP سخت‌گیر، لود فونت از بیرون را می‌بندند؛ ولی FontFace از روی بایت‌های محلی از CSP معاف است.
// اسکریپت‌های اصلی به اسم‌های Vazirmatn / Vazir / IranSans / IRANSans اشاره می‌کنند؛ همه به همین وزیر وصل می‌شوند (همه‌ی فونت‌ها وزیر).
// Reset همه‌ی FontFaceها را برمی‌دارد (ثبت در ردیاب).
(() => {
  const G = globalThis;
  if (G.__vcFaces) return;                         // قبلاً ثبت شده (دو اسکریپت پشت‌سرهم)
  const faces = (G.__vcFaces = []);
  const FAMILIES = ['Vazirmatn', 'Vazir', 'IranSans', 'IRANSans'];
  const WEIGHTS = [['Light', '100 300'], ['Regular', '400'], ['Medium', '500 600'], ['Bold', '700'], ['ExtraBold', '800'], ['Black', '900']];
  if (G.__vc) G.__vc.cleanup(() => { faces.forEach(f => { try { document.fonts.delete(f); } catch (e) {} }); if (G.__vcFaces === faces) G.__vcFaces = null; });
  (async () => {
    for (const [file, weight] of WEIGHTS) {
      let buf;
      try { buf = await (await fetch(chrome.runtime.getURL('fonts/Vazirmatn-' + file + '.woff2'))).arrayBuffer(); }
      catch (e) { continue; }                      // یک وزن نیامد → بقیه ادامه می‌دهند
      if (G.__vcFaces !== faces) return;           // وسط کار Reset شد
      for (const fam of FAMILIES) {
        try {
          const f = new FontFace(fam, buf.slice(0), { weight, style: 'normal', display: 'swap' });
          await f.load(); document.fonts.add(f); faces.push(f);
        } catch (e) { /* فونت خراب/مسدود: نادیده */ }
      }
    }
  })();
})();
