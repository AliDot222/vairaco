// vairaco — opens the change-tracking window (closed by inject/end.js after the script file ran).
if (globalThis.__vc) globalThis.__vc.begin(true);
