// تکمیل‌کننده‌ی Reset Styles (فایل اصلی reset-styles.js بدون تغییر می‌ماند).
// آثاری را پاک می‌کند که ریست اصلی پاک نمی‌کند: کلاس‌های روی المنت‌ها، spanهای GPT--MATH،
// style="" خالی، و همه‌ی فریم‌ها (حتی cross-origin). مستقل از هر متغیر بیرونی است.
export function ResetExtra() {
  try {
    // نشانه‌های اختصاصی خودمان: همیشه پاک می‌شوند
    const OWN = ['tm-persian-font-applied', '.custom-rtl', 'sc-rtl-style', 'sc-font-style'];
    // نشانه‌های عمومی (ممکن است سایت هم داشته باشد، مثل language- در Prism یا box-content در Tailwind):
    // فقط وقتی پاک می‌شوند که حداقل ۲ نشانه با هم در یک استایلِ «کوچک» باشند (استایل تزریق‌شده کوچک است، CSS سایت بزرگ)
    const GENERIC = ['Vazir', 'IranSans', 'IRANSans', 'Fira Code', 'unicode-bidi: plaintext', 'mjx-container', 'font-size: 20px'];   // language- و box-content عمداً نیست (CSS سایت‌ها هم دارند)؛ ریست اصلی خودش آن‌ها را مدیریت می‌کند
    // استایل Cursor عمداً در هیچ لیستی نیست؛ ریست آن را پاک نمی‌کند
    const IDS = ['tm-persian-font-style', 'claude-fa-style', 'fa-dir-style', 'sc-rtl-style', 'sc-font-style',
      'claude-fa-link', 'claude-fa-link2', 'claude-fa-link3', 'fa-font-link', 'sc-font-link'];

    // لینک فونت‌ها
    document.querySelectorAll('link[href*="vazir" i], link[href*="iransans" i], link[href*="fira" i]').forEach(n => n.remove());
    IDS.forEach(id => { const n = document.getElementById(id); if (n) n.remove(); });

    // استایل‌های تزریق‌شده (Cursor شامل نمی‌شود)
    document.querySelectorAll('style').forEach(s => {
      const t = s.textContent || '';
      if (OWN.some(m => t.includes(m)) || (t.length < 4000 && GENERIC.filter(m => t.includes(m)).length >= 2)) s.remove();
    });

    // کلاس‌ها
    document.querySelectorAll('.tm-persian-font-applied').forEach(el => el.classList.remove('tm-persian-font-applied'));
    document.documentElement.classList.remove('custom-rtl', 'tm-persian-font-applied');
    if (document.body) document.body.classList.remove('custom-rtl', 'tm-persian-font-applied');
    document.querySelectorAll('[class=""]').forEach(el => el.removeAttribute('class'));

    // اندازه‌ی فونت اینلاین FONT17PX
    document.querySelectorAll('[style]').forEach(el => { if (el.style.fontSize === '20px') el.style.fontSize = ''; });

    // spanهای GPT--MATH: دوباره به متن ساده برگردند
    const wrapped = [];
    document.querySelectorAll('span[style]').forEach(sp => {
      if (sp.attributes.length === 1 &&
          sp.style.direction === 'ltr' && sp.style.unicodeBidi === 'plaintext' &&
          /monospace/.test(sp.style.fontFamily) && sp.childNodes.length === 1 && sp.firstChild.nodeType === 3) wrapped.push(sp);
    });
    wrapped.forEach(sp => {
      const p = sp.parentNode;
      if (!p) return;
      p.replaceChild(document.createTextNode(sp.textContent), sp);
      p.normalize();
    });

    // style="" خالی
    document.querySelectorAll('[style]').forEach(el => { if (!el.getAttribute('style').trim()) el.removeAttribute('style'); });

    if (document.documentElement.getAttribute('lang') === 'fa') document.documentElement.removeAttribute('lang');
  } catch (e) { /* ریست نباید صفحه را خراب کند */ }
}

// ResetStyles اصلی هر <style> که language- یا box-content داشته باشد را پاک می‌کند (برای استایل‌های Claude)، ولی Prism/highlight.js/Tailwind سایت‌ها هم همین را دارند.
// پس: قبل از ResetStyles استایل‌هایی که «فقط» به‌خاطر این دو نشانه در خطرند کنار گذاشته و بعدش برمی‌گردند؛ استایل‌های خودِ اسکریپت‌ها (نشانه‌ی قوی/شناسه‌ی اختصاصی) برنمی‌گردند.
export function StashSiteStyles() {
  try {
    const STRONG = ['Vazir', 'IranSans', 'IRANSans', 'Fira Code', 'tm-persian-font-applied', '.custom-rtl', 'unicode-bidi: plaintext', 'mjx-container', 'sc-rtl-style', 'sc-font-style'];   // font-size: 20px عمداً نیست (در CSS سایت‌ها رایج است)
    const OWN_IDS = ['tm-persian-font-style', 'claude-fa-style', 'fa-dir-style', 'sc-rtl-style', 'sc-font-style'];
    const keep = [];
    document.querySelectorAll('style').forEach(s => {
      const t = s.textContent || '';
      if (OWN_IDS.includes(s.id)) return;
      if (!(t.includes('language-') || t.includes('box-content'))) return;
      if (STRONG.some(m => t.includes(m))) return;
      keep.push({ el: s, parent: s.parentNode });
    });
    // جای هر استایل = اولین همسایه‌ی بعدی که خودش کنار گذاشته نشده (تا چند استایل کنار هم با ترتیب اصلی برگردند)
    const set = new Set(keep.map(k => k.el));
    keep.forEach(k => { let n = k.el.nextSibling; while (n && set.has(n)) n = n.nextSibling; k.next = n; });
    globalThis.__vcStash = keep;
  } catch (e) { globalThis.__vcStash = []; console.warn('[vairaco] stash failed', e); }
}
export function RestoreSiteStyles() {
  try {
    (globalThis.__vcStash || []).forEach(k => {
      if (!k.el.isConnected && k.parent && k.parent.isConnected) k.parent.insertBefore(k.el, k.next && k.next.parentNode === k.parent ? k.next : null);   // به ترتیب اصلی: هر کدام قبل از همان همسایه‌ی پایدار
    });
  } catch (e) { console.warn('[vairaco] restore failed', e); }
  globalThis.__vcStash = [];
}
