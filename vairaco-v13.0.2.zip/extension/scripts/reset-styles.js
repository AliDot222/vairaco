export function ResetStyles() {
  (function () {
    try {
      // 1. حذف لینک‌های فونت تزریق شده
      document.querySelectorAll(
        'link[href*="vazir"], link[href*="vazirmatn"], link[href*="iransans"], link[href*="fira_code"], link[href*="firacode"], link[href*="fira-code"], #claude-fa-link, #claude-fa-link2, #claude-fa-link3, #fa-font-link'
      ).forEach(n => n.remove());

      // 2. حذف استایل‌های تزریق شده (تگ‌های style)
      document.querySelectorAll('style').forEach(s => {
        const txt = s.textContent || "";
        if (
          s.id === 'tm-persian-font-style' ||
          s.id === 'claude-fa-style' ||
          s.id === 'fa-dir-style' ||
          txt.includes('Vazir') || txt.includes('Vazirmatn') ||
          txt.includes('IranSans') || txt.includes('IRANSans') ||
          txt.includes('Fira Code') ||
          txt.includes('tm-persian-font-applied') ||
          txt.includes('.custom-rtl') ||
          txt.includes('unicode-bidi: plaintext') ||
          txt.includes('mjx-container') ||
          txt.includes('font-size: 20px') ||
          txt.includes('box-content') ||
          txt.includes('language-') ||
          // 👇 کلمات کلیدی جدید برای شناسایی استایل دیپ‌سیک
          txt.includes('scrollbar-width: thin') ||
          txt.includes('div[class*="think"]') ||
          txt.includes('max-height: 400px')
        ) {
          s.remove();
        }
      });

      // 3. حذف استایل‌های درون‌خطی (Inline Styles)
      document.querySelectorAll('body *').forEach(el => {
        // ریست فونت 20px
        if (el.style.fontSize === '20px') {
          el.style.fontSize = ''; 
        }
        // 👇 ریست کردن user-select که اسکریپت دیپ‌سیک موقع کلیک اعمال می‌کند
        if (el.style.userSelect || el.style.webkitUserSelect) {
          el.style.removeProperty('user-select');
          el.style.removeProperty('-webkit-user-select');
        }
      });

      // 4. حذف کلاس‌ها و ویژگی‌های تزریق شده
      document.documentElement.classList.remove('custom-rtl', 'tm-persian-font-applied');
      if (document.documentElement.getAttribute('lang') === 'fa') {
        document.documentElement.removeAttribute('lang');
      }

      // 5. پاک کردن فلگ‌های سراسری (تا اگر دوباره اسکریپت را اجرا کردید، تازه شروع شود)
      if (window.__deepseek_think_select_handler__) delete window.__deepseek_think_select_handler__;
      if (window.__deepseek_think_copy_handler__) delete window.__deepseek_think_copy_handler__;

      // 6. تلاش برای پاکسازی iframe ها
      document.querySelectorAll('iframe').forEach(fr => {
        try {
          const doc = fr.contentDocument;
          if (!doc) return;
          doc.querySelectorAll('#tm-persian-font-style, style').forEach(s => {
            const txt = s.textContent || "";
            if (
              s.id === 'tm-persian-font-style' ||
              txt.includes('tm-persian-font-applied') ||
              txt.includes('IranSans') || txt.includes('Vazir') ||
              txt.includes('Vazirmatn') || txt.includes('font-size: 20px')
            ) s.remove();
          });
          doc.querySelectorAll('.tm-persian-font-applied').forEach(el => el.classList.remove('tm-persian-font-applied'));
        } catch (e) {}
      });

      console.clear();
      console.log('✅ ResetStyles: تمام تغییرات (فونت‌ها، استایل‌ها، user-select و کلاس‌ها) با موفقیت پاک شد');
    } catch (e) {
      console.error('Reset Styles failed:', e);
    }
  })();
}
