export function CursorEnable() {
  chrome.storage.local.set({ cursorEnabled: true }, () => {
    chrome.tabs.query({}, (tabs) => {
      tabs.forEach(tab => {
        chrome.tabs.reload(tab.id);
      });
    });
  });
}

export function CursorDisable() {
  chrome.storage.local.set({ cursorEnabled: false }, () => {
    chrome.tabs.query({}, (tabs) => {
      tabs.forEach(tab => {
        chrome.tabs.reload(tab.id);
      });
    });
  });
}
