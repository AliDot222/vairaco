export function RTL() {
  const vc = globalThis.__vc;          // ردیاب (inject/tracker.js) برای اینکه Reset بتواند دقیق برگرداند
  if (vc) vc.begin();
  // راست‌به‌چپ کردن کل صفحه
  document.documentElement.classList.add('custom-rtl');

  if (!document.getElementById('sc-rtl-style')) {
    const s = document.createElement('style');
    s.id = 'sc-rtl-style';
    s.textContent = `
      .custom-rtl, .custom-rtl body,
      .custom-rtl *:not(pre):not(pre *):not(code):not(code *):not(svg):not(svg *) {
        direction: rtl !important;
        text-align: right !important;
      }
      .custom-rtl textarea, .custom-rtl input, .custom-rtl [contenteditable="true"] {
        unicode-bidi: plaintext;
        text-align: start !important;
      }
    `;
    document.head.appendChild(s);
  }
  if (vc) vc.end();
}
