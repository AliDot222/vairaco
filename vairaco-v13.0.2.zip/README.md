# vairaco

**Free, open-source Chrome extension that gives AI chat sites beautiful RTL support and the Vazirmatn font.**
Persian · Arabic · Dari/Pashto · Urdu · Hebrew — any right-to-left language.

No ads. No account. No server. No tracking. Scripts and fonts are bundled inside the extension. Your own scripts stay in your browser.

Works on ChatGPT, Claude, Gemini, DeepSeek, Google AI Studio, Copilot and more — code blocks and math stay untouched.

## Install

1. Download the latest zip from [Releases](https://github.com/AliDot222/vairaco/releases) and unzip it (or clone this repo).
2. Open `chrome://extensions/` and turn on **Developer mode** (top right).
3. Click **Load unpacked** and choose the **`extension`** folder — the one that contains `manifest.json`.
4. Pin vairaco from the puzzle-piece menu.

Keep the folder in place after installing. To update: replace the folder contents (keep your own `settings.json` and any scripts you added in `my-scripts/`) and press the reload button on `chrome://extensions/`; your settings are kept.

## Use

- **Right-click menu:** right-click on a page → *vairaco* → pick a script (RTL, Vazir, or a site-specific style). *Reset Styles* undoes everything (the Cursor stays).
- **Site rules:** popup → *Site rules* → add a site (e.g. `claude.ai`) and drag scripts into it. They are applied automatically on every visit.
- **Edit with Notepad, applied instantly:** every `name.js` in `extension/my-scripts/` is a script. Edit or add a file with any editor, **Save**, switch back to Chrome — open pages are updated on the spot (no reload, no buttons). A brand-new file is picked up the next time you open the popup (Chrome only lets a window page list a folder). Put `// @auto` and `// @sites site.com` on the first lines to make a script run on those sites by itself. Popup → *My scripts* has a ready template.
- **Settings live inside the extension folder** (`settings.json`, next to `manifest.json`): every Chrome profile — even with a different Google account — that loads this folder sees the same site rules and right-click menu, and if you zip the folder and give it to a friend they get your settings too. Reading is automatic; to *save* from a profile, press **Link extension folder** once (Site rules tab) and pick the folder you loaded — you can even pick a bigger folder such as Downloads, vairaco finds the running copy itself. Export/Import still works. (Chrome Web Store installs have no writable folder; this is for Load unpacked.)
- **Languages:** the popup are available in فارسی, العربية and English.

All scripts live in one place: **`extension/my-scripts/`** — one plain `name.js` file per script. You can also drop files there by hand; the extension notices them when you open the popup.

## Writing your own scripts — keep Reset in mind

The **Reset Styles** button must always bring a site back to how it was. vairaco undoes by itself what a script does to the page: elements, attributes, classes, inline styles, text, observers, timers, event listeners, new global variables, `localStorage`/`sessionStorage` writes, constructed stylesheets, `insertRule`/`deleteRule` and new fonts.

Things it **cannot** see, so a script that does them must also be handled in `extension/scripts/reset-extra.js` (the extra reset step) — otherwise the change stays on the site after Reset:
- changes inside shadow DOM, or `localStorage.x = 1` written directly (use `setItem`);
- anything saved outside the page (cookies, a site's server/account settings);
- anything that is not undone by simply removing it (e.g. you rewrote a page-owned object).

Rule of thumb: after writing or changing a script, test it — apply it, press **Reset Styles**, and check the site looks exactly as before. If something is left over, add its cleanup to `reset-extra.js` in the same change. Give your injected elements a recognisable `id` (e.g. `my-style`) so cleanup is easy.

## Privacy

vairaco itself makes **no network requests** and has no analytics. Settings are stored locally in your browser (`chrome.storage`). The only exception is the optional *Cursor* feature: when you enable it, the page loads a cursor image from `cur.cursors-4u.net`.  Everything else, including all Persian/Arabic fonts, is local.

## Project layout

| Path | Purpose |
|---|---|
| `extension/` | The extension itself (load this folder) |
| `extension/my-scripts/` | **All scripts** — one `name.js` each (header: `// @title`, `// @sites`, `// @sticky`) |
| `extension/fonts/` | Vazirmatn woff2 files (SIL OFL) — registered locally via `FontFace`, CSP-safe |
| `extension/i18n.js` | UI translations (fa / ar / en) |
| `tools/make-seed.mjs` | Regenerates the first-run list `extension/registry.js` after you add/remove a default script |

## Contributing

Issues and pull requests are welcome — see [CONTRIBUTING.md](CONTRIBUTING.md). Translations, new site styles and bug reports for AI sites are especially useful.

## License

MIT — see [LICENSE](LICENSE). Vazirmatn font: SIL OFL 1.1 ([extension/fonts/OFL.txt](extension/fonts/OFL.txt)).

---

## فارسی

**افزونه‌ی رایگان و متن‌باز کروم برای راست‌چین و فونت وزیر در سایت‌های هوش مصنوعی** (ChatGPT، Claude، Gemini، Google AI Studio، Copilot و …). بدون تبلیغ، بدون ثبت‌نام، بدون سرور؛ فونت‌ها و اسکریپت‌ها همه داخل خود افزونه‌اند.

**نصب:** zip را از بخش [Releases](https://github.com/AliDot222/vairaco/releases) بگیرید و از حالت فشرده خارج کنید ← در `chrome://extensions/` گزینه‌ی **Developer mode** را روشن کنید ← **Load unpacked** ← پوشه‌ی **`extension`** (همان که `manifest.json` دارد) را انتخاب کنید.

**استفاده:** راست‌کلیک روی صفحه ← vairaco ← اسکریپت دلخواه. برای اجرای خودکار، در پاپ‌آپ تب «قوانین سایت» را باز کنید، آدرس سایت را اضافه و اسکریپت‌ها را به آن بکشید.

## العربية

**إضافة Chrome مجانية ومفتوحة المصدر تضيف دعم الكتابة من اليمين إلى اليسار وخط Vazirmatn لمواقع الذكاء الاصطناعي.** بلا إعلانات ولا حساب ولا خادم؛ الخطوط والسكربتات كلها داخل الإضافة.

**التثبيت:** حمّل ملف zip من [Releases](https://github.com/AliDot222/vairaco/releases) وفكّ ضغطه ← افتح `chrome://extensions/` وفعّل **Developer mode** ← **Load unpacked** ← اختر المجلد **`extension`** (الذي يحتوي على `manifest.json`).

**الاستخدام:** انقر بزر الفأرة الأيمن في الصفحة ← vairaco ← اختر السكربت. وللتشغيل التلقائي افتح النافذة المنبثقة وتبويب «قواعد المواقع» وأضف الموقع واسحب السكربتات إليه.
