# vairaco

**Free, open-source Chrome extension that gives AI chat sites beautiful RTL support and the Vazirmatn font.**
Persian · Arabic · Dari/Pashto · Urdu · Hebrew — any right-to-left language.

No ads. No account. No server. No tracking. Scripts and fonts are bundled inside the extension. Your own scripts stay in your browser.

Works on ChatGPT, Claude, Gemini, DeepSeek, Google AI Studio, Copilot and more — code blocks and math stay untouched.

## Install

1. Download the latest zip from [Releases](https://github.com/AliDot222/vairaco/releases) and unzip it (or clone this repo).
2. Open `chrome://extensions/` and turn on **Developer mode** (top right).
3. Click **Load unpacked** and choose the **`extension`** folder — the one that contains `manifest.json`.
4. Pin vairaco from the puzzle-piece menu.

Keep the folder in place after installing. To update: replace the folder contents and press the reload button on `chrome://extensions/`; your settings are kept.

## Use

- **Right-click menu:** right-click on a page → *vairaco* → pick a script (RTL, Vazir, or a site-specific style). *Reset Styles* undoes everything (the Cursor stays).
- **Site rules:** popup → *Site rules* → add a site (e.g. `claude.ai`) and drag scripts into it. They are applied automatically on every visit.
- **Script editor** (popup → *Editor*): see, edit, delete or add any script with a few buttons — **New · Save · Delete · Copy AI prompt · Undo on page**. *Save* writes the file and applies it to the page you were just on; no reload. The code box is exactly what you can paste into the browser console.
  - One-time setup: the editor asks you to pick the `my-scripts` folder inside the extension folder you loaded (browsers only let an extension write files into a folder you choose).
  - **Make a script with AI:** press *Copy AI prompt*, paste it into any AI, add your wish at the end ("make the background cream"), paste the answer into the editor, *Save*. Done.
- **Languages:** the popup and editor are available in فارسی, العربية and English.

All scripts live in one place: **`extension/my-scripts/`** — one plain `name.js` file per script. You can also drop files there by hand; the extension notices them when you open the popup.

## Privacy

vairaco itself makes **no network requests** and has no analytics. Settings are stored locally in your browser (`chrome.storage`). The only exception is the optional *Cursor* feature: when you enable it, the page loads a cursor image from `cur.cursors-4u.net`. Also, the Claude site script loads the Fira Code code font from a public CDN (jsdelivr); everything else, including all Persian/Arabic fonts, is local. Bundling Fira Code too is a good first contribution.

## Project layout

| Path | Purpose |
|---|---|
| `extension/` | The extension itself (load this folder) |
| `extension/my-scripts/` | **All scripts** — one `name.js` each (header: `// @title`, `// @sites`, `// @sticky`) |
| `extension/fonts/` | Vazirmatn woff2 files (SIL OFL) — registered locally via `FontFace`, CSP-safe |
| `extension/editor.*` | The script editor page |
| `extension/i18n.js` | UI translations (fa / ar / en) |
| `tools/make-seed.mjs` | Regenerates the first-run list `extension/registry.js` after you add/remove a default script |

## Contributing

Issues and pull requests are welcome — see [CONTRIBUTING.md](CONTRIBUTING.md). Translations, new site styles and bug reports for AI sites are especially useful.

## License

MIT — see [LICENSE](LICENSE). Vazirmatn font: SIL OFL 1.1 ([extension/fonts/OFL.txt](extension/fonts/OFL.txt)).

---

## فارسی

**افزونه‌ی رایگان و متن‌باز کروم برای راست‌چین و فونت وزیر در سایت‌های هوش مصنوعی** (ChatGPT، Claude، Gemini، Google AI Studio، Copilot و …). بدون تبلیغ، بدون ثبت‌نام، بدون سرور؛ فونت‌ها و اسکریپت‌ها همه داخل خود افزونه‌اند.

**نصب:** zip را از بخش [Releases](https://github.com/AliDot222/vairaco/releases) بگیرید و از حالت فشرده خارج کنید ← در `chrome://extensions/` گزینه‌ی **Developer mode** را روشن کنید ← **Load unpacked** ← پوشه‌ی **`extension`** (همان که `manifest.json` دارد) را انتخاب کنید.

**استفاده:** راست‌کلیک روی صفحه ← vairaco ← اسکریپت دلخواه. برای اجرای خودکار، در پاپ‌آپ تب «قوانین سایت» را باز کنید، آدرس سایت را اضافه و اسکریپت‌ها را به آن بکشید.

## العربية

**إضافة Chrome مجانية ومفتوحة المصدر تضيف دعم الكتابة من اليمين إلى اليسار وخط Vazirmatn لمواقع الذكاء الاصطناعي.** بلا إعلانات ولا حساب ولا خادم؛ الخطوط والسكربتات كلها داخل الإضافة.

**التثبيت:** حمّل ملف zip من [Releases](https://github.com/AliDot222/vairaco/releases) وفكّ ضغطه ← افتح `chrome://extensions/` وفعّل **Developer mode** ← **Load unpacked** ← اختر المجلد **`extension`** (الذي يحتوي على `manifest.json`).

**الاستخدام:** انقر بزر الفأرة الأيمن في الصفحة ← vairaco ← اختر السكربت. وللتشغيل التلقائي افتح النافذة المنبثقة وتبويب «قواعد المواقع» وأضف الموقع واسحب السكربتات إليه.
