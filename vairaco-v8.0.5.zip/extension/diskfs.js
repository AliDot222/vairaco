// vairaco — saving scripts to the extension's my-scripts folder on disk.
// An extension cannot write files by itself, so the user links the folder once (File System Access API); the handle is kept in IndexedDB.
const idb = () => new Promise((res, rej) => { const r = indexedDB.open('vairaco-fs', 1); r.onupgradeneeded = () => r.result.createObjectStore('kv'); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
const kv = async (mode, fn) => { const db = await idb(); return new Promise((res, rej) => { const q = fn(db.transaction('kv', mode).objectStore('kv')); q.onsuccess = () => res(q.result); q.onerror = () => rej(q.error); }); };
export const getDir = () => kv('readonly', s => s.get('dir')).catch(() => null);
export const setDir = h => kv('readwrite', s => (h ? s.put(h, 'dir') : s.delete('dir')));
export const pickDir = () => window.showDirectoryPicker({ id: 'vairaco-scripts', mode: 'readwrite' });

// Must run inside a click handler (the permission prompt needs a user gesture)
export async function ensureWrite(h) {
  const o = { mode: 'readwrite' };
  try { if ((await h.queryPermission(o)) === 'granted') return true; return (await h.requestPermission(o)) === 'granted'; } catch { return false; }
}
export async function writeScript(h, file, code) {
  const fh = await h.getFileHandle(file, { create: true });
  const w = await fh.createWritable(); await w.write(code); await w.close();
}
export const removeScript = (h, file) => h.removeEntry(file);
// Find THIS extension's my-scripts folder inside whatever the user picked (the extracted project folder, "extension", or "my-scripts"; even a parent
// that holds several extension copies). Only the loaded copy is accepted — proven by a marker file that the running extension can read back
// (an unpacked extension is served live from its own folder, so no other copy can pass). Nothing outside the proven folder is kept or used.
// Returns { h, why }: h = the folder or null; why = short diagnostic text.
async function candidates(root) {
  const out = []; let seen = 0;
  const walk = async (dir, depth) => {
    if (dir.name === 'my-scripts') out.push(dir);
    if (depth >= 4 || seen > 400) return;
    try {
      for await (const [name, e] of dir.entries()) {
        if (e.kind !== 'directory' || name.startsWith('.') || name === 'node_modules' || name === 'fonts' || name === '_locales') continue;
        seen++; await walk(e, depth + 1);
      }
    } catch { /* unreadable */ }
  };
  await walk(root, 0);
  return out;
}
export async function findOurFolder(picked, canRead, pkgNames) {
  const cands = await candidates(picked);
  if (!cands.length) return { h: null, why: 'no "my-scripts" folder found inside "' + picked.name + '"' };
  const why = []; 
  for (const h of cands) {
    let overlap = 0;
    try { for await (const [name] of h.entries()) if (pkgNames.has(name)) overlap++; } catch { /* unreadable */ }
    const marker = 'zz-vairaco-link-check-' + Math.random().toString(36).slice(2) + '.js';
    try {
      await writeScript(h, marker, '// temporary link check');
      const ok = await canRead(marker).catch(() => false);
      await h.removeEntry(marker).catch(() => {});
      if (ok) return { h, why: '' };
      why.push('a my-scripts folder (' + overlap + ' matching files) is not the loaded extension');
    } catch (err) { why.push('could not write: ' + (err && err.name || 'error')); }
  }
  return { h: null, why: why.join(' | ') };
}
