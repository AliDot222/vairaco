vairaco — scripts folder
========================
Every  name.js  in this folder is a script: it shows up in the popup as "name" and in the right-click menu.
Easiest way: open the popup -> "Editor" and use the buttons (New / Save / Delete). It writes the files here for you.

Each file is plain JavaScript that also works if you paste it into the browser console.
Wrap it in  (() => { ... })();  and keep it free of import/export.
Optional first lines:
    // @title Pretty name
    // @sites chat.example.com, other.com      (adds it to "Suggested rules")
    // @sticky                                  (the page reloads once after Reset)
Keep this README.txt.
