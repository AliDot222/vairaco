// vairaco — script editor (full tab). Everything is one folder: my-scripts/. Save/Delete write real files there and apply instantly.
import { t, setLang, guessLang, applyI18n, LANGS } from './i18n.js';
import { syncScripts, readScript, scriptUrl } from './userscripts.js';
import { runScript, loadScripts, clearGuard, frozenIds } from './inject.js';
import { getDir, setDir, pickDir, ensureWrite, writeScript, removeScript, findOurFolder } from './diskfs.js';
import { loadRules, saveRules } from './rules.js';

const $ = id => document.getElementById(id);
const msg = (text, ok = false) => { $('msg').textContent = text || ''; $('msg').classList.toggle('ok', ok); };
const AI_PROMPT = `Write a small JavaScript snippet for the "vairaco" browser extension.
Rules: plain JavaScript wrapped in an IIFE: (() => { ... })(); no import/export, no libraries, no network requests. Change the page with DOM/CSS (best: add ONE <style> tag with an id, removing the old one first if it exists). Optional first lines: "// @title Short name" and "// @sites example.com".
Reply with ONLY the code in one code block.
My request: `;

let DIR = null, LIST = [], CUR = null;     // CUR: { file, isNew }
const FILE_OK = n => n.trim() === n && /^[^\n\r/\\<>:"|?*]{1,60}$/.test(n) && !/^\.+$/.test(n);

async function refresh() {
  LIST = (await syncScripts().catch(() => null)) || [];
  await loadScripts();
  const box = $('list'); box.innerHTML = '';
  for (const s of LIST) {
    const b = document.createElement('button'); b.className = 'item' + (CUR && CUR.file === s.file ? ' on' : '') + (s.bad ? ' bad' : ''); b.textContent = (s.bad ? '⚠ ' : '') + s.id;
    b.onclick = () => openScript(s.file); box.append(b);
  }
  await showConnect();
}
async function showConnect() {
  let ok = false;
  try { ok = !!DIR && (await DIR.queryPermission({ mode: 'readwrite' })) === 'granted'; } catch {}
  $('connect').classList.toggle('hidden', ok);
  $('btn-connect').textContent = DIR ? t('edAllowBtn') : t('edConnectBtn');
  $('connect-title').textContent = DIR ? t('edAllow') : t('edConnect');
  $('connect-desc').textContent = DIR ? t('edAllowDesc') : t('edConnectDesc');
}
async function openScript(file) {
  CUR = { file, isNew: false }; msg('');
  $('box').classList.remove('hidden'); $('name').value = file.replace(/\.js$/i, ''); $('code').value = await readScript(file);
  $('btn-del').classList.remove('hidden'); $('btn-del').textContent = t('edDelete'); delete $('btn-del').dataset.sure;
  await refresh();
  if ((await frozenIds()).includes(file.replace(/\.js$/i, ''))) msg(t('edFroze'));
  const bad = LIST.filter(s => s.bad === 'module').map(s => s.id); if (bad.length && LIST.find(s => s.file === file)?.bad) msg(t('edBadScript', bad.join(', ')));
}
$('btn-new').onclick = () => {
  CUR = { file: null, isNew: true }; msg('');
  $('box').classList.remove('hidden'); $('name').value = ''; $('code').value = t('edTemplate'); $('btn-del').classList.add('hidden'); $('name').focus(); refresh();
};
$('code').addEventListener('keydown', e => {   // Tab = two spaces
  if (e.key !== 'Tab' || e.shiftKey) return; e.preventDefault();
  const a = e.target, p = a.selectionStart; a.value = a.value.slice(0, p) + '  ' + a.value.slice(a.selectionEnd); a.selectionStart = a.selectionEnd = p + 2;
});

// Syntax check without running: compile in a sandbox page (an extension page may not eval)
let seq = 0;
const checkSyntax = code => new Promise(resolve => {
  const f = $('syntaxFrame'), id = ++seq;
  const done = r => { removeEventListener('message', on); clearTimeout(tm); resolve(r); };
  const on = e => { if (e.source === f.contentWindow && e.data && e.data.id === id) done(e.data); };
  const tm = setTimeout(() => done({ ok: true }), 1500);
  addEventListener('message', on);
  try { f.contentWindow.postMessage({ id, code }, '*'); } catch { done({ ok: true }); }
});

// The page the user was just looking at: most recently used normal web tab
async function lastWebTab() {
  const tabs = (await chrome.tabs.query({})).filter(x => /^https?:/.test(x.url || ''));
  tabs.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0));
  return tabs[0] || null;
}
async function renameInSettings(from, to) {
  const rules = await loadRules(); let ch = false;
  rules.forEach(r => { const i = r.scripts.indexOf(from); if (i >= 0) { if (to) r.scripts[i] = to; else r.scripts.splice(i, 1); ch = true; } });
  if (ch) await saveRules(rules);
  const { menuScripts } = await chrome.storage.local.get('menuScripts');
  if (Array.isArray(menuScripts) && menuScripts.includes(from)) await chrome.storage.local.set({ menuScripts: menuScripts.map(x => x === from ? to : x).filter(Boolean) });
}
async function needDir() {
  if (!DIR) { $('connect').classList.remove('hidden'); msg(t('edConnect')); return false; }
  if (!(await ensureWrite(DIR))) { msg(t('edNeedPerm')); return false; }
  return true;
}

$('btn-save').onclick = async () => {
  if (!CUR) return;
  const name = $('name').value, code = $('code').value;
  if (!name.trim()) return msg(t('edNeedName'));
  if (!FILE_OK(name)) return msg(t('edBadName'));
  const file = name + '.js', renamed = !CUR.isNew && file !== CUR.file;
  if ((CUR.isNew || renamed) && LIST.some(s => s.file.toLowerCase() === file.toLowerCase())) return msg(t('edDup'));
  const syn = await checkSyntax(code); if (!syn.ok) return msg(t('edSyntax', syn.msg));
  if (!(await needDir())) return;
  try {
    await writeScript(DIR, file, code);
    if (renamed) { await removeScript(DIR, CUR.file).catch(() => {}); await renameInSettings(CUR.file.replace(/\.js$/i, ''), name); }
  } catch (e) { return msg(t('edDiskFail', e && e.message || '')); }
  CUR = { file, isNew: false }; await clearGuard(name);
  $('btn-del').classList.remove('hidden');
  await refresh();
  const tab = await lastWebTab();
  if (!tab) return msg(t('edSavedNoTab'), true);
  try { await runScript(tab.id, name); msg(t('edSaved'), true); }
  catch (e) { msg(e && e.message === 'SCRIPT_FROZE' ? t('edFroze') : t('edSaved') + ' (' + (e && e.message || '') + ')', e && e.message !== 'SCRIPT_FROZE'); }
};
$('btn-del').onclick = async () => {
  if (!CUR || CUR.isNew) return;
  const b = $('btn-del');
  if (b.dataset.sure !== '1') { b.dataset.sure = '1'; b.textContent = t('edDeleteSure'); return; }
  if (!(await needDir())) return;
  const id = CUR.file.replace(/\.js$/i, '');
  try { await removeScript(DIR, CUR.file); } catch (e) { return msg(t('edDiskFail', e && e.message || '')); }
  await renameInSettings(id, null);
  CUR = null; $('box').classList.add('hidden'); await refresh(); msg(t('edDeleted'), true);
};
$('btn-prompt').onclick = async () => {
  try { await navigator.clipboard.writeText(AI_PROMPT); msg(t('edPromptDone'), true); }
  catch { $('code').value = AI_PROMPT + '\n\n' + $('code').value; msg(t('edPromptDone'), true); }
};
$('btn-undo').onclick = async () => {
  const tab = await lastWebTab(); if (!tab) return;
  const r = await chrome.runtime.sendMessage({ type: 'reset', tabId: tab.id }).catch(() => null);
  msg(r && r.ok ? '✓' : '', !!(r && r.ok));
};
$('btn-connect').onclick = async () => {
  try {
    if (DIR) { if (await ensureWrite(DIR)) { await refresh(); msg(t('edLinked'), true); } else msg(t('edNeedPerm')); return; }   // just re-grant, no picker
    const picked = await pickDir();
    const { h, why } = await findOurFolder(picked, async f => (await fetch(scriptUrl(f), { cache: 'no-store' })).ok, new Set(LIST.map(s => s.file)));
    if (!h) return msg(t('edWrongFolder') + (why ? '  [' + why + ']' : ''));
    await setDir(h); DIR = h; await refresh(); msg(t('edLinked'), true);
  } catch (e) { if (!e || e.name !== 'AbortError') msg(String(e && e.message || e)); }
};

(async () => {
  const { lang } = await chrome.storage.local.get('lang'); const L = LANGS[lang] ? lang : guessLang();
  setLang(L); applyI18n(); $('loop').textContent = '⚠ ' + t('edLoop');
  const sel = $('lang'); for (const [k, v] of Object.entries(LANGS)) { const o = document.createElement('option'); o.value = k; o.textContent = v; sel.append(o); }
  sel.value = L; sel.onchange = async () => { await chrome.storage.local.set({ lang: sel.value }); setLang(sel.value); applyI18n(); $('loop').textContent = '⚠ ' + t('edLoop'); await refresh(); };
  DIR = await getDir();
  await refresh();
})();
